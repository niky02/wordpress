<?php
 defined('IN_IA') or exit('Access Denied'); class Baobiao_4sModule extends WeModule { } ?>