<?php
$sql="CREATE TABLE IF NOT EXISTS `ims_baobiao_4s_car` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) unsigned NOT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `detail` text NOT NULL,
  `price` float NOT NULL,
  `guide_price` float NOT NULL,
  `images` text NOT NULL,
  `category_id` int(11) unsigned NOT NULL,
  `parameter` varchar(255) NOT NULL DEFAULT '',
  `parameter_content` text NOT NULL,
  `status` tinyint(3) NOT NULL DEFAULT '0',
  `sort` int(11) NOT NULL DEFAULT '0',
  `model` varchar(255) NOT NULL DEFAULT '',
  `seat` tinyint(3) NOT NULL,
  `output` float NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `video` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8;
CREATE TABLE IF NOT EXISTS `ims_baobiao_4s_category` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) unsigned NOT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `image` varchar(255) NOT NULL DEFAULT '',
  `sort` int(11) NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` tinyint(3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8;
CREATE TABLE IF NOT EXISTS `ims_baobiao_4s_news` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) unsigned NOT NULL,
  `node_id` int(11) unsigned NOT NULL,
  `status` tinyint(3) NOT NULL DEFAULT '0',
  `sort` int(11) NOT NULL,
  `image` varchar(255) NOT NULL DEFAULT '',
  `title` varchar(255) NOT NULL DEFAULT '',
  `body` text NOT NULL,
  `view` int(255) unsigned NOT NULL,
  `video` text NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
CREATE TABLE IF NOT EXISTS `ims_baobiao_4s_node` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) unsigned NOT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `sort` int(11) NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
CREATE TABLE IF NOT EXISTS `ims_baobiao_4s_order` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) unsigned NOT NULL,
  `openid` varchar(255) NOT NULL DEFAULT '',
  `name` varchar(255) NOT NULL DEFAULT '',
  `phone` varchar(255) NOT NULL DEFAULT '',
  `message` text NOT NULL,
  `status` tinyint(3) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
CREATE TABLE IF NOT EXISTS `ims_baobiao_4s_photo` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) unsigned NOT NULL,
  `images` text NOT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8;
CREATE TABLE IF NOT EXISTS `ims_baobiao_4s_salesman` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) unsigned NOT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `phone` varchar(255) NOT NULL DEFAULT '',
  `image` varchar(255) NOT NULL DEFAULT '',
  `sort` int(11) NOT NULL,
  `status` tinyint(3) NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
CREATE TABLE IF NOT EXISTS `ims_baobiao_4s_setting` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) unsigned NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `info` text NOT NULL,
  `tech_support` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8;
CREATE TABLE IF NOT EXISTS `ims_baobiao_4s_swiper` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) unsigned NOT NULL,
  `image` varchar(255) NOT NULL DEFAULT '',
  `status` tinyint(3) NOT NULL,
  `sort` int(11) NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `type` tinyint(3) NOT NULL DEFAULT '0',
  `meta` varchar(1000) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8;
";
pdo_run($sql);
if(!pdo_fieldexists('baobiao_4s_car',  'id')) {
	pdo_query("ALTER TABLE ".tablename('baobiao_4s_car')." ADD `id` int(11) unsigned NOT NULL AUTO_INCREMENT;");
}
if(!pdo_fieldexists('baobiao_4s_car',  'uniacid')) {
	pdo_query("ALTER TABLE ".tablename('baobiao_4s_car')." ADD `uniacid` int(11) unsigned NOT NULL;");
}
if(!pdo_fieldexists('baobiao_4s_car',  'name')) {
	pdo_query("ALTER TABLE ".tablename('baobiao_4s_car')." ADD `name` varchar(255) NOT NULL DEFAULT '';");
}
if(!pdo_fieldexists('baobiao_4s_car',  'detail')) {
	pdo_query("ALTER TABLE ".tablename('baobiao_4s_car')." ADD `detail` text NOT NULL;");
}
if(!pdo_fieldexists('baobiao_4s_car',  'price')) {
	pdo_query("ALTER TABLE ".tablename('baobiao_4s_car')." ADD `price` float NOT NULL;");
}
if(!pdo_fieldexists('baobiao_4s_car',  'guide_price')) {
	pdo_query("ALTER TABLE ".tablename('baobiao_4s_car')." ADD `guide_price` float NOT NULL;");
}
if(!pdo_fieldexists('baobiao_4s_car',  'images')) {
	pdo_query("ALTER TABLE ".tablename('baobiao_4s_car')." ADD `images` text NOT NULL;");
}
if(!pdo_fieldexists('baobiao_4s_car',  'category_id')) {
	pdo_query("ALTER TABLE ".tablename('baobiao_4s_car')." ADD `category_id` int(11) unsigned NOT NULL;");
}
if(!pdo_fieldexists('baobiao_4s_car',  'parameter')) {
	pdo_query("ALTER TABLE ".tablename('baobiao_4s_car')." ADD `parameter` varchar(255) NOT NULL DEFAULT '';");
}
if(!pdo_fieldexists('baobiao_4s_car',  'parameter_content')) {
	pdo_query("ALTER TABLE ".tablename('baobiao_4s_car')." ADD `parameter_content` text NOT NULL;");
}
if(!pdo_fieldexists('baobiao_4s_car',  'status')) {
	pdo_query("ALTER TABLE ".tablename('baobiao_4s_car')." ADD `status` tinyint(3) NOT NULL DEFAULT '0';");
}
if(!pdo_fieldexists('baobiao_4s_car',  'sort')) {
	pdo_query("ALTER TABLE ".tablename('baobiao_4s_car')." ADD `sort` int(11) NOT NULL DEFAULT '0';");
}
if(!pdo_fieldexists('baobiao_4s_car',  'model')) {
	pdo_query("ALTER TABLE ".tablename('baobiao_4s_car')." ADD `model` varchar(255) NOT NULL DEFAULT '';");
}
if(!pdo_fieldexists('baobiao_4s_car',  'seat')) {
	pdo_query("ALTER TABLE ".tablename('baobiao_4s_car')." ADD `seat` tinyint(3) NOT NULL;");
}
if(!pdo_fieldexists('baobiao_4s_car',  'output')) {
	pdo_query("ALTER TABLE ".tablename('baobiao_4s_car')." ADD `output` float NOT NULL;");
}
if(!pdo_fieldexists('baobiao_4s_car',  'updated_at')) {
	pdo_query("ALTER TABLE ".tablename('baobiao_4s_car')." ADD `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;");
}
if(!pdo_fieldexists('baobiao_4s_car',  'video')) {
	pdo_query("ALTER TABLE ".tablename('baobiao_4s_car')." ADD `video` text NOT NULL;");
}
if(!pdo_fieldexists('baobiao_4s_category',  'id')) {
	pdo_query("ALTER TABLE ".tablename('baobiao_4s_category')." ADD `id` int(11) unsigned NOT NULL AUTO_INCREMENT;");
}
if(!pdo_fieldexists('baobiao_4s_category',  'uniacid')) {
	pdo_query("ALTER TABLE ".tablename('baobiao_4s_category')." ADD `uniacid` int(11) unsigned NOT NULL;");
}
if(!pdo_fieldexists('baobiao_4s_category',  'name')) {
	pdo_query("ALTER TABLE ".tablename('baobiao_4s_category')." ADD `name` varchar(255) NOT NULL DEFAULT '';");
}
if(!pdo_fieldexists('baobiao_4s_category',  'image')) {
	pdo_query("ALTER TABLE ".tablename('baobiao_4s_category')." ADD `image` varchar(255) NOT NULL DEFAULT '';");
}
if(!pdo_fieldexists('baobiao_4s_category',  'sort')) {
	pdo_query("ALTER TABLE ".tablename('baobiao_4s_category')." ADD `sort` int(11) NOT NULL;");
}
if(!pdo_fieldexists('baobiao_4s_category',  'updated_at')) {
	pdo_query("ALTER TABLE ".tablename('baobiao_4s_category')." ADD `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;");
}
if(!pdo_fieldexists('baobiao_4s_category',  'status')) {
	pdo_query("ALTER TABLE ".tablename('baobiao_4s_category')." ADD `status` tinyint(3) NOT NULL;");
}
if(!pdo_fieldexists('baobiao_4s_news',  'id')) {
	pdo_query("ALTER TABLE ".tablename('baobiao_4s_news')." ADD `id` int(11) unsigned NOT NULL AUTO_INCREMENT;");
}
if(!pdo_fieldexists('baobiao_4s_news',  'uniacid')) {
	pdo_query("ALTER TABLE ".tablename('baobiao_4s_news')." ADD `uniacid` int(11) unsigned NOT NULL;");
}
if(!pdo_fieldexists('baobiao_4s_news',  'node_id')) {
	pdo_query("ALTER TABLE ".tablename('baobiao_4s_news')." ADD `node_id` int(11) unsigned NOT NULL;");
}
if(!pdo_fieldexists('baobiao_4s_news',  'status')) {
	pdo_query("ALTER TABLE ".tablename('baobiao_4s_news')." ADD `status` tinyint(3) NOT NULL DEFAULT '0';");
}
if(!pdo_fieldexists('baobiao_4s_news',  'sort')) {
	pdo_query("ALTER TABLE ".tablename('baobiao_4s_news')." ADD `sort` int(11) NOT NULL;");
}
if(!pdo_fieldexists('baobiao_4s_news',  'image')) {
	pdo_query("ALTER TABLE ".tablename('baobiao_4s_news')." ADD `image` varchar(255) NOT NULL DEFAULT '';");
}
if(!pdo_fieldexists('baobiao_4s_news',  'title')) {
	pdo_query("ALTER TABLE ".tablename('baobiao_4s_news')." ADD `title` varchar(255) NOT NULL DEFAULT '';");
}
if(!pdo_fieldexists('baobiao_4s_news',  'body')) {
	pdo_query("ALTER TABLE ".tablename('baobiao_4s_news')." ADD `body` text NOT NULL;");
}
if(!pdo_fieldexists('baobiao_4s_news',  'view')) {
	pdo_query("ALTER TABLE ".tablename('baobiao_4s_news')." ADD `view` int(255) unsigned NOT NULL;");
}
if(!pdo_fieldexists('baobiao_4s_news',  'video')) {
	pdo_query("ALTER TABLE ".tablename('baobiao_4s_news')." ADD `video` text NOT NULL;");
}
if(!pdo_fieldexists('baobiao_4s_news',  'updated_at')) {
	pdo_query("ALTER TABLE ".tablename('baobiao_4s_news')." ADD `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;");
}
if(!pdo_fieldexists('baobiao_4s_node',  'id')) {
	pdo_query("ALTER TABLE ".tablename('baobiao_4s_node')." ADD `id` int(11) unsigned NOT NULL AUTO_INCREMENT;");
}
if(!pdo_fieldexists('baobiao_4s_node',  'uniacid')) {
	pdo_query("ALTER TABLE ".tablename('baobiao_4s_node')." ADD `uniacid` int(11) unsigned NOT NULL;");
}
if(!pdo_fieldexists('baobiao_4s_node',  'name')) {
	pdo_query("ALTER TABLE ".tablename('baobiao_4s_node')." ADD `name` varchar(255) NOT NULL DEFAULT '';");
}
if(!pdo_fieldexists('baobiao_4s_node',  'sort')) {
	pdo_query("ALTER TABLE ".tablename('baobiao_4s_node')." ADD `sort` int(11) NOT NULL;");
}
if(!pdo_fieldexists('baobiao_4s_node',  'updated_at')) {
	pdo_query("ALTER TABLE ".tablename('baobiao_4s_node')." ADD `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;");
}
if(!pdo_fieldexists('baobiao_4s_order',  'id')) {
	pdo_query("ALTER TABLE ".tablename('baobiao_4s_order')." ADD `id` int(11) unsigned NOT NULL AUTO_INCREMENT;");
}
if(!pdo_fieldexists('baobiao_4s_order',  'uniacid')) {
	pdo_query("ALTER TABLE ".tablename('baobiao_4s_order')." ADD `uniacid` int(11) unsigned NOT NULL;");
}
if(!pdo_fieldexists('baobiao_4s_order',  'openid')) {
	pdo_query("ALTER TABLE ".tablename('baobiao_4s_order')." ADD `openid` varchar(255) NOT NULL DEFAULT '';");
}
if(!pdo_fieldexists('baobiao_4s_order',  'name')) {
	pdo_query("ALTER TABLE ".tablename('baobiao_4s_order')." ADD `name` varchar(255) NOT NULL DEFAULT '';");
}
if(!pdo_fieldexists('baobiao_4s_order',  'phone')) {
	pdo_query("ALTER TABLE ".tablename('baobiao_4s_order')." ADD `phone` varchar(255) NOT NULL DEFAULT '';");
}
if(!pdo_fieldexists('baobiao_4s_order',  'message')) {
	pdo_query("ALTER TABLE ".tablename('baobiao_4s_order')." ADD `message` text NOT NULL;");
}
if(!pdo_fieldexists('baobiao_4s_order',  'status')) {
	pdo_query("ALTER TABLE ".tablename('baobiao_4s_order')." ADD `status` tinyint(3) NOT NULL DEFAULT '0';");
}
if(!pdo_fieldexists('baobiao_4s_order',  'created_at')) {
	pdo_query("ALTER TABLE ".tablename('baobiao_4s_order')." ADD `created_at` timestamp NULL DEFAULT NULL;");
}
if(!pdo_fieldexists('baobiao_4s_order',  'updated_at')) {
	pdo_query("ALTER TABLE ".tablename('baobiao_4s_order')." ADD `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;");
}
if(!pdo_fieldexists('baobiao_4s_photo',  'id')) {
	pdo_query("ALTER TABLE ".tablename('baobiao_4s_photo')." ADD `id` int(11) unsigned NOT NULL AUTO_INCREMENT;");
}
if(!pdo_fieldexists('baobiao_4s_photo',  'uniacid')) {
	pdo_query("ALTER TABLE ".tablename('baobiao_4s_photo')." ADD `uniacid` int(11) unsigned NOT NULL;");
}
if(!pdo_fieldexists('baobiao_4s_photo',  'images')) {
	pdo_query("ALTER TABLE ".tablename('baobiao_4s_photo')." ADD `images` text NOT NULL;");
}
if(!pdo_fieldexists('baobiao_4s_photo',  'name')) {
	pdo_query("ALTER TABLE ".tablename('baobiao_4s_photo')." ADD `name` varchar(255) NOT NULL DEFAULT '';");
}
if(!pdo_fieldexists('baobiao_4s_photo',  'updated_at')) {
	pdo_query("ALTER TABLE ".tablename('baobiao_4s_photo')." ADD `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;");
}
if(!pdo_fieldexists('baobiao_4s_salesman',  'id')) {
	pdo_query("ALTER TABLE ".tablename('baobiao_4s_salesman')." ADD `id` int(11) unsigned NOT NULL AUTO_INCREMENT;");
}
if(!pdo_fieldexists('baobiao_4s_salesman',  'uniacid')) {
	pdo_query("ALTER TABLE ".tablename('baobiao_4s_salesman')." ADD `uniacid` int(11) unsigned NOT NULL;");
}
if(!pdo_fieldexists('baobiao_4s_salesman',  'name')) {
	pdo_query("ALTER TABLE ".tablename('baobiao_4s_salesman')." ADD `name` varchar(255) NOT NULL DEFAULT '';");
}
if(!pdo_fieldexists('baobiao_4s_salesman',  'phone')) {
	pdo_query("ALTER TABLE ".tablename('baobiao_4s_salesman')." ADD `phone` varchar(255) NOT NULL DEFAULT '';");
}
if(!pdo_fieldexists('baobiao_4s_salesman',  'image')) {
	pdo_query("ALTER TABLE ".tablename('baobiao_4s_salesman')." ADD `image` varchar(255) NOT NULL DEFAULT '';");
}
if(!pdo_fieldexists('baobiao_4s_salesman',  'sort')) {
	pdo_query("ALTER TABLE ".tablename('baobiao_4s_salesman')." ADD `sort` int(11) NOT NULL;");
}
if(!pdo_fieldexists('baobiao_4s_salesman',  'status')) {
	pdo_query("ALTER TABLE ".tablename('baobiao_4s_salesman')." ADD `status` tinyint(3) NOT NULL;");
}
if(!pdo_fieldexists('baobiao_4s_salesman',  'updated_at')) {
	pdo_query("ALTER TABLE ".tablename('baobiao_4s_salesman')." ADD `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;");
}
if(!pdo_fieldexists('baobiao_4s_setting',  'id')) {
	pdo_query("ALTER TABLE ".tablename('baobiao_4s_setting')." ADD `id` int(11) unsigned NOT NULL AUTO_INCREMENT;");
}
if(!pdo_fieldexists('baobiao_4s_setting',  'uniacid')) {
	pdo_query("ALTER TABLE ".tablename('baobiao_4s_setting')." ADD `uniacid` int(11) unsigned NOT NULL;");
}
if(!pdo_fieldexists('baobiao_4s_setting',  'updated_at')) {
	pdo_query("ALTER TABLE ".tablename('baobiao_4s_setting')." ADD `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;");
}
if(!pdo_fieldexists('baobiao_4s_setting',  'info')) {
	pdo_query("ALTER TABLE ".tablename('baobiao_4s_setting')." ADD `info` text NOT NULL;");
}
if(!pdo_fieldexists('baobiao_4s_setting',  'tech_support')) {
	pdo_query("ALTER TABLE ".tablename('baobiao_4s_setting')." ADD `tech_support` varchar(255) NOT NULL DEFAULT '';");
}
if(!pdo_fieldexists('baobiao_4s_swiper',  'id')) {
	pdo_query("ALTER TABLE ".tablename('baobiao_4s_swiper')." ADD `id` int(11) unsigned NOT NULL AUTO_INCREMENT;");
}
if(!pdo_fieldexists('baobiao_4s_swiper',  'uniacid')) {
	pdo_query("ALTER TABLE ".tablename('baobiao_4s_swiper')." ADD `uniacid` int(11) unsigned NOT NULL;");
}
if(!pdo_fieldexists('baobiao_4s_swiper',  'image')) {
	pdo_query("ALTER TABLE ".tablename('baobiao_4s_swiper')." ADD `image` varchar(255) NOT NULL DEFAULT '';");
}
if(!pdo_fieldexists('baobiao_4s_swiper',  'status')) {
	pdo_query("ALTER TABLE ".tablename('baobiao_4s_swiper')." ADD `status` tinyint(3) NOT NULL;");
}
if(!pdo_fieldexists('baobiao_4s_swiper',  'sort')) {
	pdo_query("ALTER TABLE ".tablename('baobiao_4s_swiper')." ADD `sort` int(11) NOT NULL;");
}
if(!pdo_fieldexists('baobiao_4s_swiper',  'updated_at')) {
	pdo_query("ALTER TABLE ".tablename('baobiao_4s_swiper')." ADD `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;");
}
if(!pdo_fieldexists('baobiao_4s_swiper',  'type')) {
	pdo_query("ALTER TABLE ".tablename('baobiao_4s_swiper')." ADD `type` tinyint(3) NOT NULL DEFAULT '0';");
}
if(!pdo_fieldexists('baobiao_4s_swiper',  'meta')) {
	pdo_query("ALTER TABLE ".tablename('baobiao_4s_swiper')." ADD `meta` varchar(1000) NOT NULL DEFAULT '';");
}

?>