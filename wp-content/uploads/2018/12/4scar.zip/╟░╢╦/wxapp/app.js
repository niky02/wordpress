App({
    onLaunch: function() {},
    util: require("we7/resource/js/util.js"),
    globalData: {
        userInfo: null
    },
    siteInfo: require("siteinfo.js"),
    getGlobalData: function(t) {
        this.util.request({
            url: "entry/wxapp/global",
            method: "POST",
            data: {
                m: "baobiao_4s"
            },
            cachetime: "30",
            success: function(e) {
                var o = e.data.data;
                t(o);
            }
        });
    },
    template: require("pages/template/template.js"),
    tabBar: {
        color: "#123",
        selectedColor: "#1ba9ba",
        borderStyle: "#1ba9ba",
        backgroundColor: "#fff",
        list: [ {
            pagePath: "/pages/index/index",
            iconPath: "/we7/resource/icon/home.png",
            selectedIconPath: "/we7/resource/icon/homeselect.png",
            icon: "icon-home1",
            text: "首页"
        }, {
            pagePath: "/pages/news/index",
            iconPath: "/we7/resource/icon/user.png",
            selectedIconPath: "/we7/resource/icon/userselect.png",
            icon: "icon-news1",
            text: "新闻资讯"
        }, {
            pagePath: "/pages/car/index",
            iconPath: "/we7/resource/icon/user.png",
            selectedIconPath: "/we7/resource/icon/userselect.png",
            icon: "icon-car1",
            text: "车型报价"
        }, {
            pagePath: "/pages/order/order",
            iconPath: "/we7/resource/icon/todo.png",
            selectedIconPath: "/we7/resource/icon/todoselect.png",
            icon: "icon-order",
            text: "在线预约"
        }, {
            pagePath: "/pages/about/about",
            iconPath: "/we7/resource/icon/pay.png",
            selectedIconPath: "/we7/resource/icon/payselect.png",
            icon: "icon-store1",
            text: "门店介绍"
        } ]
    }
});