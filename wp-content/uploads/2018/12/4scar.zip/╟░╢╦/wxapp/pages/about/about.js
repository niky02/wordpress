var app = getApp(), WxParse = require("../../utils/wxParse/wxParse.js"), common = require("../../utils/common.js");

Page({
    data: {},
    onLoad: function(t) {
        app.template.footer(this);
        var a = this;
        app.getGlobalData(function(t) {
            a.setData({
                info: t.info
            }), wx.setNavigationBarTitle({
                title: t.info.shop_text
            }), WxParse.wxParse("content", "html", a.data.info.about, a, 15);
        }), app.util.request({
            url: "entry/wxapp/salesman",
            method: "POST",
            data: {
                m: "baobiao_4s"
            },
            success: function(t) {
                var o = t.data.data;
                a.setData({
                    salesman: o
                });
            }
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {},
    callPhone: function(t) {
        var o = t.currentTarget.dataset.phone;
        common.callPhone(o);
    },
    toLocation: function() {
        common.toLocation(this);
    }
});