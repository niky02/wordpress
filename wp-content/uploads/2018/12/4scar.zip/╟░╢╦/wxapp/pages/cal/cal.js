var app = getApp();

function e(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function a(e) {
    return e = e.toString().replace(/\,/g, ""), parseInt(e);
}

function t(e) {
    e = e.toString().replace(/\$|\,/g, ""), isNaN(e) && (e = "0");
    var a = e == (e = Math.abs(e));
    e = Math.floor(100 * e + .50000000001), e = Math.floor(e / 100).toString();
    for (var t = 0; t < Math.floor((e.length - (1 + t)) / 3); t++) e = e.substring(0, e.length - (4 * t + 3)) + "," + e.substring(e.length - (4 * t + 3));
    return (a ? "" : "-") + e;
}

function s(e) {
    return e = e.toString().replace(/\$|\,/g, ""), isNaN(e) && (e = "0"), (e == (e = Math.abs(e)) ? "" : "-") + (e = Math.floor(1e4 * e + .50000000001).toString());
}

function c(e) {
    return e.replace(/\b(0+)/gi, "");
}

function r(e) {
    return e.toString().replace(/\D/g, "");
}

function i(e) {
    var a = parseFloat(e);
    return a <= 1 ? 0 : 1 < a && a <= 1.6 ? 1 : 1.6 < a && a <= 2 ? 2 : 2 < a && a <= 2.5 ? 3 : 2.5 < a && a <= 3 ? 4 : 3 < a && a <= 4 ? 5 : 4 < a ? 6 : void 0;
}

function priceFormat(e) {
    return t(e);
}

var l = e(require("../../utils/util.js"));

e(require("../../utils/calc.js")), Page({
    data: {
        customFpSt: !1,
        price: "",
        mprice: 0,
        hideseat: 5,
        more: !1,
        calcStatus: 1,
        sybx: 0,
        total: 0,
        dtotal: 0,
        yprice: 0,
        sharetitle: "",
        byhf: 0,
        allChecked: !0,
        business: {
            chkTPL: {
                text: "第三者责任险",
                value: 0,
                checked: !0,
                radio: [ {
                    value: "5万",
                    sel: !1
                }, {
                    value: "10万",
                    sel: !0
                }, {
                    value: "20万",
                    sel: !1
                }, {
                    value: "50万",
                    sel: !1
                }, {
                    value: "100万",
                    sel: !1
                } ]
            },
            calcTPLWuguo: {
                text: "第三者不计免赔",
                value: 0,
                checked: !0
            },
            calcCarDamage: {
                text: "车辆损失险",
                value: 0,
                checked: !0
            },
            calcCarDamageWuguo: {
                text: "车损险不计免赔",
                value: 0,
                checked: !0
            },
            calcCarTheft: {
                text: "全车盗抢险",
                value: 0,
                checked: !0
            },
            calcBreakageOfGlass: {
                text: "玻璃单独破碎险",
                value: 0,
                checked: !0,
                radio: [ {
                    value: "国产",
                    sel: !0
                }, {
                    value: "进口",
                    sel: !1
                } ]
            },
            calcSelfignite: {
                text: "自燃损失险",
                value: 0,
                checked: !0
            },
            calcPassenger: {
                text: "车上人员责任险",
                value: 0,
                checked: !0,
                radio: [ {
                    value: "1人",
                    sel: !0,
                    price: 50
                }, {
                    value: "2人",
                    sel: !1,
                    price: 100
                }, {
                    value: "3人",
                    sel: !1,
                    price: 150
                }, {
                    value: "4人",
                    sel: !1,
                    price: 200
                }, {
                    value: "5人",
                    sel: !1,
                    price: 250
                }, {
                    value: "6人",
                    sel: !1,
                    price: 300
                }, {
                    value: "7人",
                    sel: !1,
                    price: 350
                } ]
            },
            calcCarDamageDW: {
                text: "车身划痕险",
                value: 0,
                checked: !0,
                radio: [ {
                    value: "2千",
                    sel: !1,
                    price: 2e3
                }, {
                    value: "5千",
                    sel: !0,
                    price: 5e3
                }, {
                    value: "1万",
                    sel: !1,
                    price: 1e4
                }, {
                    value: "2万",
                    sel: !1,
                    price: 2e4
                } ]
            }
        },
        must: {
            gzs: {
                index: 0,
                value: 0,
                text: "购置税",
                checked: !0,
                default: !0,
                noInput: !0
            },
            xfs: {
                index: 1,
                value: 0,
                text: "消费税",
                checked: !0,
                default: !0,
                noInput: !0
            },
            paizhao_fee: {
                index: 2,
                value: 0,
                text: "上牌费用",
                checked: !0,
                default: !0
            },
            ccs: {
                index: 3,
                value: 0,
                text: "车船使用税",
                checked: !0,
                default: !0,
                radio: [ {
                    price: 300,
                    value: "1.0L(含)以下",
                    sel: !1
                }, {
                    price: 420,
                    value: "1.0-1.6L(含)",
                    sel: !1
                }, {
                    price: 480,
                    value: "1.6-2.0L(含）",
                    sel: !0
                }, {
                    price: 900,
                    value: "2.0-2.5L(含)",
                    sel: !1
                }, {
                    price: 1920,
                    value: "2.5-3.0L(含)",
                    sel: !1
                }, {
                    price: 3480,
                    value: "3.0-4.0L(含)",
                    sel: !1
                }, {
                    price: 5280,
                    value: "4.0以上",
                    sel: !1
                } ]
            },
            jqx: {
                index: 4,
                value: 0,
                text: "交强险",
                checked: !0,
                default: !0,
                noInput: !0,
                radio: [ {
                    value: "家用6座以下",
                    sel: !0
                }, {
                    value: "家用6座及以上",
                    sel: !1
                } ]
            }
        },
        checkedChkTPL: !0,
        checkedCalcCarDamage: !0,
        aside: {
            type: "",
            hidden: !0,
            data: []
        },
        dk: {
            shoufu: [ {
                value: 0,
                checked: !1
            }, {
                value: 10,
                checked: !1
            }, {
                value: 20,
                checked: !1
            }, {
                value: 30,
                checked: !0
            }, {
                value: 40,
                checked: !1
            }, {
                value: 50,
                checked: !1
            } ],
            ll: [ {
                year: 1,
                value: 4.85,
                checked: !1
            }, {
                year: 2,
                value: 5.25,
                checked: !1
            }, {
                year: 3,
                value: 5.25,
                checked: !0
            }, {
                year: 4,
                value: 5.25,
                checked: !1
            }, {
                year: 5,
                value: 5.25,
                checked: !1
            } ],
            llValue: 5.25,
            years: 1,
            firstPay: 0,
            carfp: 0,
            lx: 0,
            yg: 0
        },
        tplLevel: 2,
        dwindex: 1,
        bog: 0,
        ccsLevel: 1,
        jqxLevel: 0
    },
    onShareAppMessage: function() {
        return {
            title: this.data.info.name + " " + this.data.info.model + " 价格计算器"
        };
    },
    onLoad: function(o) {
        var h = this;
        o.id && o.id, console.log(o), app.util.request({
            url: "entry/wxapp/calculate",
            method: "POST",
            data: {
                m: "baobiao_4s",
                id: o.id
            },
            success: function(e) {
                var a = priceFormat(1e4 * e.data.data.info.price);
                h.setData({
                    info: e.data.data.info,
                    price_format: a
                }), console.log(e.data);
                var t = h.data;
                for (var c in t.must.ccs.radio = e.data.data.must.ccs.radio, t.must.ccs.radio[2].sel = !0, 
                t.dk.ll = e.data.data.dk.ll, t.dk.ll[0].checked = !0, t.dk.llValue = t.dk.ll[0].value, 
                t.dk.ll) 3 == t.dk.ll[c].year && (t.dk.ll[0].checked = !1, t.dk.ll[c].checked = !0, 
                t.dk.llValue = t.dk.ll[c].value);
                for (var r in t.dk.shoufu = e.data.data.dk.shoufu, t.dk.shoufu[0].checked = !0, 
                t.dk.shoufu) 30 == t.dk.shoufu[r].value && (t.dk.shoufu[0].checked = !1, t.dk.shoufu[r].checked = !0);
                if (e.data.data.info && 0 != e.data.data.info.output) {
                    for (var l in t.must.ccs.radio) t.must.ccs.radio[l].sel = !1;
                    console.log(i(e.data.data.info.output)), t.must.ccs.radio[i(e.data.data.info.output)].sel = !0;
                }
                t.name = o.id ? e.data.data.info.name : decodeURIComponent(o.title), e.data.data.info && (t.hideseat = e.data.data.info.seat);
                var u = 5 < t.hideseat ? 1 : 0;
                for (var d in t.must.jqx.radio) t.must.jqx.radio[d].sel = !1;
                t.must.jqx.radio[u].sel = !0, t.must.paizhao_fee.value = e.data.data.must.paizhao_fee.price;
                var n = o.id ? parseInt(s(parseFloat(e.data.data.info.price))) : parseInt(s(parseFloat(o.price)));
                t.price = n, console.log(t), t = h.mustTotel(t), t = h.businessTotel(t), t = h.dk(t), 
                console.log(t), t = h.getTotal(t), e.data.data.info && (console.log(t), h.setData(t));
            }
        });
    },
    calcStatus: function(e) {
        console.log(e.currentTarget);
        var a = e.currentTarget.dataset.value;
        a = parseFloat(a), this.setData({
            calcStatus: a
        });
    },
    calcShoufu: function(e) {
        e.currentTarget.dataset.value;
        var a = e.currentTarget.dataset.index, t = this.data;
        for (var s in t.dk.shoufu) t.dk.shoufu[s].checked = !1;
        t.dk.shoufu[a].checked = !0, t.dk.carfp = 0, t.customFpSt = !1, t = this.dk(t), 
        t = this.getTotal(t), this.setData(t);
    },
    calcYear: function(e) {
        e.currentTarget.dataset.years;
        var a = e.currentTarget.dataset.index, t = this.data;
        for (var s in t.dk.ll) t.dk.ll[s].checked = !1;
        t.dk.ll[a].checked = !0, t.dk.llValue = t.dk.ll[a].value, t = this.dk(t), t = this.getTotal(t), 
        this.setData(t);
    },
    customFp: function(e) {
        var a = this.data;
        for (var t in parseInt(c(e.target.value)) >= parseInt(a.price) ? a.dk.carfp = parseInt(a.price) : a.dk.carfp = parseInt(c(e.target.value)), 
        a.dk.shoufu) a.dk.shoufu[t].checked = !1;
        a = this.dk(a), a = this.getTotal(a), this.setData(a);
    },
    customLl: function(e) {
        var a = this.data;
        console.log(e.target.value), a.dk.llValue = e.target.value, a = this.dk(a), a = this.getTotal(a), 
        this.setData(a);
    },
    hidden: function(e) {
        var a = this.data.aside;
        a.hidden = e, this.setData({
            aside: a
        });
    },
    aside: function(e) {
        this.data;
        var a = e.currentTarget.dataset.aside.split("-"), t = {};
        console.log(a), t.type = a, t.data = this.data[a[0]][a[1]].radio, t.hidden = !1, 
        this.setData({
            aside: t
        });
    },
    check: function(e) {
        var a = this.data, t = a.business, s = a.allChecked;
        for (var c in t[e.target.dataset.value].checked = !t[e.target.dataset.value].checked, 
        t.chkTPL.checked || "chkTPL" != e.target.dataset.value || (t.calcPassenger.checked = !1, 
        t.calcTPLWuguo.checked = !1), t.calcCarDamage.checked || "calcCarDamage" != e.target.dataset.value || (t.calcCarTheft.checked = !1, 
        t.calcCarDamageDW.checked = !1, t.calcCarDamageWuguo.checked = !1), "chkTPL" != e.target.dataset.value && (t.chkTPL.checked = !!t.chkTPL.checked || t.calcPassenger.checked || t.calcTPLWuguo.checked), 
        "calcCarDamage" != e.target.dataset.value && (t.calcCarDamage.checked = !!t.calcCarDamage.checked || t.calcCarTheft.checked || t.calcCarDamageDW.checked || t.calcCarDamageWuguo.checked), 
        a.business) {
            if (0 == a.business[c].checked) {
                s = !1;
                break;
            }
            s = !0;
        }
        a.allChecked = s, a.business = t, a = Object.assign(a, this.businessTotel(a)), a = Object.assign(a, this.dk(a)), 
        a = this.getTotal(a), this.setData(a);
    },
    mustCheck: function(e) {
        var a = this.data, t = a.must;
        t[e.target.name].checked = !t[e.target.name].checked, a = Object.assign(a, this.mustTotel(a)), 
        a = Object.assign(a, this.dk(a)), a = this.getTotal(a), this.setData(a);
    },
    asideClose: function() {
        var e = this.data.aside;
        e.hidden = !0, this.setData({
            aside: e
        });
    },
    radioChange: function(e) {
        var a = this.data;
        a.aside.hidden = !0, console.log(e);
        for (var t = a.aside.data, s = (Number(e.target.value), 0), c = t.length; s < c; ++s) t[s].sel = s == e.detail.value;
        for (var r in a[a.aside.type[0]][a.aside.type[1]].radio = t, a[a.aside.type[0]][a.aside.type[1]].value = this[a.aside.type[1]](a), 
        a.must.jqx.radio) 1 == a.must.jqx.radio[r].sel && (a.hideseat = 0 == r ? 5 : 6);
        a = Object.assign(a, this.mustTotel(a)), a = Object.assign(a, this.businessTotel(a)), 
        a = Object.assign(a, this.dk(a)), a = this.getTotal(a), this.setData(a);
    },
    businessChange: function(e) {
        var a = this.data;
        a.business[e.target.name].value = "" == c(r(e.target.value)) ? 0 : c(r(e.target.value)), 
        a = this.businessTotel(a, !0), a = Object.assign(a, this.dk(a)), a = this.getTotal(a), 
        this.setData(a);
    },
    mustChange: function(e) {
        e.target.name;
        var a = this.data;
        a.must[e.target.name].value = "" == c(r(e.target.value)) ? 0 : c(r(e.target.value)), 
        a = this.mustTotel(a, !0), a = Object.assign(a, this.dk(a)), a = this.getTotal(a), 
        this.setData(a);
    },
    allSel: function(e) {
        var a = this.data;
        for (var t in a.allChecked = !a.allChecked, a.business) a.allChecked ? a.business[t].checked = !0 : a.business[t].checked = !1;
        a.checkedChkTPL = !0, a.checkedCalcCarDamage = !0, a = Object.assign(a, this.businessTotel(a)), 
        a = Object.assign(a, this.dk(a)), a = this.getTotal(a), this.setData(a);
    },
    priceChange: function(e) {
        var a = c(r(e.target.value)), t = this.data;
        for (var s in t.price = a, t.must.paizhao_fee.value = t.getData.must.paizhao_fee.price, 
        t.getData.must) "ccs" != s && "paizhao_fee" != s && (t.must[s].value = t.getData.must[s].value);
        t.dk.carfp = 0, t = Object.assign(this.businessTotel(t), this.mustTotel(t), this.dk(t)), 
        t = this.getTotal(t), this.setData(t);
    },
    priceFocus: function(e) {
        var a = e.target.value;
        this.setData({
            price: "",
            oldPrice: a
        });
    },
    priceBlur: function(e) {
        var a = "" == e.target.value ? this.data.oldPrice : e.target.value;
        this.setData({
            price: a
        });
    },
    customFpShow: function() {
        var e = this.data;
        for (var a in e.dk.shoufu) e.dk.shoufu[a].checked = !1;
        e.customFpSt = !0, (e = this.dk(e)).dk.carfp = 0, this.setData(e);
    },
    getTotal: function(e) {
        for (var s in e.total = 0 == e.price ? 0 : a(e.price) + a(e.byhf) + a(e.sybx), e.dtotal = 0 == e.price ? 0 : a(e.total) + a(e.dk.lx), 
        e.dk.lx = t(e.dk.lx), e.dk.yg = t(e.dk.yg), e.dk.firstPay = t(a(e.dk.firstPay)), 
        e.byhf = t(e.byhf), e.sybx = t(e.sybx), e.total = t(e.total), e.dtotal = t(e.dtotal), 
        e.business) e.business[s].value = t(e.business[s].value);
        for (var c in e.must) e.must[c].value = t(e.must[c].value);
        return e;
    },
    dk: function(e) {
        var t = e || this.data, s = t.dk.llValue, c = 3, r = .3;
        for (var i in t.dk.ll) t.dk.ll[i].checked && (c = t.dk.ll[i].year);
        if (!t.customFpSt) {
            for (var i in t.dk.shoufu) t.dk.shoufu[i].checked && (r = parseInt(t.dk.shoufu[i].value) / 100);
            0 == t.dk.carfp || t.dk.carfp ? t.dk.carfp = 0 != t.dk.carfp ? t.dk.carfp : Math.round(r * t.price) : t.dk.carfp = 0;
        }
        t.dk.firstPay = t.dk.carfp + a(t.sybx) + a(t.byhf);
        var l = parseInt(t.price - t.dk.carfp);
        return t.dk.yg = 0 == s ? Math.round(l / (12 * c)) : Math.round(l * (s / 12 * Math.pow(1 + s / 12, 12 * c) / (Math.pow(1 + s / 12, 12 * c) - 1))), 
        t.dk.yg = 0 == t.price ? 0 : t.dk.yg, t.dk.lx = 0 == s ? 0 : t.dk.yg * c * 12 - l, 
        t.dk.lx = t.dk.lx <= 0 ? 0 : t.dk.lx, t.dk.lx = 0 == t.price ? 0 : t.dk.lx, t;
    },
    businessTotel: function(e, a) {
        if (!a) for (var t in e.business) e.business[t].value = parseInt(this[t](e));
        for (var s in e.sybx = 0, e.business) e.business[s].checked && (e.sybx += parseInt(e.business[s].value));
        return e.sybx = e.sybx ? e.sybx : 0, e.sybx = 0 == e.price ? 0 : e.sybx, e;
    },
    mustTotel: function(e, a) {
        if (!a) for (var t = Object.keys(e.must), s = t.length - 1; 0 <= s; s--) this[t[s]] && (e.must[t[s]].value = parseInt(this[t[s]](e)));
        for (var c in e.byhf = 0, e.must) e.must[c].checked && (e.byhf += parseInt(e.must[c].value));
        return e.byhf = 0 == e.price ? 0 : e.byhf, e;
    },
    paizhao_fee: function(e) {
        return 0 == e.price ? 0 : a(e.must.paizhao_fee.value);
    },
    ccs: function(e) {
        var a = 0;
        for (var t in e.must.ccs.radio) e.must.ccs.radio[t].sel && (a = e.must.ccs.radio[t].price);
        return 0 == e.price ? 0 : a;
    },
    xfs: function(e) {
        return 1521e3 <= e.price ? Math.round(e.price / 11.7) : 0;
    },
    gzs: function(e) {
        var a = 2;
        for (var t in e.must.ccs.radio) e.must.ccs.radio[t].sel && (a = t);
        var s = e.price / 1.17 * .1, c = Math.round(s);
        return 0 <= a && parseFloat(a) < 2 && (c = Math.round(e.price / 1.17 * .1 * 1)), 
        c;
    },
    jqx: function(e) {
        var a = 0;
        for (var t in e.must.jqx.radio) e.must.jqx.radio[t].sel && (a = t);
        var s = 1 == a ? 1100 : 950;
        return 0 == e.price ? 0 : s;
    },
    calcPassenger: function(e) {
        var a = 0;
        for (var t in e.business.calcPassenger.radio) e.business.calcPassenger.radio[t].sel && (a = e.business.calcPassenger.radio[t].price);
        return 0 == e.price ? 0 : a;
    },
    calcSelfignite: function(e) {
        return Math.round(.0015 * e.price);
    },
    calcCarDamage: function(e) {
        var a = 459;
        6 <= e.hideseat && (a = 550);
        var t = Math.round(.01088 * e.price + a);
        return 0 == e.price ? 0 : t;
    },
    calcCarTheft: function(e) {
        var a;
        return a = e.hideseat < 6 ? Math.round(.004505 * e.price + 102) : Math.round(.00374 * e.price + 119), 
        0 == e.price ? 0 : a;
    },
    calcCarDamageWuguo: function(e) {
        return Math.round(.2 * this.calcCarDamage(e));
    },
    calcTPLWuguo: function(e) {
        return Math.round(.2 * this.chkTPL(e));
    },
    chkTPL: function(e) {
        console.log(e);
        var a = 0;
        for (var t in e.business.chkTPL.radio) e.business.chkTPL.radio[t].sel && (a = t);
        var s = 0;
        return e.hideseat < 6 ? (0 == a && (s = 516), 1 == a && (s = 746), 2 == a && (s = 924), 
        3 == a && (s = 1252), 4 == a && (s = 1630)) : (0 == a && (s = 478), 1 == a && (s = 674), 
        2 == a && (s = 821), 3 == a && (s = 1094), 4 == a && (s = 1425)), 0 == e.price ? 0 : s;
    },
    calcBreakageOfGlass: function(e) {
        var a = 0;
        for (var t in e.business.calcBreakageOfGlass.radio) e.business.calcBreakageOfGlass.radio[t].sel && (a = t);
        return a = 0 == a ? Math.round(.0015 * e.price) : Math.round(.0025 * e.price), 0 == e.price ? 0 : a;
    },
    calcCarDamageDW: function(e) {
        var a = 0;
        for (var t in e.business.calcCarDamageDW.radio) e.business.calcCarDamageDW.radio[t].sel && (a = t);
        var s = e.price, c = 0;
        return s <= 3e5 ? (0 == a && (c = 400), 1 == a && (c = 570), 2 == a && (c = 760), 
        3 == a && (c = 1140)) : 5e5 < s ? (0 == a && (c = 850), 1 == a && (c = 1100), 2 == a && (c = 1500), 
        3 == a && (c = 2250)) : (0 == a && (c = 585), 1 == a && (c = 900), 2 == a && (c = 1170), 
        3 == a && (c = 1780)), 0 == e.price ? 0 : c;
    }
});