var app = getApp(), common = require("../../utils/common.js"), WxParse = require("../../utils/wxParse/wxParse.js");

Page({
    data: {
        btn_show: !1,
        tel_show: !1,
        curr_tab: 1,
        swiper_count: 1,
        swiper_current: 1
    },
    onLoad: function(t) {
        var e = this;
        app.getGlobalData(function(t) {
            e.setData({
                info: t.info
            });
        }), app.util.request({
            url: "entry/wxapp/detail",
            method: "POST",
            data: {
                m: "baobiao_4s",
                id: t.id
            },
            success: function(t) {
                var a = t.data.data;
                e.setData({
                    detail: a,
                    swiper_count: a.images ? a.images.length : 0
                }), wx.setNavigationBarTitle({
                    title: a.name + " " + a.model
                }), a.detail || e.setData({
                    curr_tab: 2
                }), WxParse.wxParse("content", "html", a.detail, e, 20);
            }
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: this.data.detail.name + " " + this.data.detail.model
        };
    },
    btnToggle: function() {
        this.setData({
            btn_show: !this.data.btn_show
        });
    },
    telToggle: function() {
        this.setData({
            tel_show: !this.data.tel_show
        });
    },
    changeTab: function(t) {
        var a = t.currentTarget.dataset.tab;
        this.setData({
            curr_tab: a
        });
    },
    callPhone: function(t) {
        var a = t.currentTarget.dataset.phone;
        common.callPhone(a);
    },
    toLocation: function() {
        common.toLocation(this);
    },
    goHome: function() {
        wx.reLaunch({
            url: "../index/index"
        });
    },
    swiperChange: function(t) {
        console.log(t), this.setData({
            swiper_current: t.detail.current + 1
        });
    }
});