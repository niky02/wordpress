function _toConsumableArray(t) {
    if (Array.isArray(t)) {
        for (var a = 0, e = Array(t.length); a < t.length; a++) e[a] = t[a];
        return e;
    }
    return Array.from(t);
}

var app = getApp();

Page({
    data: {
        top: {
            brand: {
                defaultText: "全部品牌",
                text: "全部品牌",
                current: !1
            },
            sort: {
                defaultText: "默认排序",
                text: "默认排序",
                current: !1
            }
        },
        filter: {
            category: 0,
            sort: 0,
            page: 1
        },
        more: !0,
        car: []
    },
    onLoad: function(t) {
        app.template.footer(this);
        var e = this, a = t.category;
        if (a) {
            var r = t.text, o = this.data.filter, n = this.data.top;
            o.category = a, n.brand.text = r, this.setData({
                filter: o,
                top: n
            });
        }
        this.requestList(), app.getGlobalData(function(t) {
            e.setData({
                info: t.info
            });
        }), app.util.request({
            url: "entry/wxapp/category",
            method: "POST",
            data: {
                m: "baobiao_4s"
            },
            success: function(t) {
                var a = t.data.data;
                e.setData({
                    category: a
                });
            }
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {
        this.requestList();
    },
    onReachBottom: function() {
        this.data.more && this.requestList();
    },
    onShareAppMessage: function() {},
    filterChange: function(t) {
        var a = t.currentTarget.dataset, e = this.data.filter, r = this.data.top;
        console.log(a), "sort" == a.type ? (e.sort = a.index, r.sort.text = a.text) : (e.category = a.pid, 
        r.brand.text = a.text), e.page = 1, this.setData({
            filter: e,
            top: r,
            more: !0,
            car: []
        }), this.requestList(), wx.pageScrollTo({
            scrollTop: 0
        }), this.hidePanel();
    },
    requestList: function() {
        var r = this, t = r.data.filter;
        t.m = "baobiao_4s", app.util.request({
            url: "entry/wxapp/car",
            method: "POST",
            data: t,
            success: function(t) {
                var a = t.data.data;
                if (0 == a.length) 0 != r.data.car.length && wx.showToast({
                    title: "已经到底了~",
                    icon: "success",
                    duration: 2e3
                }), r.setData({
                    more: !1
                }); else {
                    var e = r.data.filter;
                    e.page = e.page + 1, r.setData({
                        car: [].concat(_toConsumableArray(r.data.car), _toConsumableArray(a)),
                        filter: e
                    });
                }
            }
        });
    },
    popShow: function(t) {
        console.log(t.currentTarget.dataset.type);
        var a = !0, e = this.data.top;
        for (var r in e) r == t.currentTarget.dataset.type ? (e[r].current = !e[r].current, 
        a = !e[r].current) : e[r].current = !1;
        this.setData({
            top: e,
            carscrollis: a
        });
    },
    hidePanel: function(t) {
        var a = this.data.top;
        for (var e in a) a[e].current = !1;
        console.log(t), t && !t.type && (a.brand.current = !0), this.setData({
            top: a
        });
    }
});