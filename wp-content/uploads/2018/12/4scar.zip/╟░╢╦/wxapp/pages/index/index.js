var app = getApp(), common = require("../../utils/common.js");

Page({
    data: {},
    onLoad: function(t) {
        app.template.footer(this);
        var e = this;
        app.getGlobalData(function(t) {
            e.setData({
                info: t.info
            }), wx.setNavigationBarTitle({
                title: e.data.info.name
            }), app.util.request({
                url: "entry/wxapp/index",
                method: "POST",
                data: {
                    m: "baobiao_4s"
                },
                success: function(t) {
                    var a = t.data.data;
                    e.setData({
                        swiper: a.swiper,
                        category: a.category,
                        car: a.car,
                        photo: a.photo,
                        news: a.news
                    });
                }
            });
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {
        wx.clearStorage(), app.template.footer(this);
        var e = this;
        app.getGlobalData(function(t) {
            e.setData({
                info: t.info
            }), wx.setNavigationBarTitle({
                title: e.data.info.name
            }), app.util.request({
                url: "entry/wxapp/index",
                method: "POST",
                data: {
                    m: "baobiao_4s"
                },
                success: function(t) {
                    var a = t.data.data;
                    e.setData({
                        swiper: a.swiper,
                        category: a.category,
                        car: a.car,
                        photo: a.photo
                    }), wx.stopPullDownRefresh();
                }
            });
        });
    },
    onReachBottom: function() {},
    onShareAppMessage: function() {},
    toLocation: function() {
        common.toLocation(this);
    },
    imagePreview: function(t) {
        var a = t.currentTarget.dataset.index;
        wx.previewImage({
            current: this.data.photo[a].images[0],
            urls: this.data.photo[a].images
        });
    },
    swiperClick: function(t) {
        var a = t.currentTarget.dataset.index, e = this.data.swiper[a];
        1 == e.type ? wx.navigateTo({
            url: "../website/website?url=" + encodeURIComponent(e.meta)
        }) : 2 == e.type && wx.navigateTo({
            url: "../car/detail?id=" + e.meta
        });
    }
});