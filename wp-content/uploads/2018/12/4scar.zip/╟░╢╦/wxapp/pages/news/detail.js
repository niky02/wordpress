var app = getApp(), WxParse = require("../../utils/wxParse/wxParse.js");

Page({
    data: {
        detail: {}
    },
    onLoad: function(a) {
        var t = this;
        app.util.request({
            url: "entry/wxapp/newsDetail",
            method: "POST",
            data: {
                id: a.id,
                m: "baobiao_4s"
            },
            success: function(a) {
                console.log(a.data.data), t.setData({
                    detail: a.data.data
                }), WxParse.wxParse("content", "html", a.data.data.body, t, 15), wx.setNavigationBarTitle({
                    title: a.data.data.title
                });
            }
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});