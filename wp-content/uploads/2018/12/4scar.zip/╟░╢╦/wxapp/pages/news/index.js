function _toConsumableArray(a) {
    if (Array.isArray(a)) {
        for (var t = 0, e = Array(a.length); t < a.length; t++) e[t] = a[t];
        return e;
    }
    return Array.from(a);
}

var app = getApp();

Page({
    data: {
        news: [],
        isloading: !1,
        more: !0,
        page: 1,
        category: {},
        category_index: 0
    },
    onLoad: function(a) {
        app.template.footer(this);
        var e = this;
        app.getGlobalData(function(a) {
            e.setData({
                info: a.info
            });
        }), app.util.request({
            url: "entry/wxapp/node",
            method: "POST",
            data: {
                m: "baobiao_4s"
            },
            success: function(a) {
                var t = a.data.data;
                t = [ {
                    id: 0,
                    name: "全部"
                } ].concat(_toConsumableArray(t)), e.setData({
                    category: t
                });
            }
        }), this.RequestApi();
    },
    RequestApi: function() {
        var e = this;
        app.util.request({
            url: "entry/wxapp/news",
            method: "POST",
            data: {
                page: e.data.page,
                category: e.data.category_index,
                m: "baobiao_4s"
            },
            success: function(a) {
                console.log(a.data.data);
                var t = a.data.data;
                0 == t.length ? (wx.showToast({
                    title: "已经到底了~",
                    icon: "success",
                    duration: 2e3
                }), e.setData({
                    more: !1
                })) : e.setData({
                    news: [].concat(_toConsumableArray(e.data.news), _toConsumableArray(t)),
                    page: ++e.data.page
                });
            }
        });
    },
    onCategoryChange: function(a) {
        if (this.data.category_index == a.currentTarget.dataset.classid) return !1;
        wx.pageScrollTo({
            scrollTop: 0
        }), this.setData({
            category_index: a.currentTarget.dataset.classid,
            news: [],
            page: 1,
            more: !0
        }), this.RequestApi();
    },
    onReachBottom: function(a) {
        this.data.more && this.RequestApi();
    },
    onPullDownRefresh: function() {
        wx.stopPullDownRefresh();
        this.setData({
            page: 1,
            news: [],
            more: !0
        }), this.RequestApi();
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onShareAppMessage: function() {}
});