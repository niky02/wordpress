var app = getApp();

Page({
    data: {},
    onLoad: function(e) {
        app.template.footer(this);
        var o = this, n = e.message;
        this.setData({
            message: n
        }), app.getGlobalData(function(e) {
            o.setData({
                info: e.info
            });
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {},
    formSubmit: function(e) {
        var o = {
            phone: e.detail.value.phone,
            name: e.detail.value.name,
            message: e.detail.value.message,
            m: "baobiao_4s"
        };
        console.log(o), o.phone && o.name ? app.util.request({
            url: "entry/wxapp/order",
            method: "POST",
            data: o,
            success: function(e) {
                wx.showModal({
                    content: e.data.message,
                    showCancel: !1,
                    confirmText: "确定"
                });
            }
        }) : wx.showModal({
            content: "请填写完整后再提交哦~",
            showCancel: !1,
            confirmText: "知道了"
        });
    }
});