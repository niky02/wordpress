function _toConsumableArray(t) {
    if (Array.isArray(t)) {
        for (var a = 0, o = Array(t.length); a < t.length; a++) o[a] = t[a];
        return o;
    }
    return Array.from(t);
}

var app = getApp();

Page({
    data: {
        page: 1,
        more: !0,
        photo: []
    },
    onLoad: function(t) {
        app.getGlobalData(function(t) {
            var a = t.info.photo_text;
            "交车照片" != a && wx.setNavigationBarTitle({
                title: a
            });
        }), this.listRequest();
    },
    listRequest: function() {
        var o = this;
        app.util.request({
            url: "entry/wxapp/photo",
            method: "POST",
            data: {
                m: "baobiao_4s",
                page: o.data.page
            },
            success: function(t) {
                var a = t.data.data;
                0 == a.length ? (0 != o.data.photo.length && wx.showToast({
                    title: "已经到底了~",
                    icon: "success",
                    duration: 2e3
                }), o.setData({
                    more: !1
                })) : o.setData({
                    photo: [].concat(_toConsumableArray(o.data.photo), _toConsumableArray(a)),
                    page: ++o.data.page
                });
            }
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {
        this.data.more && this.listRequest();
    },
    onShareAppMessage: function() {},
    imagePreview: function(t) {
        var a = t.currentTarget.dataset.index;
        wx.previewImage({
            current: this.data.photo[a].images[0],
            urls: this.data.photo[a].images
        });
    }
});