var template = {
    footer: function(e) {
        var a = getApp(), o = e.__route__;
        console.log(o), console.log(a.tabBar), a.getGlobalData(function(t) {
            1 == t.info.news_section && 5 == a.tabBar.list.length && a.tabBar.list.splice(1, 1), 
            t.info.shop_text && (a.tabBar.list[4].text = t.info.shop_text), e.setData({
                tabBar: a.tabBar,
                curr_route: "/" + o
            });
        });
    }
};

module.exports = template;