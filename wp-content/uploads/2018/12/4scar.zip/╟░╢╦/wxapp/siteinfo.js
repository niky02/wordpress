module.exports = {
    name: "4s汽车小程序",
    uniacid: "1",
    acid: "1",
    multiid: "0",
    version: "7.1.0",
    siteroot: "https://你的域名/app/index.php",
    design_method: "3"
};