function e(e, a, r) {
    return a in e ? Object.defineProperty(e, a, {
        value: r,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : e[a] = r, e;
}

function a() {
    i(), r(), t(), n(), s(d.checkBoxS), d.total = d.sybx + d.jqx + d.paizhao_fee + d.ccs + d.gzs + d.price, 
    d.byhf = d.gzs + d.ccs + d.paizhao_fee + d.jqx;
    var e = 12 * d.years, a = .0485;
    1 == d.years ? a = d.lv1 : 2 == d.years ? a = d.lv2 : 3 == d.years ? a = d.lv3 : 4 == d.years ? a = d.lv4 : 5 == d.years && (a = d.lv5);
    var c = d.sybx + d.jqx + d.paizhao_fee + d.ccs + d.gzs, l = parseInt(d.price * d.shoufu + c), o = parseInt(d.price * (1 - d.shoufu)), p = Math.floor(o * a * d.years), u = Math.round((o + p) / e);
    d.dtotal = d.total + p, y.gzs = M(d.gzs), y.ccs = M(d.ccs), y.jqx = M(d.jqx), y.sybx = M(d.sybx), 
    y.paizhao_fee = M(d.paizhao_fee), y.total = M(d.total), y.dtotal = M(d.dtotal), 
    y.yprice = Math.round(d.price / 100) / 100, y.years = d.years, y.shoufu = d.shoufu, 
    y.firstPay = M(l), y.lx = M(p), y.yg = M(u), y.byhf = M(d.byhf);
}

function r() {
    var e = d.displacement, a = b[e].Tax, r = Math.ceil(a);
    return d.ccs = r;
}

function t() {
    return y.xfs = 1521e3 <= y.price ? x(y.price / 11.7) : 0, console.log(y.xfs), y.xfs;
}

function i() {
    var e = d.displacement, a = d.price / 1.17 * .1, r = Math.round(a);
    return 0 < e && parseFloat(e) <= 2 && (r = Math.round(d.price / 1.17 * .1 * .75)), 
    d.gzs = r;
}

function n() {
    if (0 != d.price) {
        var e = d.seat, a = parseFloat(e);
        return d.jqx = a, d.jqx;
    }
}

function s(e) {
    var a = 0, r = c();
    y.chkTPL = M(parseFloat(x(r))), a += parseFloat(x(r));
    var t = o();
    y.calcCarDamage1 = M(parseFloat(x(t))), a += x(t);
    var i = M(Math.round(.2 * (x(r) + x(t))));
    y.calcAbatement = M(parseFloat(x(i))), a += x(i);
    var n = p();
    y.calcCarTheft1 = M(parseFloat(x(n))), a += x(n);
    var s = u();
    y.calcBreakageOfGlass1 = M(parseFloat(x(s))), a += x(s);
    var D = f();
    y.calcSelfignite1 = M(parseFloat(x(D))), a += x(D);
    var g = v();
    y.calcCarEngineDamage1 = M(parseFloat(x(g))), a += x(g);
    var b = h();
    y.calcCarDamageDW1 = M(parseFloat(x(b))), a += x(b);
    var F = m();
    y.calcPassenger1 = M(parseFloat(x(F))), a += x(F);
    var z = l();
    if (y.calcWuguozeren = M(parseFloat(x(z))), a += x(z), e) for (var L in a = 0, e) e[L] && (a += x(y[L]));
    var T = Math.round(a);
    return d.sybx = T;
}

function c() {
    var e = d.hideseat < 6 ? "0" : "1", a = d.tplLevel;
    if (0 == e) {
        if (0 == a) return 710;
        if (1 == a) return 1026;
        if (2 == a) return 1270;
        if (3 == a) return 1721;
        if (4 == a) return 2242;
    } else if (1 == e) {
        if (0 == a) return 659;
        if (1 == a) return 928;
        if (2 == a) return 1131;
        if (3 == a) return 1507;
        if (4 == a) return 1963;
    }
}

function l() {
    return .2 * c();
}

function o() {
    var e = .0095, a = 285, r = d.hideseat;
    return 6 <= r && r < 10 ? (e = .009, a = 342) : 10 <= r && r < 20 ? (e = .0095, 
    a = 342) : 20 <= r && (e = .0095, a = 357), Math.round(d.price * e + a);
}

function p() {
    return "1150" == d.seat ? Math.round(.0044 * d.price + 140) : Math.round(.0049 * d.price + 120);
}

function u() {
    return d.mode_int < 2 ? Math.round(.0015 * d.price) : Math.round(.0025 * d.price);
}

function f() {
    return Math.round(.0015 * d.price);
}

function v() {
    var e = .05 * x(o());
    return Math.round(e);
}

function h() {
    var e = d.dwindex, a = d.price;
    if (a < 3e5) {
        if (0 == e) return "400";
        if (1 == e) return "570";
        if (2 == e) return "760";
        if (3 == e) return "1140";
    } else if (5e5 < a) {
        if (0 == e) return "850";
        if (1 == e) return "1100";
        if (2 == e) return "1500";
        if (3 == e) return "2250";
    } else {
        if (0 == e) return "585";
        if (1 == e) return "900";
        if (2 == e) return "1170";
        if (3 == e) return "1780";
    }
}

function m() {
    return 50 * d.people;
}

function x(e) {
    if (e) return e = e.toString().replace(/\,/g, ""), parseInt(e);
}

function M(e) {
    e = e.toString().replace(/\$|\,/g, ""), isNaN(e) && (e = "0");
    var a = e == (e = Math.abs(e));
    e = Math.floor(100 * e + .50000000001), e = Math.floor(e / 100).toString();
    for (var r = 0; r < Math.floor((e.length - (1 + r)) / 3); r++) e = e.substring(0, e.length - (4 * r + 3)) + "," + e.substring(e.length - (4 * r + 3));
    return (a ? "" : "-") + e;
}

function g(e) {
    return e = e.toString().replace(/\$|\,/g, ""), isNaN(e) && (e = "0"), (e == (e = Math.abs(e)) ? "" : "-") + (e = Math.floor(1e4 * e + .50000000001).toString());
}

var D, d = (e(D = {
    price: 0,
    mprice: 0,
    displacement: 0,
    seat: 0,
    hideseat: 0,
    paizhao_fee: 0,
    shoufu: .3,
    years: 1,
    lv1: .0485,
    lv2: .0525,
    lv3: .0525,
    lv4: .0525,
    lv5: .0525,
    gzs: 0,
    ccs: 0,
    jqx: 0,
    sybx: 0
}, "paizhao_fee", 0), e(D, "total", 0), e(D, "dtotal", 0), D), y = {
    gzs: "",
    xfs: "",
    ccs: "",
    jqx: "",
    sybx: "",
    paizhao_fee: "",
    total: "",
    dtotal: "",
    yprice: "",
    shoufu: .3,
    years: 1,
    firstPay: "",
    lx: "",
    yg: "",
    byhf: ""
}, b = {
    0: {
        Level: 0,
        MinDisplacement: 0,
        MaxDisplacement: 0,
        DisplacementDescription: "平行进口 排量参数空",
        Tax: 480
    },
    1: {
        Level: 1,
        MinDisplacement: 0,
        MaxDisplacement: 1,
        DisplacementDescription: "1.0L(含)以下",
        Tax: 300
    },
    2: {
        Level: 2,
        MinDisplacement: 1,
        MaxDisplacement: 1.6,
        DisplacementDescription: "1.0-1.6L(含)",
        Tax: 420,
        IsDefault: !0
    },
    3: {
        Level: 3,
        MinDisplacement: 1.6,
        MaxDisplacement: 2,
        DisplacementDescription: "1.6-2.0L(含)",
        Tax: 480
    },
    4: {
        Level: 4,
        MinDisplacement: 2,
        MaxDisplacement: 2.5,
        DisplacementDescription: "2.0-2.5L(含)",
        Tax: 900
    },
    5: {
        Level: 5,
        MinDisplacement: 2.5,
        MaxDisplacement: 3,
        DisplacementDescription: "2.5-3.0L(含)",
        Tax: 1920
    },
    6: {
        Level: 6,
        MinDisplacement: 3,
        MaxDisplacement: 4,
        DisplacementDescription: "3.0-4.0L(含)",
        Tax: 3480
    },
    7: {
        Level: 7,
        MinDisplacement: 4,
        MaxDisplacement: Number.MAX_VALUE,
        DisplacementDescription: "4.0L以上",
        Tax: 5280
    }
};

module.exports = {
    calc: function(e) {
        "string" == typeof (d = Object.assign(d, e)).price && (d.price = x(g(d.price))), 
        "string" == typeof d.mprice && (d.mprice = x(g(d.mprice))), d.lv1 = parseFloat(d.lv1), 
        d.lv2 = parseFloat(d.lv2), d.lv3 = parseFloat(d.lv3), d.lv4 = parseFloat(d.lv4), 
        d.lv5 = parseFloat(d.lv5), d.displacement = parseFloat(d.displacement), d.seat = parseFloat(d.seat), 
        d.hideseat = parseFloat(d.hideseat), d.paizhao_fee = parseFloat(d.paizhao_fee), 
        0 == d.price && 0 < d.mprice && (d.price = d.mprice), a();
    },
    config: d,
    data: y,
    calcBusinessTotal: s
};