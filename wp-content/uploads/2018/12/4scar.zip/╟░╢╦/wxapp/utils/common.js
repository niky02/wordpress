function callPhone(o) {
    wx.makePhoneCall({
        phoneNumber: o
    });
}

function toLocation(o) {
    wx.openLocation({
        latitude: parseFloat(o.data.info.latitude),
        longitude: parseFloat(o.data.info.longitude),
        name: o.data.info.name,
        address: o.data.info.address,
        scale: 28
    });
}

module.exports = {
    callPhone: callPhone,
    toLocation: toLocation
};