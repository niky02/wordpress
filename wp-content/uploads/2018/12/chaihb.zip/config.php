<?php
$appid='wxa9e40dadf0647438';
$appsecret='00ac9949923916a97c2416ec5b70f4e3';
//后退跳转
$url_back = 'http://qq.com';
//分享跳转
$url = 'https://360.com';
//好友分享1
$app_title = '中秋快乐！拆个红包再走。';
$app_link = 'http://wxyvip.cc/hb1005/';
$app_desc = '快乐快乐快乐！！！';
$app_img = 'http://wxyvip.cc/hb1005/assets/u=902823362,1960090247&fm=27&gp=0.jpg';
//好友分享2
$app_title2 = '如何一个小时赚2000快？';
$app_link2 = 'http://wxyvip.cc/hb1005/';
$app_desc2 = '赚赚赚！！！！';
$app_img2 = 'http://wxyvip.cc/hb1005/assets/u=1273164776,1578493823&fm=27&gp=0.jpg';
//朋友圈分享1
$timeline_title = '12 秒';
$timeline_link = 'http://wxyvip.cc/hb1005/';
$timeline_img = 'http://wxyvip.cc/hb1005/assets/460.jpg';
//朋友圈分享2
$timeline_title2 = '20岁美女在床上玩这个，一夜居然成了白富美！';
$timeline_link2 = 'http://wxyvip.cc/hb1005/';
$timeline_img2 = 'http://wxyvip.cc/hb1005/assets/u=2771834338,2560424674&fm=27&gp=0.jpg';
//广告配置

?>
        
        