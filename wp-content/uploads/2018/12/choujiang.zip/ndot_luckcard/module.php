<?php
/**
 * ndot_test1模块定义
 *
 * @author yw0421
 * @url 
 */
defined('IN_IA') or exit('Access Denied');

class Ndot_luckcardModule extends WeModule {
    public function doMobileIndex() {
        echo $this->createMobileUrl('home');
    }
    public function doMobileHome() {
        //上面doMobileIndex()生成的链接会进入到这里
    }

}