<?php
$sql="CREATE TABLE IF NOT EXISTS `ims_zzz_reply` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `rid` int(10) unsigned NOT NULL COMMENT '规则ID',
  `uniacid` int(10) unsigned NOT NULL,
  `picture` varchar(100) NOT NULL COMMENT '活动图片',
  `description` text NOT NULL COMMENT '活动描述',
  `rule` text NOT NULL COMMENT '活动描述',
  `periodlottery` smallint(10) unsigned NOT NULL DEFAULT '1' COMMENT '0为无周期',
  `maxlottery` tinyint(3) unsigned NOT NULL COMMENT '系统每天赠送次数',
  `guzhuurl` varchar(255) NOT NULL DEFAULT '',
  `prace_times` int(10) NOT NULL DEFAULT '100',
  `title` varchar(100) NOT NULL DEFAULT '',
  `bgurl` varchar(255) NOT NULL DEFAULT '',
  `bigunit` varchar(50) NOT NULL DEFAULT '',
  `smallunit` varchar(50) NOT NULL DEFAULT '',
  `start_time` int(10) NOT NULL DEFAULT '0',
  `end_time` int(10) NOT NULL DEFAULT '1600000000',
  `sharevalue` int(10) unsigned NOT NULL COMMENT '分享赠送体力',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
CREATE TABLE IF NOT EXISTS `ims_zzz_share` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `rid` int(10) unsigned NOT NULL COMMENT '规则ID',
  `fanid` int(10) unsigned NOT NULL COMMENT '粉丝ID',
  `sharefid` int(10) unsigned NOT NULL COMMENT '分享者ID',
  PRIMARY KEY (`id`),
  KEY `rid` (`rid`,`fanid`,`sharefid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
CREATE TABLE IF NOT EXISTS `ims_zzz_user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `rid` int(10) NOT NULL DEFAULT '0',
  `fanid` int(10) unsigned NOT NULL COMMENT '粉丝ID',
  `count` int(10) NOT NULL DEFAULT '0',
  `points` int(10) NOT NULL DEFAULT '0',
  `friendcount` int(10) NOT NULL DEFAULT '0',
  `createtime` int(10) unsigned NOT NULL COMMENT '日期',
  `sharevalue` int(10) unsigned NOT NULL COMMENT '分享获得体力',
  PRIMARY KEY (`id`),
  KEY `idx_fanid` (`fanid`),
  KEY `idx_rid` (`rid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
CREATE TABLE IF NOT EXISTS `ims_zzz_winner` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `rid` int(10) unsigned NOT NULL DEFAULT '0',
  `point` int(10) unsigned NOT NULL DEFAULT '0',
  `fanid` int(10) unsigned NOT NULL COMMENT '粉丝ID',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0未领奖，1不需要领奖，2已领奖',
  `createtime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '获奖日期',
  PRIMARY KEY (`id`),
  KEY `idx_fanid` (`fanid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
";
pdo_run($sql);
if(!pdo_fieldexists('zzz_reply',  'id')) {
	pdo_query("ALTER TABLE ".tablename('zzz_reply')." ADD `id` int(10) unsigned NOT NULL AUTO_INCREMENT;");
}
if(!pdo_fieldexists('zzz_reply',  'rid')) {
	pdo_query("ALTER TABLE ".tablename('zzz_reply')." ADD `rid` int(10) unsigned NOT NULL COMMENT '规则ID';");
}
if(!pdo_fieldexists('zzz_reply',  'uniacid')) {
	pdo_query("ALTER TABLE ".tablename('zzz_reply')." ADD `uniacid` int(10) unsigned NOT NULL;");
}
if(!pdo_fieldexists('zzz_reply',  'picture')) {
	pdo_query("ALTER TABLE ".tablename('zzz_reply')." ADD `picture` varchar(100) NOT NULL COMMENT '活动图片';");
}
if(!pdo_fieldexists('zzz_reply',  'description')) {
	pdo_query("ALTER TABLE ".tablename('zzz_reply')." ADD `description` text NOT NULL COMMENT '活动描述';");
}
if(!pdo_fieldexists('zzz_reply',  'rule')) {
	pdo_query("ALTER TABLE ".tablename('zzz_reply')." ADD `rule` text NOT NULL COMMENT '活动描述';");
}
if(!pdo_fieldexists('zzz_reply',  'periodlottery')) {
	pdo_query("ALTER TABLE ".tablename('zzz_reply')." ADD `periodlottery` smallint(10) unsigned NOT NULL DEFAULT '1' COMMENT '0为无周期';");
}
if(!pdo_fieldexists('zzz_reply',  'maxlottery')) {
	pdo_query("ALTER TABLE ".tablename('zzz_reply')." ADD `maxlottery` tinyint(3) unsigned NOT NULL COMMENT '系统每天赠送次数';");
}
if(!pdo_fieldexists('zzz_reply',  'guzhuurl')) {
	pdo_query("ALTER TABLE ".tablename('zzz_reply')." ADD `guzhuurl` varchar(255) NOT NULL DEFAULT '';");
}
if(!pdo_fieldexists('zzz_reply',  'prace_times')) {
	pdo_query("ALTER TABLE ".tablename('zzz_reply')." ADD `prace_times` int(10) NOT NULL DEFAULT '100';");
}
if(!pdo_fieldexists('zzz_reply',  'title')) {
	pdo_query("ALTER TABLE ".tablename('zzz_reply')." ADD `title` varchar(100) NOT NULL DEFAULT '';");
}
if(!pdo_fieldexists('zzz_reply',  'bgurl')) {
	pdo_query("ALTER TABLE ".tablename('zzz_reply')." ADD `bgurl` varchar(255) NOT NULL DEFAULT '';");
}
if(!pdo_fieldexists('zzz_reply',  'bigunit')) {
	pdo_query("ALTER TABLE ".tablename('zzz_reply')." ADD `bigunit` varchar(50) NOT NULL DEFAULT '';");
}
if(!pdo_fieldexists('zzz_reply',  'smallunit')) {
	pdo_query("ALTER TABLE ".tablename('zzz_reply')." ADD `smallunit` varchar(50) NOT NULL DEFAULT '';");
}
if(!pdo_fieldexists('zzz_reply',  'start_time')) {
	pdo_query("ALTER TABLE ".tablename('zzz_reply')." ADD `start_time` int(10) NOT NULL DEFAULT '0';");
}
if(!pdo_fieldexists('zzz_reply',  'end_time')) {
	pdo_query("ALTER TABLE ".tablename('zzz_reply')." ADD `end_time` int(10) NOT NULL DEFAULT '1600000000';");
}
if(!pdo_fieldexists('zzz_reply',  'sharevalue')) {
	pdo_query("ALTER TABLE ".tablename('zzz_reply')." ADD `sharevalue` int(10) unsigned NOT NULL COMMENT '分享赠送体力';");
}
if(!pdo_fieldexists('zzz_share',  'id')) {
	pdo_query("ALTER TABLE ".tablename('zzz_share')." ADD `id` int(10) unsigned NOT NULL AUTO_INCREMENT;");
}
if(!pdo_fieldexists('zzz_share',  'rid')) {
	pdo_query("ALTER TABLE ".tablename('zzz_share')." ADD `rid` int(10) unsigned NOT NULL COMMENT '规则ID';");
}
if(!pdo_fieldexists('zzz_share',  'fanid')) {
	pdo_query("ALTER TABLE ".tablename('zzz_share')." ADD `fanid` int(10) unsigned NOT NULL COMMENT '粉丝ID';");
}
if(!pdo_fieldexists('zzz_share',  'sharefid')) {
	pdo_query("ALTER TABLE ".tablename('zzz_share')." ADD `sharefid` int(10) unsigned NOT NULL COMMENT '分享者ID';");
}
if(!pdo_indexexists('zzz_share',  'rid')) {
	pdo_query("ALTER TABLE ".tablename('zzz_share')." ADD KEY `rid` (`rid`,`fanid`,`sharefid`);");
}
if(!pdo_fieldexists('zzz_user',  'id')) {
	pdo_query("ALTER TABLE ".tablename('zzz_user')." ADD `id` int(10) unsigned NOT NULL AUTO_INCREMENT;");
}
if(!pdo_fieldexists('zzz_user',  'rid')) {
	pdo_query("ALTER TABLE ".tablename('zzz_user')." ADD `rid` int(10) NOT NULL DEFAULT '0';");
}
if(!pdo_fieldexists('zzz_user',  'fanid')) {
	pdo_query("ALTER TABLE ".tablename('zzz_user')." ADD `fanid` int(10) unsigned NOT NULL COMMENT '粉丝ID';");
}
if(!pdo_fieldexists('zzz_user',  'count')) {
	pdo_query("ALTER TABLE ".tablename('zzz_user')." ADD `count` int(10) NOT NULL DEFAULT '0';");
}
if(!pdo_fieldexists('zzz_user',  'points')) {
	pdo_query("ALTER TABLE ".tablename('zzz_user')." ADD `points` int(10) NOT NULL DEFAULT '0';");
}
if(!pdo_fieldexists('zzz_user',  'friendcount')) {
	pdo_query("ALTER TABLE ".tablename('zzz_user')." ADD `friendcount` int(10) NOT NULL DEFAULT '0';");
}
if(!pdo_fieldexists('zzz_user',  'createtime')) {
	pdo_query("ALTER TABLE ".tablename('zzz_user')." ADD `createtime` int(10) unsigned NOT NULL COMMENT '日期';");
}
if(!pdo_fieldexists('zzz_user',  'sharevalue')) {
	pdo_query("ALTER TABLE ".tablename('zzz_user')." ADD `sharevalue` int(10) unsigned NOT NULL COMMENT '分享获得体力';");
}
if(!pdo_indexexists('zzz_user',  'idx_fanid')) {
	pdo_query("ALTER TABLE ".tablename('zzz_user')." ADD KEY `idx_fanid` (`fanid`);");
}
if(!pdo_indexexists('zzz_user',  'idx_rid')) {
	pdo_query("ALTER TABLE ".tablename('zzz_user')." ADD KEY `idx_rid` (`rid`);");
}
if(!pdo_fieldexists('zzz_winner',  'id')) {
	pdo_query("ALTER TABLE ".tablename('zzz_winner')." ADD `id` int(10) unsigned NOT NULL AUTO_INCREMENT;");
}
if(!pdo_fieldexists('zzz_winner',  'rid')) {
	pdo_query("ALTER TABLE ".tablename('zzz_winner')." ADD `rid` int(10) unsigned NOT NULL DEFAULT '0';");
}
if(!pdo_fieldexists('zzz_winner',  'point')) {
	pdo_query("ALTER TABLE ".tablename('zzz_winner')." ADD `point` int(10) unsigned NOT NULL DEFAULT '0';");
}
if(!pdo_fieldexists('zzz_winner',  'fanid')) {
	pdo_query("ALTER TABLE ".tablename('zzz_winner')." ADD `fanid` int(10) unsigned NOT NULL COMMENT '粉丝ID';");
}
if(!pdo_fieldexists('zzz_winner',  'status')) {
	pdo_query("ALTER TABLE ".tablename('zzz_winner')." ADD `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0未领奖，1不需要领奖，2已领奖';");
}
if(!pdo_fieldexists('zzz_winner',  'createtime')) {
	pdo_query("ALTER TABLE ".tablename('zzz_winner')." ADD `createtime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '获奖日期';");
}
if(!pdo_indexexists('zzz_winner',  'idx_fanid')) {
	pdo_query("ALTER TABLE ".tablename('zzz_winner')." ADD KEY `idx_fanid` (`fanid`);");
}

?>