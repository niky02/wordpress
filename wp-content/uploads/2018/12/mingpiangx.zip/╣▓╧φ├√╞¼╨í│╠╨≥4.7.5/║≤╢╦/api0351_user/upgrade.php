<?php
/**
 * [cloud System] Copyright (c) 2016  微擎商业互存框架 一键更新 授权 QQ: 32663267
 */
pdo_query("CREATE TABLE IF NOT EXISTS `ims_api_user_banner` (
`bid` int(11) NOT NULL AUTO_INCREMENT,
`sort` int(50),
`icon` varchar(255),
`title` varchar(255) NOT NULL,
`url` varchar(255),
`uniacid` int(11),
`btime` int(11),
`appid` varchar(150),
`appstatr` int(11) NOT NULL,
PRIMARY KEY (`bid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `ims_api_user_cdr` (
`rid` int(11) NOT NULL AUTO_INCREMENT,
`openid` varchar(255),
`xingming` varchar(150),
`weixin` varchar(150),
`youxiang` varchar(200),
`shouji` varchar(50),
`dianhua` varchar(50),
`zhiwei` varchar(100),
`gongsi` varchar(200),
`imgurl` varchar(255),
`uniacid` int(11) NOT NULL,
`time` int(11) NOT NULL,
PRIMARY KEY (`rid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `ims_api_user_class` (
`id` int(11) NOT NULL AUTO_INCREMENT,
`sort` int(50),
`icon` varchar(255),
`csname` varchar(255) NOT NULL,
`content` varchar(255),
`display` varchar(11) NOT NULL,
`uniacid` int(11),
`recomme` int(11),
`time` int(11),
PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `ims_api_user_collection` (
`oid` int(11) NOT NULL AUTO_INCREMENT,
`openid` varchar(255),
`uid` int(11),
`tid` int(11),
`uniacid` int(11),
`otime` int(11),
PRIMARY KEY (`oid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `ims_api_user_config` (
`key` varchar(200) NOT NULL,
`value` text NOT NULL,
`num` int(11) NOT NULL AUTO_INCREMENT,
PRIMARY KEY (`num`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `ims_api_user_formid` (
`fid` int(11) NOT NULL AUTO_INCREMENT,
`formid` varchar(255) NOT NULL,
`openid` varchar(255) NOT NULL,
`display` int(5) NOT NULL,
`uniacid` int(11),
`time` int(11) NOT NULL,
PRIMARY KEY (`fid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `ims_api_user_gz` (
`id` int(11) NOT NULL AUTO_INCREMENT,
`uid` int(11) NOT NULL,
`openid` varchar(255) NOT NULL,
`avatar` varchar(255) NOT NULL,
`uniacid` int(11),
`time` int(11) NOT NULL,
PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `ims_api_user_message` (
`mid` int(11) NOT NULL AUTO_INCREMENT,
`official` int(11),
`op` varchar(200),
`openid` varchar(200),
`nickname` varchar(150),
`avatar` varchar(255),
`content` varchar(255),
`display` int(11) NOT NULL,
`uniacid` int(11),
`addtime` int(11),
PRIMARY KEY (`mid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `ims_api_user_more` (
`id` int(11) NOT NULL AUTO_INCREMENT,
`cid` int(11) NOT NULL,
`indes` varchar(100),
`openid` varchar(200),
`avatarUrl` varchar(255),
`mobile` varchar(20),
`nickName` varchar(150),
`user_zc` varchar(150),
`user_gs` varchar(255),
`longitude` varchar(100),
`latitude` varchar(100),
`user_weixin` varchar(100),
`signature` text,
`uniacid` int(11) NOT NULL,
`user_vip` int(11) NOT NULL,
`paytime` int(11),
`overtime` int(11),
`display` int(11),
`shareurl` varchar(200),
`heat` int(11),
`report` int(11),
`uptime` int(11) NOT NULL,
`backgro` int(11) NOT NULL,
PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `ims_api_user_moto` (
`id` int(11) NOT NULL AUTO_INCREMENT,
`openid` varchar(255),
`imgUrl` varchar(255),
`uniacid` int(11),
`time` int(11),
PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `ims_api_user_news` (
`nid` int(11) NOT NULL AUTO_INCREMENT,
`title` varchar(255),
`content` text,
`uniacid` int(11),
`addtime` int(11),
PRIMARY KEY (`nid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `ims_api_user_opinion` (
`id` int(11) NOT NULL AUTO_INCREMENT,
`op` varchar(255),
`jid` int(11),
`openid` varchar(150),
`nickname` varchar(100),
`avatar` varchar(255),
`content` varchar(255) NOT NULL,
`uniacid` int(11),
`dis` int(11),
`time` int(11) NOT NULL,
PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `ims_api_user_pay` (
`plid` int(11) NOT NULL AUTO_INCREMENT,
`title` int(11),
`openid` varchar(40),
`username` varchar(180),
`uniontid` varchar(128),
`fee` decimal(10,2),
`status` tinyint(4),
`orderid` varchar(200),
`uniacid` int(11),
`pay_time` int(11),
PRIMARY KEY (`plid`),
KEY `idx_openid` (`openid`),
KEY `idx_tid` (`uniontid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `ims_api_user_reward` (
`rid` int(11) NOT NULL AUTO_INCREMENT,
`photo` varchar(255),
`title` varchar(200) NOT NULL,
`content` varchar(255),
`price` varchar(100),
`hotnum` int(11),
`uniacid` int(11),
`rtime` int(11),
PRIMARY KEY (`rid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `ims_api_user_reward_log` (
`lid` int(11) NOT NULL AUTO_INCREMENT,
`sid` int(11),
`img` varchar(255),
`title` varchar(255),
`orderid` varchar(255),
`openid` varchar(255) NOT NULL,
`username` varchar(255),
`price` varchar(100),
`sopenid` varchar(255),
`hotnum` varchar(100),
`uniacid` int(11),
`status` int(11),
`srtime` int(11),
PRIMARY KEY (`lid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `ims_api_user_shop` (
`id` int(11) NOT NULL AUTO_INCREMENT,
`openid` varchar(200),
`title` varchar(255),
`photo` varchar(255),
`content` text,
`uniacid` int(11),
`time` int(11),
PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `ims_api_user_trade` (
`did` int(11) NOT NULL AUTO_INCREMENT,
`dtitle` varchar(200) NOT NULL,
`dnumber` int(100),
`dcontent` varchar(255),
`x` varchar(255),
`y` varchar(255),
`openid` varchar(255),
`avatar` varchar(255),
`nickname` varchar(100),
`seid` int(11),
`dmoney` varchar(100),
`noliyou` varchar(255),
`display` int(11),
`pay` int(11),
`uniacid` int(11),
`sptime` int(11),
`dqtime` int(11),
`ctime` int(11),
PRIMARY KEY (`did`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

");
?>