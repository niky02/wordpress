<?php
/**
 * 个人名片模块小程序接口定义
 *
 * @author 阿 莫 之 家
 * @url http://www.0766city.com/
 */
defined('IN_IA') or exit('Access Denied');

use Qiniu\Auth;

class Api0351_userModuleWxapp extends WeModuleWxapp {
	
	
	const TABLE_A = 'api_user_gz';
	const TABLE_B = 'api_user_more';
	const TABLE_C = 'api_user_ms';
	const TABLE_D = 'api_user_opinion';
	const TABLE_E = 'api_user_class';
	const TABLE_F = 'api_user_pay';
	const TABLE_G = 'api_user_collection';
	const TABLE_H = 'api_user_formid';
	const TABLE_I = 'api_user_shop';
	const TABLE_J = 'api_user_message';
	const TABLE_K = 'api_user_trade';
	const TABLE_L = 'api_user_banner';
	const TABLE_M = 'api_user_trade';
	const TABLE_N = 'api_user_news';
	const TABLE_O = 'api_user_reward';
	const TABLE_P = 'api_user_reward_log';
	const TABLE_Q = 'api_user_cdr';
	const TABLE_R = 'api_user_moto';
	const TABLE_S = 'api_user_config';
	
	private $uid; 
	private $AppId; 
	private $gpc;
	private $w;
	private $setConfig;
	public function __construct() {
		global $_W;
		global $_GPC;
		$this->gpc = $_GPC;
		$this->w = $_W;
		$this->uniacid = $_W['uniacid'];
		$this->uid = $_W['openid'];
		$this->AppId = $_W['account']['key'];
		$this->setConfig = pdo_fetchall("SELECT * FROM ".tablename('api_user_config'));
	}
	
	public function doPageUserData(){
		global $_GPC, $_W;
		$getData = pdo_get(self::TABLE_B, array('openid' => $_GPC['openid'],'uniacid'   => $_W['uniacid']));
		if (empty($getData)) {
			$data = array(
				'openid' => $_GPC['openid'],
				'indes' => 0,
				'display' => 1,
				'uniacid'   => $_W['uniacid']
			);
			$data = pdo_insert(self::TABLE_B, $data);
			if (!empty($data)) {
				$message = '数据添加成功';
				$errno = 0;
				return $this->result($errno, $message, $data);
			}	
		}
	}
	
	public function doPagePostGz(){
		global $_GPC, $_W;
		$cid = $_GPC['cid'];
		$uniacid = $_W['uniacid'];
		if($cid == 1){
			$openid = $_GPC['openid'];
			$uid = $_GPC['uid'];
			if($uid == 0){
				exit();
			}
			$sql = "SELECT * FROM ".tablename('api_user_gz')." WHERE openid='$openid' AND uid='$uid' AND uniacid='$uniacid'";
			$dataMsn = pdo_fetchall($sql);
			$total = count($dataMsn);
			if($total > 0){
				$dataGz = array(
					'time' => $_W['timestamp']
				);
				$data = pdo_update(self::TABLE_A, $dataGz, array('openid' => $_GPC['openid'],'uid' => $_GPC['uid'],'uniacid'   => $_W['uniacid']));
				if (!empty($data)) {
					$message = '更新成功';
					$errno = 0;
					return $this->result($errno, $message, $data);
				}				
			}else{
				if($_GPC['avatar'] != '.._.._image/nouser.png' || $_GPC['avatar'] != 0 || $_GPC['avatar'] != 'undefined' || $_GPC['avatar'] != '' || $_GPC['openid'] != '' ){
					$dataGz = array(
						'avatar' => $_GPC['avatar'],
						'openid' => $_GPC['openid'],
						'uid' => $_GPC['uid'],
						'uniacid'   => $_W['uniacid'],
						'time' => $_W['timestamp']
					);
					$data = pdo_insert(self::TABLE_A, $dataGz);
					if (!empty($data)) {
						$message = '关注成功';
						$errno = 0;
						return $this->result($errno, $message, $data);
					}	
				}

			}
			
		}else if($cid == 2){
			$data = pdo_getall(self::TABLE_A,array('uid' => $_GPC['uid'],'uniacid'   => $_W['uniacid']),array() , '' , 'time DESC', array(1,8));
			foreach($data as $key=>$value){
				if($data[$key]['avatar'] == 'undefined' || $data[$key]['avatar'] == ''){
					$data[$key]['avatar'] = '../../image/nouser.png';
				}
	    	}
			$dataNum = pdo_getall(self::TABLE_A,array('uid' => $_GPC['uid'],'uniacid'   => $_W['uniacid']),array() , '' , '', array());
			$message = $dataNum;
			$errno = 0;
			return $this->result($errno, $message, $data);		
		}
		
	}
	
	public function doPageGetUser() {
		global $_GPC, $_W;
		$mod = $_GPC['mod'];
		if($mod == 1){
			$data = pdo_get(self::TABLE_B, array('openid' => $_GPC['openid'],'uniacid' => $_W['uniacid']));
			if(!$data || !$_GPC['openid']){
				$data['userMber'] = false;
				$newUserData = array(
					'openid' => $_GPC['openid'],
					'avatarUrl' => $_GPC['avatarUrl'],
					'uniacid'   => $_W['uniacid'],
				);
				pdo_insert(self::TABLE_B, $newUserData);
			}else{
				$data['userMber'] = true;	
			}
		}else if($mod == 2){
			$data = pdo_get(self::TABLE_B, array('id' => $_GPC['uid'],'uniacid' => $_W['uniacid']));	
		}
		
		$avatarUrl = explode("/",$this->cut_str($data['avatarUrl'],'/',0));
		if($avatarUrl[0] == 'images'){
			$data['avatarUrl'] = $_W['attachurl'].$data['avatarUrl'];
		}
		if($this->setConfig[1][value] == 2){
			$data['avatarUrl'] = $this->setConfig[6][value].$data['avatarUrl'];
		}
		$day = $_W['current_module']['config']['cycle'];
		$d = date("Y-m-d", $data['paytime']);
		$data['paytime'] = date("Y-m-d", strtotime("{$d} +{$day} day"));
		$data['overtime'] = date("Y-m-d", $data['overtime']);
		$errno = 0;
		$message = '名片数据请求成功';
		return $this->result($errno, $message, $data);
    }
	
	public function doPagePostAvatar() {
		global $_GPC, $_W;
		if (!empty($_FILES)) {
			$errno = 0;
			$message = '图片信息';
			load()->func('file');
			$imginfo = file_upload($_FILES['files'], 'image');
			$data = array(
				'avatarUrl' =>  $_W['attachurl'].$imginfo['path'],
			);
			$result = pdo_update(self::TABLE_B, $data, array('openid' => $_GPC['openid'],'uniacid' => $_W['uniacid']));
			if(!empty($result)){
				return $this->result($errno, $data, $result);
			}
    	}
    }
	
	
	public function doPageAddUser() {
		global $_GPC, $_W;
		
		$addData = pdo_get(self::TABLE_B, array('openid' => $_GPC['openid'],'uniacid'   => $_W['uniacid']), array('openid'));
		if(!empty($addData)){
			$ed_data = array(
				'cid' => $_GPC['sid'],
				'indes' => $_GPC['index'],
				'mobile' => $_GPC['mobile'],
				'nickname' => $_GPC['nickname'],
				'user_zc' => $_GPC['user_zc'],
				'user_weixin' => $_GPC['user_weixin'],
				'user_gs'   => $_GPC['user_gs'],
				'longitude'   => $_GPC['longitude'],
				'latitude'   => $_GPC['latitude'],
				'uniacid'   => $_W['uniacid'],
				'uptime' => $_W['timestamp'],
			);
			$data = pdo_update(self::TABLE_B, $ed_data, array('openid' => $_GPC['openid'],'uniacid'   => $_W['uniacid']));
			$message = '更新成功';
			$errno = 0;
			return $this->result($errno, $message, $data);
		}else{
			$ad_data = array(
				'cid' => $_GPC['sid'],
				'indes' => $_GPC['index'],
				'openid' => $_GPC['openid'],
				'avatarUrl' => $_GPC['avatarUrl'],
				'mobile' => $_GPC['mobile'],
				'nickname' => $_GPC['nickname'],
				'user_zc' => $_GPC['user_zc'],
				'user_gs'   => $_GPC['user_gs'],
				'user_weixin' => $_GPC['user_weixin'],
				'longitude'   => $_GPC['longitude'],
				'latitude'   => $_GPC['latitude'],
				'uniacid'   => $_W['uniacid'],
				'uptime' => $_W['timestamp'],
			);
			$data = pdo_insert(self::TABLE_B, $ad_data);
			if (!empty($data)) {
				$message = '提交成功';
				$errno = 0;
				return $this->result($errno, $message, $data);
			}
		}
    }
	
	
	public function doPageUserUp() {
		global $_GPC, $_W;
		$ed_data = array(
			'signature' => $_GPC['signature'],
		);
		$data = pdo_update(self::TABLE_B, $ed_data, array('openid' => $_GPC['openid'],'uniacid'   => $_W['uniacid']));
		$message = '更新成功';
		$errno = 0;
		return $this->result($errno, $message, $data);
		
    }
	
	
	public function doPageAddMsn(){
		global $_GPC, $_W;
		$data = array(
			'uid' => $_GPC['uid'],
			'fromid' => $_GPC['fromid'],
			'op' => $_GPC['op'],
			'openid' => $_GPC['openid'],
			'avatar' => $_GPC['avatar'],
			'nickname' => $_GPC['nickname'],
			'content' => $_GPC['content'],
			'uniacid'   => $_W['uniacid'],
			'addtime' => $_W['timestamp'],
		);
		$dataMsn = pdo_insert(self::TABLE_C, $data);
		if (!empty($dataMsn)) {
			//==========================================//
			$msStart = $_W['current_module']['config']['msStart'];
			if($msStart == 1){
				$account_api = WeAccount::create();
				$access_token = $account_api->getAccessToken();
				$touser = $_GPC['op'];
				$template_id = $_W['current_module']['config']['bok'];
				$findFid = pdo_getall(self::TABLE_H, array('openid' => $touser,'display' => 0), array() , '' , '' , array(1));
				$form_id = $findFid[0]['formid'];
				$keyword1 = date('Y/m/d H:i:s',time());
				$keyword2 = '您有新的问答消息，进入个人中心问答管理查看';
				$page = 'api0351_user/pages/user/user';
				/**************************/
				$this->SendMsg($access_token,$touser,$template_id,$form_id,$keyword1,$keyword2,$page);
				pdo_update(self::TABLE_H, array('display' => 1), array('formid' => $findFid[0]['formid']));
			}
			//==========================================//
			$message = '发布成功';
			$errno = 0;
			return $this->result($errno, $message, $data);
		}
	}
	
	public function doPageGetMsn(){
		global $_GPC, $_W;
		/*******************************/
		$uid = $_GPC['uid'];
		$dataMsn = pdo_getall(self::TABLE_C,array('uid' => $_GPC['uid'],'display' => $_GPC['display'],'uniacid' => $_W['uniacid']),array() , '' , 'mid DESC', array(1,10));
		/*******************************/	
		foreach($dataMsn as $key=>$value){
			$dataMsn[$key]['addtime'] = date("m-d H:i", $value['addtime']);
	    }
		$errno = 0;
		$message = '留言信息请求成功';
		return $this->result($errno, $message, $dataMsn);
	}
	
	public function doPageEdGetMsn(){
		global $_GPC, $_W;
		/*******************************/
		$op = $_GPC['op'];
		$uniacid = $_W['uniacid'];
		$sql = "SELECT * FROM ".tablename('api_user_ms')." WHERE op='$op' AND uniacid='$uniacid'";
		$dataMsn = pdo_fetchall($sql);
		$total = count($dataMsn);
		$pageindex = max($_GPC['page'],1);
		$pagesize = 5;
		$p = ($pageindex-1)*$pagesize;
		$sql.=" ORDER BY mid DESC LIMIT ".$p.",".$pagesize;
		$dataMsn = pdo_fetchall($sql);
		/*******************************/	
		foreach($dataMsn as $key=>$value){
			$dataMsn[$key]['addtime'] = date("m-d H:i", $value['addtime']);
	    }
		$errno = 0;
		$message = $total;
		$data = $dataMsn;
		return $this->result($errno, $total, $data);
	}
	
	public function doPageReplyMsn(){
		
		global $_GPC, $_W;
		$data = array(
			'r_content' => $_GPC['r_content'],
			'display' => 1,
			'rtime' => $_W['timestamp'],
		);
		$result = pdo_update(self::TABLE_C, $data, array('mid' => $_GPC['mid'],'uniacid' => $_W['uniacid']));
		$errno = 0;
		$message = '信息回复成功';
		$data = $result;
		if (!empty($result)) {
			return $this->result($errno, $message, $data);
		}
		
	}
	
	public function doPageDelMsn(){
		global $_GPC, $_W;
		$result = $temp= pdo_delete(self::TABLE_C, array('mid' => $_GPC['mid'],'uniacid' => $_W['uniacid']));
		$errno = 0;
		$message = '删除成功';
		$data = $result;
		if (!empty($result)) {
			return $this->result($errno, $message, $data);
		}
		
	}
	
	public function doPagePsOpinion(){
		global $_GPC, $_W;
		$ad_data = array(
			'openid'   => $_GPC['openid'],
			'nickname'   => $_GPC['nickName'],
			'avatar'   => $_GPC['avatarUrl'],
			'content'   => $_GPC['content'],
			'uniacid' => $_W['uniacid'],
			'time' => $_W['timestamp'],
		);
		$data = pdo_insert(self::TABLE_D, $ad_data);
		if (!empty($data)) {
			$message = '提交成功';
			$errno = 0;
			return $this->result($errno, $message, $data);
		}
		
	}
	
	
	public function doPageGetMobile() {
		global $_GPC, $_W;
		$account_api = WeAccount::create();
		$oauth = $account_api->getOauthInfo($_W['code']);
		require 'common/wx.inc.php';
		$getMobileWx = new WXBizDataCrypt($this->AppId, $oauth['session_key']);
		$errCode = $getMobileWx->decryptData($_GPC['encryptedData'], $_GPC['iv'], $data);
		
		if ($errCode == 0) {
			$errno = 0;
			$message = '获取成功';
			return $this->result($errno, $message, json_decode($data));
		} else {
			$errno = 1;
			$message = '获取失败，点击重试';
			return $this->result($errno, $message, $errCode);
		}
	}
	
	 
	public function doPageReClass() {
		global $_GPC, $_W;
		$data = pdo_getall(self::TABLE_E,array('uniacid' => $_W['uniacid'],'recomme' => 1),array() , '' , 'sort ASC');
		foreach($data as $key=>$value){
			$data[$key]['icon'] = $_W['attachurl'].$data[$key]['icon'];
	    }
		$errno = 0;
		$message = '推荐分类请求';
		return $this->result($errno, $message, $data);
	}
	
	public function doPageGetClass() {
		global $_GPC, $_W;
		$data = pdo_getall(self::TABLE_E,array('uniacid' => $_W['uniacid']),array() , '' , 'sort ASC');
		foreach($data as $key=>$value){
			$data[$key]['icon'] = $_W['attachurl'].$data[$key]['icon'];
	    }
		$errno = 0;
		$message = '分类请求成功';
		return $this->result($errno, $message, $data);
	}
	
	public function doPageFooter() {
		global $_GPC, $_W;
		$data = $_W['current_module']['config'];
		$errno = 0;
		$message = '底部信息请求成功';
		return $this->result($errno, $message, $data);
	}

	public function doPageOpenid(){
		global $_GPC, $_W;
		$message = 'Openid';
		$errno = 0;
		return $this->result($errno, $message, $this->uid);
	}
	

	public function get($key, $default = null) {
		return isset($this->gpc[$key]) ? $this->gpc[$key] : $default;
	}
	
	public function doPagePay() {
		global $_GPC, $_W;
		$shopNum = $_GPC['shopNum'];
		$orderid = $this->get('orderid', null);
		if (!$this->hasOrder($orderid)) {
			$this->result(1, '非用户订单');
		}
		if($shopNum == 1){
			$fee = $_GPC['price'];
			$title = '贸易街租金';
			$titleInt = 1;
		}else if($shopNum == 2){
			$fee = $_GPC['price'];
			$title = '礼品打赏';
			$titleInt = 2;
		}else{ 
			$fee = $_W['current_module']['config']['wxpay'];
			$title = '开设名片功能';
			$titleInt = 0;
		}
		$_W['openid'] = $_GPC['openid'];
		$order = array(
			'tid' => $orderid,
			'fee' => floatval($fee), 
			'title' => $title,
		);

        $pay_params = $this->pay($order);
        if (is_error($pay_params)) {
			$this->result($pay_params['errno'], $pay_params['message']);
       	}
		$uniacid = $_W['uniacid'];
		$data = array(
			'title' => $titleInt,
			'openid' => $_GPC['openid'],
			'username' => $_GPC['username'],
			'fee' => $fee,
			'status' => 0,
			'pay_time' => $_W['timestamp'],
			'uniacid' => $_W['uniacid'],
			'orderid' => $orderid
		);
		pdo_insert(self::TABLE_F, $data);
		// 
		if($shopNum == 2){
			$data = array(
				'sid' => $_GPC['sid'],
				'img' => $_GPC['img'],
				'title' => $_GPC['stitle'],
				'openid' => $_GPC['openid'],
				'username' => $_GPC['username'],
				'hotnum' => $_GPC['hotnum'],
				'price' => $fee,
				'status' => 0,
				'sopenid' => $_GPC['sopenid'],
				'srtime' => $_W['timestamp'],
				'uniacid' => $_W['uniacid'],
				'orderid' => $orderid
			);
			pdo_insert(self::TABLE_P, $data);
		}
		//
		if($shopNum != 1 && $shopNum != 2){
			$day = $_W['current_module']['config']['cycle'];
			$overtime = strtotime("+{$day} day");
			pdo_update(self::TABLE_B, array('paytime' => $_W['timestamp'] , 'overtime' => $overtime), array('openid' => $_GPC['openid'],'uniacid' => $_W['uniacid']));
		}
        return $this->result(0, '', $pay_params);
	}

	private function hasOrder($orderid) {
		return true;
	}
	
	public function payResult($params) {
		global $_GPC, $_W;
		$orderid = $params['tid'];
		$paylog = pdo_get('core_paylog', array('uniacid' => $_W['uniacid'], 'module' => 'api0351_user', 'tid' => $orderid));
		pdo_update(self::TABLE_B, array('user_vip' => 1), array('openid' => $paylog['openid'],'uniacid' => $_W['uniacid']));
		$data = array(
			'status' => $paylog['status'],
			'pay_time' => time(),
			'uniontid' => $paylog['uniontid'],
		);
		pdo_update(self::TABLE_F, $data, array('openid' => $paylog['openid'],'orderid' => $orderid,'uniacid' => $_W['uniacid']));
		//
		pdo_update(self::TABLE_M, array('pay' => 1), array('openid' => $paylog['openid'],'uniacid' => $_W['uniacid']));
		// 
		pdo_update(self::TABLE_P, array('status' => 1), array('orderid' => $paylog['tid'],'uniacid' => $_W['uniacid']));
	}
	
	public function doPageEditDis(){
		global $_GPC, $_W;
		$data = array(
			'display' => $_GPC['display'],
		);
		$result = pdo_update(self::TABLE_B, $data, array('openid' => $_GPC['openid'],'uniacid' => $_W['uniacid']));
		$errno = 0;
		$message = '更新成功';
		$data = $result;
		if (!empty($result)) {
			return $this->result($errno, $message, $data);
		}
		
	}
	
	public function doPageGetData(){
		global $_GPC, $_W;
		$uniacid = $_W['uniacid'];
		if($_GPC['xid'] == 0 || $_GPC['xid'] == 1){
			$sql = "SELECT * FROM ".tablename('api_user_more')." WHERE uptime != 0 AND display=1 AND uniacid='$uniacid'";
		}else if($_GPC['xid'] == 3){
			$sql = "SELECT * FROM ".tablename('api_user_more')." WHERE display=1 AND uniacid='$uniacid' AND heat!=0";
		}else{
			$sql = "SELECT * FROM ".tablename('api_user_more')." WHERE uptime != 0 AND display=1 AND uniacid='$uniacid'";
		}
		/*******************************/
		$dataMsn = pdo_fetchall($sql);
		$total = count($dataMsn);
		$pageindex = max($_GPC['page'],1);
		$pagesize = 7;
		$p = ($pageindex-1)*$pagesize;
		if($_GPC['xid'] == 0 || $_GPC['xid'] == 1){
			$sql.=" ORDER BY id DESC LIMIT ".$p.",".$pagesize;
		}else if($_GPC['xid'] == 3){
			$sql.=" ORDER BY heat DESC LIMIT ".$p.",".$pagesize;
		}else{
			$sql.=" ORDER BY id DESC LIMIT ".$p.",".$pagesize;
		}
		$dataMsn = pdo_fetchall($sql);
		/*******************************/	
		foreach($dataMsn as $key=>$value){
			$value['avatarUrl'] = explode("/",$this->cut_str($value['avatarUrl'],'/',0));
			if($value['avatarUrl'][0] == 'images'){
				$dataMsn[$key]['avatarUrl'] = $_W['attachurl'].$dataMsn[$key]['avatarUrl'];
			}
			if($this->setConfig[1][value] == 2){
				$dataMsn[$key]['avatarUrl'] = $this->setConfig[6][value].$dataMsn[$key]['avatarUrl'];
			}
	    }
		$errno = 0;
		$message = $total;
		return $this->result($errno, $total, $dataMsn);
	}
	
	public function cut_str($str,$sign,$number){
			$array=explode($sign, $str);
			$length=count($array);
			if($number<0){
				$new_array=array_reverse($array);
				$abs_number=abs($number);
				if($abs_number>$length){
					return 'error';
				}else{
					return $new_array[$abs_number-1];
				}
			}else{
				if($number>=$length){
					return 'error';
				}else{
					return $array[$number];
				}
			}

		
	}
	
	public function doPageTesting(){
		global $_GPC, $_W;
		$data = pdo_get(self::TABLE_G, array('uid' => $_GPC['uid'], 'openid' => $_GPC['openid'],'uniacid' => $_W['uniacid']));	
		$errno = 0;
		$message = '查询收藏';
		return $this->result($errno, $message, $data);
	}
	
	public function doPageCollection(){

		global $_GPC, $_W;
		$findData = pdo_get(self::TABLE_G, array('tid' => $_GPC['tid'], 'uid' => $_GPC['uid'], 'openid' => $_GPC['openid'],'uniacid' => $_W['uniacid']));			
		if (empty($findData)) {
			if($_GPC['openid'] != 'undefined'){
				//==========================================//
				$msStart = $_W['current_module']['config']['msStart'];
				if($msStart == 1){
					$account_api = WeAccount::create();
					$access_token = $account_api->getAccessToken();
					$findUid = pdo_get(self::TABLE_B, array('id' => $_GPC['uid'],'uniacid' => $_W['uniacid']));
					$touser = $findUid['openid'];
					$template_id = $_W['current_module']['config']['sc'];
					$findFid = pdo_getall(self::TABLE_H, array('openid' => $touser,'display' => 0,'uniacid' => $_W['uniacid']), array() , '' , '' , array(1));
					$form_id = $findFid[0]['formid'];
					$keyword1 = date('Y/m/d H:i:s',time());
					$keyword2 = '您的名片被人收藏了，点击查看对方名片。';
					$page = 'api0351_user/pages/index/index?uid='.$_GPC['tid'];
					/**************************/
					$this->SendMsg($access_token,$touser,$template_id,$form_id,$keyword1,$keyword2,$page);
					pdo_update(self::TABLE_H, array('display' => 1), array('formid' => $findFid[0]['formid'],'uniacid' => $_W['uniacid']));
				}
				//==========================================//
				$data = pdo_insert(self::TABLE_G, array('tid' => $_GPC['tid'], 'uid' => $_GPC['uid'], 'openid' => $_GPC['openid'], 'otime' => $_W['timestamp'],'uniacid' => $_W['uniacid']));
				$errno = 0;
				$message = '收藏成功';
			}
		}else{
			$data = 0;
			$errno = 0;
			$message = '重复收藏';
		}
		return $this->result($errno, $message, $data);
	}
	
	public function doPageGetColl(){
		global $_GPC, $_W;
		$uniacid = $_W['uniacid'];
		$sql = "SELECT * FROM ".tablename('api_user_collection')." AS u left join ".tablename('api_user_more')." a on u.uid = a.id WHERE u.openid = '$_GPC[openid]' AND u.uniacid = '$uniacid' ORDER BY u.oid DESC";
		$data = pdo_fetchall($sql);
		foreach($data as $key=>$value){
			$value['avatarUrl'] = explode("/",$this->cut_str($value['avatarUrl'],'/',0));
			if($value['avatarUrl'][0] == 'images'){
				$data[$key]['avatarUrl'] = $_W['attachurl'].$data[$key]['avatarUrl'];
			}
	    }
		$errno = 0;
		$message = '请求成功';
		return $this->result($errno, $message, $data);
	}
	
	public function doPageCodePic() {  
		global $_GPC, $_W;
		$paths = MODULE_ROOT.'/share/';  
		$uid = $_GPC['uid'];  
		$account_api = WeAccount::create();
		$response = $account_api->getCodeLimit('api0351_user/pages/index/index?uid='.$uid, 430, array(
			'auto_color' => false,
			'line_color' => array(
				'r' => '#ABABAB',
				'g' => '#ABABAC',
				'b' => '#ABABAD',
			),
		));
		$findData = pdo_get(self::TABLE_B, array('id' => $uid,'uniacid' => $_W['uniacid']));
		$filename = $uid.'.png';  
		if($findData['shareurl'] == 0){
			file_put_contents($paths.$filename, $response);
			$aupdata = array(
				'shareurl' => $_W['siteroot'].'addons/api0351_user/share/'.$uid.'.png'
			);
			pdo_update(self::TABLE_B, $aupdata, array('id' => $uid,'uniacid' => $_W['uniacid']));
		}
		sleep(2);
		$findDate = pdo_get(self::TABLE_B, array('id' => $uid,'uniacid' => $_W['uniacid']));
		if($findDate['shareurl'] != NULL){
			$data = $findDate;
		}else{
			$data = 1;
		}
		$errno = 0;
		$message = '请求成功';
		return $this->result($errno, $message, $data);
			
    }  
	
	public function SendMsg($access_token,$touser,$template_id,$form_id,$keyword1,$keyword2,$page){
		$url = 'https://api.weixin.qq.com/cgi-bin/message/wxopen/template/send?access_token='.$access_token;
		$value = array(
			"keyword1"=>array(
				"value"=>$keyword1,
				"color"=>"#333333"
			),
			"keyword2"=>array(
				"value"=>$keyword2,
				"color"=>"#333333"
			)
		);
		$dataMsn = array();
		$dataMsn['touser']=$touser;
		$dataMsn['template_id']=$template_id;
		$dataMsn['page']=$page;  
		$dataMsn['form_id']=$form_id;
		$dataMsn['data']=$value;  
		$dataMsn['color']='';                        
		$dataMsn['emphasis_keyword']='';   
		$result = $this->https_curl_json($url,$dataMsn,'json');
		return $result;
		
    }
	
	
	public function https_curl_json($url,$data,$type){
        if($type=='json'){
			//json $_POST=json_decode(file_get_contents('php://input'), TRUE);
		  	$headers = array("Content-type: application/json;charset=UTF-8","Accept: application/json","Cache-Control: no-cache", "Pragma: no-cache");
          	$data=json_encode($data);
        }
        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_POST, 1); 
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, FALSE);
        if (!empty($data)){
            curl_setopt($curl, CURLOPT_POST, 1);
            curl_setopt($curl, CURLOPT_POSTFIELDS,$data);
        }
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($curl, CURLOPT_HTTPHEADER, $headers );
        $output = curl_exec($curl);
        if (curl_errno($curl)) {
            echo 'Errno'.curl_error($curl);
        }
        curl_close($curl);
        return $output;
    }
	
	public function doPageformId(){
		global $_GPC, $_W;
		$data = array(
			'formid' => $_GPC['formid'],
			'openid' => $_GPC['openid'],
			'display' => 0,
			'uniacid' => $_W['uniacid'],
			'time' => $_W['timestamp'],
		);
		$data = pdo_insert(self::TABLE_H, $data);
		$errno = 0;
		$message = 'formId-OK';
		return $this->result($errno, $message, $data);
		
	}
	
	public function doPageShopAdd(){
		global $_GPC, $_W;
		$data = array(
			'openid' => $_GPC['openid'],
			'title' => $_GPC['title'],
			'content' => $_GPC['content'],
			'uniacid' => $_W['uniacid'],
			'time' => $_W['timestamp'],
		);
		$data = pdo_insert(self::TABLE_I, $data);
		$errno = 0;
		$message = pdo_insertid();
		return $this->result($errno, $message, $data);
	}
	
	public function doPageShopEdit(){
		global $_GPC, $_W;
		$data = array(
			'title' => $_GPC['title'],
			'content' => $_GPC['content'],
		);
		$data = pdo_update(self::TABLE_I, $data, array('id' => $_GPC['id'],'uniacid' => $_W['uniacid']));
		$errno = 0;
		$message = $_GPC['id'];
		return $this->result($errno, $message, $data);	
	}
	
	public function doPageShopPic() {
		global $_GPC, $_W;
		if (!empty($_FILES)) {
			$errno = 0;
			$message = '图片信息';
			load()->func('file');
			$imginfo = file_upload($_FILES['files'], 'image');
			$data = array(
				'photo' =>  $_W['attachurl'].$imginfo['path'],
			);
			$result = pdo_update(self::TABLE_I, $data, array('id' => $_GPC['id'],'uniacid' => $_W['uniacid']));
			if(!empty($result)){
				return $this->result($errno, $message, $result);
			}
    	}
    }
	
	public function doPageGetShop(){
		
		global $_GPC, $_W;
		$openid = $_GPC['openid'];
		$id = $_GPC['id'];
		$lmit = $_GPC['lmit'];
		$uniacid = $_W['uniacid'];
		$k = $_GPC['k'];
		if($k == 1){
			$sql = "SELECT *,a.id as oid FROM ".tablename('api_user_shop')." a left join ".tablename('api_user_more')." b on a.openid = b.openid WHERE a.uniacid = '$_W[uniacid]' ORDER BY a.time DESC LIMIT 20";
			$dataMsn = pdo_fetchall($sql);
			
			if($this->setConfig[1][value] == 2){
				foreach($dataMsn as $key=>$value){
					$dataMsn[$key]['time'] = date("m-d H:i", $value['time']);
					$dataMsn[$key]['photo'] = $this->setConfig[6][value].$value['photo'];
				}
			}else{
				foreach($dataMsn as $key=>$value){
					$dataMsn[$key]['time'] = date("m-d H:i", $value['time']);
				}
			}

		}else if($k == 2){
			$dataMsn = pdo_getall(self::TABLE_I,array(
					'openid' => $_GPC['openid'],
					'uniacid' => $_W['uniacid']
			),array() , '' , 'id DESC', array(6));
			
			if($this->setConfig[1][value] == 2){
				foreach($dataMsn as $key=>$value){
					$dataMsn[$key]['photo'] = $this->setConfig[6][value].$value['photo'];
				}
			}
				
		}else{
			if($lmit == 4){
				$dataMsn = pdo_getall(self::TABLE_I,array(
					'openid' => $_GPC['openid'],
					'uniacid' => $_W['uniacid']
				),array() , '' , 'id DESC', array(6));
				
			}else{
				if($id){
					$sql = "SELECT * FROM ".tablename('api_user_shop')." WHERE id='$id' AND uniacid = '$uniacid'";
				}else{
					$sql = "SELECT * FROM ".tablename('api_user_shop')." WHERE openid='$openid' AND uniacid = '$uniacid'";
				}
				$dataMsn = pdo_fetchall($sql);
				$total = count($dataMsn);
				$pageindex = max($_GPC['page'],1);
				$pagesize = 8;
				$p = ($pageindex-1)*$pagesize;
				$sql.=" ORDER BY id DESC LIMIT ".$p.",".$pagesize;
				$dataMsn = pdo_fetchall($sql);
				if($this->setConfig[1][value] == 2){
					foreach($dataMsn as $key=>$value){
						$dataMsn[$key]['photo'] = $this->setConfig[6][value].$value['photo'];
					}
				}
			}
		}
		$data = $dataMsn;
		$errno = 0;
		$message = $total;
		return $this->result($errno, $message, $data);	
	}
	
	public function doPageDelShop(){
		global $_GPC, $_W;
		$result = pdo_delete(self::TABLE_I, array('id' => $_GPC['id'],'uniacid' => $_W['uniacid']));
		$errno = 0;
		$message = '删除成功';
		return $this->result($errno, $message, $data);	
	}
	
	public function doPageMessage(){
		global $_GPC, $_W;
		$data = array(
			'op' => $_GPC['op'],
			'openid' => $_GPC['openid'],
			'nickname' => $_GPC['nickname'],
			'avatar' => $_GPC['avatar'],
			'display' => 0,
			'content' => $_GPC['content'],
			'uniacid' => $_W['uniacid'],
			'addtime' => $_W['timestamp'],
		);
		$data = pdo_insert(self::TABLE_J, $data);
		$errno = 0;
		$message = '发送成功';
		return $this->result($errno, $message, $data);
	}
	
	public function doPageDelMessage(){
		global $_GPC, $_W;
		$data = pdo_delete(self::TABLE_J, array('mid' => $_GPC['mid'],'uniacid' => $_W['uniacid']));
		$errno = 0;
		$message = '删除成功';
		return $this->result($errno, $message, $data);
	}
	
	public function doPageGetMesage(){
		global $_GPC, $_W;
		if($_GPC['k'] == 3){
			$data = pdo_getall(self::TABLE_J,array('uniacid' => $_W['uniacid'],'op' => $_GPC['openid'],'display' => 0),array() , '' , 'mid DESC', array());
		}else{
			$data = pdo_getall(self::TABLE_J,array('uniacid' => $_W['uniacid'],'op' => $_GPC['openid'],'display' => $_GPC['display']),array() , '' , 'mid DESC', array());
		}
		foreach($data as $key=>$value){
			$data[$key]['addtime'] = date('Y-m-d H:i:s',$value['addtime']);
	    }
		$errno = 0;
		$message = '私信请求成功';
		return $this->result($errno, $message, $data);
	}
	
	public function doPageEdMesage(){
		global $_GPC, $_W;
		$data = array(
			'display' =>  $_GPC['display'],
		);
		$data = pdo_update(self::TABLE_J, $data, array('mid' => $_GPC['mid'],'uniacid' => $_W['uniacid']));
		$errno = 0;
		$message = '读取成功';
		return $this->result($errno, $message, $data);
	}
	
	
	public function doPageShop(){
		global $_GPC, $_W;
		
		$serachData = pdo_get(self::TABLE_K, array('openid' => $_GPC['openid'],'uniacid' => $_W['uniacid']));
		if(empty($serachData)){
			$data = array(
				'dtitle' => $_GPC['dtitle'],
				'dnumber' => $_GPC['dnumber'],
				'x' => $_GPC['x'],
				'y' => $_GPC['y'],
				'openid' => $_GPC['openid'],
				'avatar' => $_GPC['avatar'],
				'nickname' => $_GPC['nickname'],
				'seid' => $_GPC['seid'],
				'dmoney' => $_GPC['dmoney'],
				'dcontent' => $_GPC['dcontent'],
				'uniacid' => $_W['uniacid'],
				'display' => 0,
				'ctime' => $_W['timestamp'],
			);
			$data = pdo_insert(self::TABLE_K, $data);	
		}else{
			if($_GPC['dmoney'] == 0){
				$dmoney = $_GPC['dnumber'] * $_W['current_module']['config']['shoPay'];
			}else{

				$dmoney = $_GPC['dnumber'];
			}
			$data = array(
				'dtitle' => $_GPC['dtitle'],
				'dnumber' => $_GPC['dnumber'],
				'x' => $_GPC['x'],
				'y' => $_GPC['y'],
				'seid' => $_GPC['seid'],
				'dmoney' => $dmoney,
				'dcontent' => $_GPC['dcontent'],
				'display' => 0,
			);
			pdo_update(self::TABLE_K, $data, array('openid' => $_GPC['openid'],'uniacid' => $_W['uniacid']));
		}
		$errno = 0;
		$message = '提交成功';
		return $this->result($errno, $message, $data);
	}
	
	public function doPageShopNum(){
		global $_GPC, $_W;
		$data = pdo_fetchall("SELECT SUM(dnumber) as num FROM ".tablename('api_user_trade')." WHERE uniacid = $_W[uniacid] AND display=1");
		$errno = 0;
		$message = '求和成功';
		return $this->result($errno, $message, $data);
	}
	
	public function doPageShopOnline(){
		global $_GPC, $_W;
		$data = pdo_get(self::TABLE_M, array('openid' => $_GPC['openid'],'uniacid' => $_W['uniacid']));
		$data['sptime'] = date('Y-m-d H:i:s',$data['sptime']);
		$data['dqtime'] = date('Y-m-d',$data['dqtime']);
		$data['ctime'] = date('Y-m-d H:i:s',$data['ctime']);
		$errno = 0;
		$message = '请求状态';
		return $this->result($errno, $message, $data);
	}
	
	public function doPageGetTong(){
		global $_GPC, $_W;
		
		$today_start = mktime(0,0,0,date('m'),date('d'),date('Y'));
		$today_end = mktime(0,0,0,date('m'),date('d')+1,date('Y'))-1;
		$todayPay = pdo_fetchall("SELECT * FROM ".tablename('api_user_trade')." WHERE ctime >= $today_start AND ctime <= $today_end AND display=1 AND uniacid=$_W[uniacid]");
		$todayPay = count($todayPay);
			
		$data = pdo_fetchall("SELECT * FROM ".tablename('api_user_trade')." WHERE uniacid = $_W[uniacid] AND display=1");
		$errno = 0;
		$message = $todayPay;
		return $this->result($errno, $message, $data);
	}
	
	public function doPageBanner(){
		global $_GPC, $_W;
		$data = pdo_getall(self::TABLE_L,array('uniacid' => $_W['uniacid']),array() , '' , 'sort ASC', array(1,5));
		foreach($data as $key=>$value){
			$data[$key]['icon'] = $_W['attachurl'].$value['icon'];
	    }
		$message = '幻灯数据请求成功';
		$errno = 0;
		return $this->result($errno, $message, $data);		
	}
	
	public function doPageGetUserShop(){
		global $_GPC, $_W;
		$data = pdo_get(self::TABLE_M, array('openid' => $_GPC['openid'],'display' => 1,'uniacid' => $_W['uniacid']));
		$message = '是否有店铺';
		$errno = 0;
		return $this->result($errno, $message, $data);		
	}
		
	public function doPageShopList(){
		global $_GPC, $_W;
		if($_GPC['s'] == 0){
			$data = pdo_getall(self::TABLE_M,array('uniacid' => $_W['uniacid'],'display' => 1),array() , '' , 'did DESC', array(1,10));
			foreach($data as $key=>$value){
				$data[$key]['icon'] = $_W['attachurl'].$value['icon'];
				$data[$key]['ctime'] = date('Y-m-d H:i:s',$value['ctime']);
			}
		}else if($_GPC['s'] == 1){
			$data = pdo_getall(self::TABLE_M,array('uniacid' => $_W['uniacid'],'display' => 1),array() , '' , 'dnumber DESC', array(1,4));
			foreach($data as $key=>$value){
				$data[$key]['icon'] = $_W['attachurl'].$value['icon'];
				$data[$key]['ctime'] = date('Y-m-d H:i:s',$value['ctime']);
			}
		}else if($_GPC['s'] == 2){
			$data = pdo_get(self::TABLE_M, array('did' => $_GPC['did'],'uniacid' => $_W['uniacid']));
			$data['ctime'] = date('m-d',$data['ctime']);
		}

		$message = '店铺数据请求成功';
		$errno = 0;
		return $this->result($errno, $message, $data);		
	}
	
	public function doPageDelDisplay(){
		global $_GPC, $_W;
		$data = pdo_delete(self::TABLE_M, array('openid' => $_GPC['openid'],'uniacid' => $_W['uniacid']));
		$errno = 0;
		$message = '删除成功';
		return $this->result($errno, $message, $data);
	}
	
	public function doPagePostReport(){
		global $_GPC, $_W;
		$data = array(
			'jid' => $_GPC['jid'],
			'op' => $_GPC['op'],
			'openid' => $_GPC['openid'],
			'nickname' => $_GPC['nickname'],
			'avatar' => $_GPC['avatar'],
			'content' => $_GPC['content'],
			'uniacid'   => $_W['uniacid'],
			'dis'   => $_GPC['dis'],
			'time' => $_W['timestamp'],
		);
		$data = pdo_insert(self::TABLE_D, $data);
		pdo_update(self::TABLE_B, array('report +=' => 1), array('openid' => $_GPC['op'],'uniacid' => $_W['uniacid']));
		$message = '举报成功';
		$errno = 0;
		return $this->result($errno, $message, $data);		
	}
	
	public function doPageGetNews(){
		global $_GPC, $_W;
		$data = pdo_getall(self::TABLE_N,array('uniacid' => $_W['uniacid']),array() , '' , 'nid DESC', array(1,5));
		foreach($data as $key=>$value){
			$data[$key]['addtime'] = date('m-d',$value['addtime']);
	    }
		$message = '商报请求成功';
		$errno = 0;
		return $this->result($errno, $message, $data);	
	}
	
	public function doPageGetViewNew(){
		global $_GPC, $_W;
		$data = pdo_get(self::TABLE_N, array('nid' => $_GPC['id'],'uniacid' => $_W['uniacid']));
		$data['addtime'] = date('m-d',$data['addtime']);
		$message = '商报内容';
		$errno = 0;
		return $this->result($errno, $message, $data);	
	}
	
	public function doPageGetReward(){
		global $_GPC, $_W;
		$data = pdo_getall(self::TABLE_O,array('uniacid' => $_W['uniacid']),array() , '' , 'rid DESC', array(10));
		foreach($data as $key=>$value){
			$data[$key]['photo'] = $_W['attachurl'].$value['photo'];
		}
		$message = '礼品信息';
		$errno = 0;
		return $this->result($errno, $message, $data);	
	}
	
	public function doPageAddShang(){
		global $_GPC, $_W;
		$data = pdo_update(self::TABLE_B, array('heat +=' => $_GPC['hotnum']), array('openid' => $_GPC['openid'],'uniacid' => $_W['uniacid']));
		$message = '热度增加';
		$errno = 0;
		return $this->result($errno, $message, $data);	
	}
	
	public function doPageGetShang(){
		global $_GPC, $_W;
		$data = pdo_getall(self::TABLE_P,array('uniacid' => $_W['uniacid'],'sopenid' => $_GPC['openid'],'status' => 1),array() , '' , 'lid DESC', array());
		foreach($data as $key=>$value){
			$data[$key]['srtime'] = date('Y-m-d H:i',$value['srtime']);
		}
		$message = '礼品信息';
		$errno = 0;
		return $this->result($errno, $message, $data);	
	}
	
	public function doPageCdrsb(){
		global $_GPC, $_W;
		// 图片base64编码
		if($_GPC['d'] == 1){
			$data   = file_get_contents($_W['attachurl'].$_GPC['image']);
		}else if($_GPC['d'] == 2){
			$data   = file_get_contents($this->setConfig[6][value].$_GPC['image']);
		}
		$base64 = base64_encode($data);
		
		// 设置请求数据
		$appkey = $_W['current_module']['config']['tappkey'];    // appkey
		$params = array(
			'app_id'     => $_W['current_module']['config']['tappid'],   // app_id
			'image'      => $base64,
			'time_stamp' => strval(time()),
			'nonce_str'  => strval(rand()),
			'sign'       => '',
		);
		$params['sign'] = $this->getReqSign($params, $appkey);
		// 执行API调用
		$url = 'https://api.ai.qq.com/fcgi-bin/ocr/ocr_bcocr';
		$data = $this->doHttpPost($url, $params);
		$message = '识别成功';
		$errno = 0;
		return $this->result($errno, $message, $data);	
	}
	
	
	public function doPagePostCdr() {
		global $_GPC, $_W;
		if (!empty($_FILES)) {
			$errno = 0;
			$message = '图片信息';
			load()->func('file');
			$imginfo = file_upload($_FILES['files'], 'image');
			$data = $imginfo;
			$errno = 0;
			$message = '上传成功';
			return $this->result($errno, $message, $data);
    	}
    }
	
	public function doPageAddCdr() {
		global $_GPC, $_W;
		$data = array(
			'imgurl' => $_GPC['imgurl'],
			'openid' => $_GPC['openid'],
			'xingming' => $_GPC['xingming'],
			'gongsi' => $_GPC['gongsi'],
			'zhiwei' => $_GPC['zhiwei'],
			'dianhua' => $_GPC['dianhua'],
			'shouji' => $_GPC['shouji'],
			'youxiang' => $_GPC['youxiang'],
			'weixin'   => $_GPC['weixin'],
			'uniacid'   => $_W['uniacid'],
			'time' => $_W['timestamp'],
		);
		$data = pdo_insert(self::TABLE_Q, $data);
		$errno = 0;
		$message = '新增成功';
		return $this->result($errno, $message, $data);
	}
	
	public function doPageGetCdr() {
		global $_GPC, $_W;
		$data = pdo_getall(self::TABLE_Q,array('uniacid' => $_W['uniacid'],'openid' => $_GPC['openid']),array() , '' , 'rid DESC', array());
		if($_GPC['s'] == 0){
			foreach($data as $key=>$value){
				$data[$key]['imgurl'] = $_W['attachurl'].$value['imgurl'];
			}
		}else{
			foreach($data as $key=>$value){
				$data[$key]['imgurl'] = $this->setConfig[6][value].$value['imgurl'];
			}
		}
		
		
		$errno = 0;
		$message = '查询成功';
		return $this->result($errno, $message, $data);
	}
	
	public function doPageGetViewCdr() {
		global $_GPC, $_W;
		$data = pdo_get(self::TABLE_Q,array('uniacid' => $_W['uniacid'],'openid' => $_GPC['openid'],'rid' => $_GPC['uid']));
		$data['imgurl'] = $_W['attachurl'].$data['imgurl'];
		$errno = 0;
		$message = '查询成功';
		return $this->result($errno, $message, $data);
	}
	
	// doHttpPost ：执行POST请求，并取回响应结果
    public function doHttpPost($url, $params){
        $curl = curl_init();
        $response = false;
        do
        {
            curl_setopt($curl, CURLOPT_URL, $url);
            $head = array(
                'Content-Type: application/x-www-form-urlencoded'
            );
            curl_setopt($curl, CURLOPT_HTTPHEADER, $head);
            $body = http_build_query($params);
            curl_setopt($curl, CURLOPT_POST, true);
            curl_setopt($curl, CURLOPT_POSTFIELDS, $body);
            curl_setopt($curl, CURLOPT_HEADER, false);
            curl_setopt($curl, CURLOPT_NOBODY, false);
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, true);
            curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
            $response = curl_exec($curl);
        } while (0);
        curl_close($curl);
        return $response;
    }
	
	
	public function getReqSign($params, $appkey){
        if (!$params['nonce_str']){
            $params['nonce_str'] = uniqid("{$params['app_id']}_");
        }
        if (!$params['time_stamp']){
            $params['time_stamp'] = time();
        }
        ksort($params);
        $str = '';
        foreach ($params as $key => $value){
            if ($value !== ''){
                $str .= $key . '=' . urlencode($value) . '&';
            }
        }
        $str .= 'app_key=' . $appkey;
        $sign = strtoupper(md5($str));
        return $sign;
    }
	
	public function doPageDelCarlist(){
		global $_GPC, $_W;
		$m = $_GPC['mum'];
		if($m == 1){
			$data = pdo_delete(self::TABLE_G, array('oid' => $_GPC['oid'],'openid' => $_GPC['openid']));
		}else if($m == 2){
			$data = pdo_delete(self::TABLE_Q, array('rid' => $_GPC['rid'],'openid' => $_GPC['openid']));
		}
		$errno = 0;
		$message = '移除成功';
		return $this->result($errno, $message, $data);
	}
	
	public function doPageKewords(){
		global $_GPC, $_W;
		
		if($_GPC['searchid'] == 0){
			$condition .= " WHERE signature LIKE '%".$_GPC['keyword']."%' AND uptime!=0 AND uniacid=".$_W['uniacid']." ORDER BY id DESC";
		}else if($_GPC['searchid'] == 1){
			$condition .= " WHERE nickName LIKE '%".$_GPC['keyword']."%' AND uptime!=0 AND uniacid=".$_W['uniacid']." ORDER BY id DESC";
		}else if($_GPC['searchid'] == 2){
			$condition .= " WHERE user_gs LIKE '%".$_GPC['keyword']."%' AND uptime!=0 AND uniacid=".$_W['uniacid']." ORDER BY id DESC";
		}
        
		
		$sql = "SELECT * FROM ".tablename('api_user_more').$condition;
		$data = pdo_fetchall($sql);
		foreach($data as $key=>$value){
			$value['avatarUrl'] = explode("/",$this->cut_str($value['avatarUrl'],'/',0));
			if($value['avatarUrl'][0] == 'images'){
				$data[$key]['avatarUrl'] = $_W['attachurl'].$data[$key]['avatarUrl'];
			}
	    }
		$errno = 0;
		$message = '检索成功';
		return $this->result($errno, $message, $data);
	}
	
	public function doPageGetDataClas(){
		global $_GPC, $_W;
		$uniacid = $_W['uniacid'];
		
		$find = pdo_get(self::TABLE_E, array('id' => $_GPC['cid'],'uniacid' => $_W['uniacid']));
		$sql = "SELECT * FROM ".tablename('api_user_more')." WHERE indes=".$find['sort']." AND display=1 AND uniacid='$uniacid'";
		/*******************************/
		$dataMsn = pdo_fetchall($sql);
		$total = count($dataMsn);
		$pageindex = max($_GPC['page'],1);
		$pagesize = 20;
		$p = ($pageindex-1)*$pagesize;
		$sql.=" ORDER BY id DESC LIMIT ".$p.",".$pagesize;
		$dataMsn = pdo_fetchall($sql);
		/*******************************/	
		foreach($dataMsn as $key=>$value){
			$value['avatarUrl'] = explode("/",$this->cut_str($value['avatarUrl'],'/',0));
			if($value['avatarUrl'][0] == 'images'){
				$dataMsn[$key]['avatarUrl'] = $_W['attachurl'].$dataMsn[$key]['avatarUrl'];
			}
	    }
		$errno = 0;
		$message = $total;
		return $this->result($errno, $total, $dataMsn);
	}
	
	public function doPageUploadWx(){

		global $_GPC, $_W;
		if (!empty($_FILES)) {

			load()->func('file');
			$imginfo = file_upload($_FILES['file'], 'image');
			//--------------------------------------------------
			$data = array(
				'openid' => $_GPC['openid'],
				'imgUrl' => $_W['attachurl'].$imginfo['path'],
				'uniacid'   => $_W['uniacid'],
				'time' => $_W['timestamp'],
			);
			pdo_insert(self::TABLE_R, $data);
			//--------------------------------------------------
			$data = array("Success"=>true,"SaveName"=>$_W['attachurl'].$imginfo['path']);
			echo json_encode($data);
    	}

	}
	
	public function doPageGetImg(){
		global $_GPC, $_W;
		$data = pdo_getall(self::TABLE_R,array('uniacid' => $_W['uniacid'],'openid' => $_GPC['openid']),array() , '' , 'id ASC', array(4));
		$errno = 0;
		$message = '图像请求';
		return $this->result($errno, $message, $data);
	}
	
	public function doPageDelImg(){
		global $_GPC, $_W;
		$data = pdo_delete(self::TABLE_R, array('id' => $_GPC['id'],'openid' => $_GPC['openid']));
		$errno = 0;
		$message = '删除成功';
		return $this->result($errno, $message, $data);
	}
	
	public function doPageConfig(){
		global $_GPC, $_W;
		$data = pdo_getall(self::TABLE_S,array(),array() , '' , 'num ASC', array());
		$errno = 0;
		$message = '配置请求成功';
		return $this->result($errno, $message, $data);
	}
	
	public function doPageQiniuUptoke(){
		require 'common/autoload.php';
		// 用于签名的公钥和私钥
		$accessKey = $this->setConfig[3][value];
		$secretKey = $this->setConfig[4][value];
		// 初始化签权对象
		$auth = new Auth($accessKey, $secretKey);
		$data = $auth->uploadToken($this->setConfig[5][value]);
		$errno = 0;
		$message = 'Uptoke';
		return $this->result($errno, $message, $data);
	}
	
	public function doPageQiniuUpload(){
		global $_GPC, $_W;
		$data = array(
			'avatarUrl' =>  $_GPC['avatarUrl'],
		);
		$result = pdo_update(self::TABLE_B, $data, array('openid' => $_GPC['openid'],'uniacid'   => $_W['uniacid']));
		$errno = 0;
		if(!empty($result)){
			return $this->result($errno, $data, $result);
		}	
	}
	
	public function doPageQiniuShop() {
		global $_GPC, $_W;
		$errno = 0;
		$message = '图片信息';
		$data = array(
			'photo' =>  $_GPC['photo'],
		);
		$result = pdo_update(self::TABLE_I, $data, array('id' => $_GPC['id'],'uniacid' => $_W['uniacid']));
		if(!empty($result)){
			return $this->result($errno, $message, $result);
		}
    }
	
	public function doPageQiniuCdr() {
		global $_GPC, $_W;

		$errno = 0;
		$message = '图片信息';
		load()->func('file');
		$imginfo = file_upload($_FILES['files'], 'image');
		$data = $imginfo;
		$errno = 0;
		$message = '上传成功';
		return $this->result($errno, $message, $data);
    	
    }
	
	public function doPageBackGro() {
		global $_GPC, $_W;
		$errno = 0;
		$message = '设置成功';
		$data = array(
			'backgro' =>  $_GPC['backgro'],
		);
		$result = pdo_update(self::TABLE_B, $data, array('openid' => $_GPC['openid'],'uniacid' => $_W['uniacid']));
		if(!empty($result)){
			return $this->result($errno, $message, $result);
		}
    }
	
	public function doPageGetBack() {
		global $_GPC, $_W;
		$data = pdo_get(self::TABLE_B,array('uniacid' => $_W['uniacid'],'openid' => $_GPC['openid']));
		$errno = 0;
		$message = '背景加载';
		return $this->result($errno, $message, $data);
    }
	
	
	    /**
     * 登录
     */
    public function doPageLogin(){
		global $_GPC, $_W;
        $code = $_GPC["code"];
        $rawData = htmlspecialchars_decode($_GPC["rawData"]);
        if (!$code || !$rawData) {
			return $this->result(1, '用户授权参数错误', 0);
        }
        $userInfo = (array)json_decode($rawData, true);

			
        $params = [
            'appid'      => $_W['account']['oauth']['key'],
            'secret'     => $_W['account']['oauth']['secret'],
            'js_code'    => $code,
            'grant_type' => 'authorization_code'
        ];
        $result = ihttp_request("https://api.weixin.qq.com/sns/jscode2session", $params);

		$json = (array)json_decode($result['content'], true);
		
		$data = [
			'openid'        => $json['openid'],
			'wxInfo'      => $userInfo,
			'session_key'  => $json['session_key'],
		];
				
		if (isset($json['openid'])) {
			$errno = 0;
			$message = '登录成功';
			return $this->result($errno, $message, $data);
		}else{
			$errno = 0;
			$message = '登录失败';
			return $this->result($errno, $message, $data);

		}
		
    }
	
	
	public function doPageDelPay(){
		global $_GPC, $_W;
		//var_dump($_W['current_module']['config']['zuNum']);
		//exit;
		if($_W['current_module']['config']['userVip'] == 1){
			// 清除尚未支付的残余订单
			pdo_delete(self::TABLE_F, array('status' => 0));
			// 清除没有填写信息资料的用户，数据库残留空用户
			pdo_delete(self::TABLE_B, array('cid' => 0, 'indes' => 0, 'uptime' => 0, 'user_vip' => 0));
			// 删除无效的模板消息ID
			pdo_delete(self::TABLE_H, array('display' => 1,'formid' => 'the formId is a mock one'), 'OR'); 
			// 删除过期VIP
			// 阿.莫.之.家
			$today = $_W['timestamp'];
			$data = array(
				'user_vip' => 0,
			);
			pdo_update(self::TABLE_B, $data, array('overtime <=' => $today));
			// 删除无效的收藏信息
			pdo_delete(self::TABLE_G, array('openid' => 'undefined','uid' => 0), 'OR'); 
			// 删除无效的关注信息
			pdo_delete(self::TABLE_A, array('avatar' => '','avatar' => 'undefined','openid' => ''), 'OR');
			// 删除无效的留言信息
			pdo_delete(self::TABLE_C, array('openid' => 0)); 
			// 删除过期店铺信息
			$today = $_W['timestamp'];
			//$data = array(
			//	'display' => 0,
			//);
			//pdo_update(self::TABLE_M, $data, array('dqtime <=' => $today));
			pdo_delete(self::TABLE_M, array('dqtime <=' => $today,'pay' => 1));
			// 删除未成功的打赏记录
			pdo_delete(self::TABLE_P, array('status' => 0)); 
		}
	}

}