var i = {
    uniacid: "58",
    acid: "58",
    multiid: "0",
    version: "4.7.5",
    siteroot: "https://we7.wulitan.xyz/app/index.php",
    design_method: "3"
};

module.exports = i;