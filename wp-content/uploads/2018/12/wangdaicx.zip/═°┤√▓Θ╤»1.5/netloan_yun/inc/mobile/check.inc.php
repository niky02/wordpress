<?php
defined('IN_IA') or exit('Access Denied');

	global $_W, $_GPC; 

	load()->func('tpl');

        //$name = $_POST['category'];

	if($_GET['name']){
	$name = $_GET['name'];
	}else{
	$name = $_POST['category'];
	}
	$where = " WHERE title='{$name}'"; 

	$showdit = pdo_fetch("SELECT * FROM ".tablename('momodabusiness').$where);
	//$sscd = htmlentities($showdit['content']);


	if($showdit==false){
	  $asd = 1;

	}

	include $this->template('check');


