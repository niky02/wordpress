<?php

defined('IN_IA') or exit('Access Denied');

//include MODULE_ROOT.'/inc/mobile/wx.inc.php';

global $_W, $_GPC; 

	load()->func('tpl');

	if (checksubmit()) {
	  
	$date['id'] = $_GPC['id'];
	
	$where = " WHERE category =".$_GPC['category']; 

	$showdit = pdo_fetch("SELECT * FROM ".tablename('momodabusiness').$where);
	
	echo $this->createMobileUrl('store');
	
	}

	include $this->template('store');

