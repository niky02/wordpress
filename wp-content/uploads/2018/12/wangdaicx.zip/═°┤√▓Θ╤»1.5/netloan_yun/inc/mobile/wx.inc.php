<?php
global $_W, $_GPC; 

	if($_GET['code']){
        
  	$code = $_GET['code'];

	$urlon = 'https://api.weixin.qq.com/sns/oauth2/access_token?appid='.$_W['account']['key'].'&secret='.$_W['account']['secret'].'&code='.$code.'&grant_type=authorization_code';

	//通过curl  get方式获取内容					
	
	$ch = curl_init();
	
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);// 对认证证书来源的检查
	
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE); // 从证书中检查SSL加密算法是否存在
	
	curl_setopt($ch, CURLOPT_URL, $urlon);
		
	$json =  curl_exec($ch);
	
	curl_close($ch);
	
	$arrc = json_decode($json,1);

	$url='https://api.weixin.qq.com/sns/userinfo?access_token='.$arrc['access_token'].'&openid='.$arrc['openid'].'&lang=zh_CN';

	$ch = curl_init();
	
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
	
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
	
	curl_setopt($ch, CURLOPT_URL, $url);
	
	$json =  curl_exec($ch);
	
	curl_close($ch);
	
	$arr = json_decode($json,1);
//------------------------------------------------------------------------------------------------
	$ip = $_SERVER["REMOTE_ADDR"];
	
	$isp =getCity($ip);

	$name = $arr['openid'];

	$where = " WHERE openid='{$name}'";
	
	$numruser = pdo_fetch("SELECT * FROM ".tablename('netloanuser').$where);


	if($arr['openid']==$numruser['openid']){
	

	}else{
	
	$date['openid'] = $arr['openid'];

	$date['nickname'] = $arr['nickname'];

	$date['isp'] = $ip['area'].$ip['region'].$ip['city'].$ip['county'].$ip['ip'];

	$date['sex'] = $arr['sex'];

	$date['province'] = $arr['province'];

	$date['city'] = $arr['city'];

	$date['country'] = $arr['country'];

        $date['headimgurl'] = $arr['headimgurl'];

	$date['language'] = $arr['language'];
	
	pdo_insert('netloanuser', $date);
	}


//------------------------------------------------------------------------
}else{
	$agent = check_wap();

	if($agent){
  
	$appid = $_W['account']['key'];

	$mpc = "http://".$_SERVER['SERVER_NAME']."/app/index.php?i=1&c=entry&do=store&m=netloan_yun";

	$redirect_uri = urlencode($mpc);

	$urll="https://open.weixin.qq.com/connect/oauth2/authorize?appid=$appid&redirect_uri=$redirect_uri&response_type=code&scope=snsapi_userinfo&connect_redirect=1#wechat_redirect";

	echo "<script language='javascript' type='text/javascript'>window.location.href='$urll';</script>";
	
	}
	
}

	function check_wap(){
	  // 先检查是否为wap代理，准确度高
	  if(stristr($_SERVER['HTTP_VIA'],"wap")){
	    return true;
	  }
	  // 检查浏览器是否接受 WML.
	  elseif(strpos(strtoupper($_SERVER['HTTP_ACCEPT']),"VND.WAP.WML") > 0){
 	   return true;
	  }
	  //检查USER_AGENT
	  elseif(preg_match('/(blackberry|configuration\/cldc|hp |hp-|htc |htc_|htc-|iemobile|kindle|midp|mmp|motorola|mobile|nokia|opera mini|opera |Googlebot-Mobile|YahooSeeker\/M1A1-R2D2|android|iphone|ipod|mobi|palm|palmos|pocket|portalmmm|ppc;|smartphone|sonyericsson|sqh|spv|symbian|treo|up.browser|up.link|vodafone|windows ce|xda |xda_)/i', $_SERVER['HTTP_USER_AGENT'])){
	    return true;       
	  }
 	 else{
	    return false;  
	  }
	}



function getCity($ip = ''){
    if($ip == ''){
        $url = "http://int.dpool.sina.com.cn/iplookup/iplookup.php?format=json";
        $ip=json_decode(file_get_contents($url),true);
        $data = $ip;
    }else{
        $url="http://ip.taobao.com/service/getIpInfo.php?ip=".$ip;
        $ip=json_decode(file_get_contents($url));   
        if((string)$ip->code=='1'){
           return false;
        }
        $data = (array)$ip->data;
    }
    
    return $data;   
}

