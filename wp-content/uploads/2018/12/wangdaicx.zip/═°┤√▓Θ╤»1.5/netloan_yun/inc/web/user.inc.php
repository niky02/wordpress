<?php
defined('IN_IA') or exit('Access Denied');

	global $_W, $_GPC;  
	
	load()->func('tpl');


    // 数组中的无数个数大于0，说明用户在搜索
    if(count($arr)>0){
        $where = 'where '.join(' and ', $arr);
        $url_s = '&'.join('&', $url);
    }


        
	$num = 5;

    // 2.接收当前页码
    $page = empty($_GET['p'])?1:(int)$_GET['p'];	


    $res = pdo_fetchall("select count(*) total from ".tablename('netloanuser')."$where");
    
  

    // 总记录数
    	$total = $res[0]['total'];

    // 总页数
    	$amount = ceil($total/$num);

    // 限制页码在有效的范围内
    	$page = max(1,$page);
    	$page = min($amount,$page);

	// 4.计算偏移量  ($page-1)*$num
        $offset = ($page-1)*$num;
    	// 产生链接
    	// 上一页的页码
    	$prev = $page-1;
    	// 下一页的页码
   	$next = $page+1;
	
//----------------------------------------------------------------------------	
	
	
	$where= "$where order by id desc limit $offset,$num";
	
	$showlist = pdo_fetchall("SELECT * FROM ".tablename('netloanuser').$where);
	


$str = <<<aaa
	    <a class="btn btn-default" href="?c=site&a=entry&do=user&m=netloan_yun&p={$url_s}" role="button">首页</a>
	    <a class="btn btn-default" href="?c=site&a=entry&do=user&m=netloan_yun&p={$prev}{$url_s}" role="button">上一页</a>
	    <a class="btn btn-default" href="?c=site&a=entry&do=user&m=netloan_yun&p={$next}{$url_s}" role="button">下一页</a>
	    <a class="btn btn-default" href="?c=site&a=entry&&do=user&m=netloan_yun&p={$amount}{$url_s}" role="button">尾页</a>
aaa;




	include $this->template('user');


