<?php

defined('IN_IA') or exit('Access Denied');

class Netloan_yunModuleProcessor extends WeModuleProcessor {
	public function respond() {
		$content = $this->message['content'];
	
	}
}
