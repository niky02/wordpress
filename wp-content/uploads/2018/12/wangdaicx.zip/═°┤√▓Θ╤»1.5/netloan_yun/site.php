<?php

defined('IN_IA') or exit('Access Denied');

class Netloan_yunModuleSite extends WeModuleSite {

	public function doWebRule(){
	  
	global $_W, $_GPC;
		
	$rid = intval($_GPC['id']);
		
	echo $rid;
	
	}

}
