<?php
$sql="CREATE TABLE IF NOT EXISTS `ims_netloanuser` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '//编号',
  `openid` varchar(100) NOT NULL COMMENT '//微信唯一标识',
  `nickname` varchar(50) NOT NULL COMMENT '//用户名',
  `language` varchar(50) NOT NULL COMMENT '//用户语言',
  `headimgurl` varchar(500) NOT NULL COMMENT '//头像',
  `isp` varchar(500) DEFAULT NULL COMMENT '//IP地址',
  `sex` tinyint(4) NOT NULL COMMENT '//性别',
  `province` varchar(30) DEFAULT NULL COMMENT '//省份',
  `city` varchar(30) DEFAULT NULL COMMENT '//城市',
  `country` varchar(30) DEFAULT NULL COMMENT '//国家',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
";
pdo_run($sql);
if(!pdo_fieldexists('netloanuser',  'id')) {
	pdo_query("ALTER TABLE ".tablename('netloanuser')." ADD `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '//编号';");
}
if(!pdo_fieldexists('netloanuser',  'openid')) {
	pdo_query("ALTER TABLE ".tablename('netloanuser')." ADD `openid` varchar(100) NOT NULL COMMENT '//微信唯一标识';");
}
if(!pdo_fieldexists('netloanuser',  'nickname')) {
	pdo_query("ALTER TABLE ".tablename('netloanuser')." ADD `nickname` varchar(50) NOT NULL COMMENT '//用户名';");
}
if(!pdo_fieldexists('netloanuser',  'language')) {
	pdo_query("ALTER TABLE ".tablename('netloanuser')." ADD `language` varchar(50) NOT NULL COMMENT '//用户语言';");
}
if(!pdo_fieldexists('netloanuser',  'headimgurl')) {
	pdo_query("ALTER TABLE ".tablename('netloanuser')." ADD `headimgurl` varchar(500) NOT NULL COMMENT '//头像';");
}
if(!pdo_fieldexists('netloanuser',  'isp')) {
	pdo_query("ALTER TABLE ".tablename('netloanuser')." ADD `isp` varchar(500) DEFAULT NULL COMMENT '//IP地址';");
}
if(!pdo_fieldexists('netloanuser',  'sex')) {
	pdo_query("ALTER TABLE ".tablename('netloanuser')." ADD `sex` tinyint(4) NOT NULL COMMENT '//性别';");
}
if(!pdo_fieldexists('netloanuser',  'province')) {
	pdo_query("ALTER TABLE ".tablename('netloanuser')." ADD `province` varchar(30) DEFAULT NULL COMMENT '//省份';");
}
if(!pdo_fieldexists('netloanuser',  'city')) {
	pdo_query("ALTER TABLE ".tablename('netloanuser')." ADD `city` varchar(30) DEFAULT NULL COMMENT '//城市';");
}
if(!pdo_fieldexists('netloanuser',  'country')) {
	pdo_query("ALTER TABLE ".tablename('netloanuser')." ADD `country` varchar(30) DEFAULT NULL COMMENT '//国家';");
}

?>