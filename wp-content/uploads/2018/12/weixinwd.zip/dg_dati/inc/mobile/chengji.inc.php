<?php
global $_W,$_GPC;
load()->func('tpl');
	$rid=$_GPC["rid"];
	$acid=$_W['uniacid'];
// 	$openid = $_W["openid"];
// 	$nick=$_W['fans']['nickname'];
// 	$headimg=$_W['fans']['tag']['avatar'];
	$openid = $_W ['openid'];
	$nick=!empty($_W['fans']['nickname'])?$_W['fans']['nickname']:$_COOKIE["nick"];
	$headimg=!empty($_W['fans']['tag']['avatar'])?$_W['fans']['tag']['avatar']:$_COOKIE["head"];
	$reply=pdo_fetch("SELECT * FROM " . tablename('dt_question_reply') . " WHERE rid = :rid ", array(':rid' => $rid));
	$userinfo = pdo_fetch("SELECT * FROM ". tablename("dt_userpoints")." WHERE openid=:openid and rid=:rid ORDER BY ID DESC LIMIT 1" , array(":openid"=>$openid,":rid"=>$rid));
	$usercount = pdo_fetch("SELECT * FROM ". tablename("dt_usercount")." WHERE openid=:openid and rid=:rid LIMIT 1" , array(":openid"=>$openid,":rid"=>$rid));
	if(!empty($userinfo)){
		$id=intval($userinfo["id"]);
		$ljstatus=$userinfo["ljstatus"];
		$shyucount=intval($usercount["shyucount"]);
		$points=$userinfo["points"];
		$sytime=$userinfo["sytime"];
	}

	/**
	 * 分享
	 */
	$sharetitle=$reply["sharetitle"];//分享标题
	$sharecontent=$reply["sharecontent"];//分享内容
	$shareimg=$_W['attachurl'].$reply["shareimg"];//分享图片
	$isshareadd=$reply["isshareadd"];//是否 分享增加一次
	$sharelink="";
	$huodongname=$reply["huodongname"];
	$color=$reply["color"];
	//奖励设置
	$isjl=$reply["isjl"];
	$jltype=$reply["jltype"];
	$jlnum=$reply["jlnum"];
	$jlcontent=$reply["jlcontent"];
	
	if($isshareadd==0){
		$sharelink = $_W ['siteroot'] . 'app/' . $this->createMobileUrl ( 'index', array ('rid' => $rid));
	}else{
		$sharelink=$_W ['siteroot'] . 'app/' . $this->createMobileUrl ( 'index', array ('rid' => $rid,'fromid'=>$openid));
	}
	$sharelink = str_replace ( './', '', $sharelink );//分享链接
	
	//如果超过分享次数上限
	$sharelist=pdo_fetchall("select * from ".tablename("dt_usershare")." where fromuserid=:fromid and rid=:rid",array(":fromid"=>$openid,":rid"=>$rid));
	$is_max=0;
	if($reply["maxcount"]!=0 && !empty($reply["maxcount"]) && $reply["maxcount"]<=count($sharelist)){
		$is_max=1;
	}
	
include $this->template('chengji');