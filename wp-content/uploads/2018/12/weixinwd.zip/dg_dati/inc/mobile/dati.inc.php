<?php
global $_W,$_GPC;
load()->func('tpl');
$openid = $_W["openid"];
	$rid=$_GPC["rid"];
	$fromid=$_GPC["fromid"];//分享人openid
	$reply=pdo_fetch("SELECT * FROM " . tablename('dt_question_reply') . " WHERE rid = :rid ", array(':rid' => $rid));
 	$total=$reply["questioncount"];//问题数量
 	$dtuser = pdo_fetch("SELECT * FROM ". tablename('dt_userpoints')." WHERE openid=:openid and rid=:rid ORDER BY ID DESC LIMIT 1" , array(":openid"=>$openid,":rid"=>$rid));
 	$usercount = pdo_fetch("SELECT * FROM ". tablename("dt_usercount")." WHERE openid=:openid and rid=:rid LIMIT 1" , array(":openid"=>$openid,":rid"=>$rid));
 	
	$huodongname=$reply["huodongname"];
 	$shyucount=$usercount["shyucount"]; 
 	$color=$reply["color"];
 	$iswanshan=$reply["iswanshan"];
 	$result=pdo_fetchall("select * from ".tablename("dt_userinfo")." where openid=:openid and rid = :rid",array(":openid"=>$openid,":rid"=>$rid));
 	if(count($result)>0){
 		$iswanshan=0;
 	}
 	if(empty($usercount)){
 		//添加答题次数记录
 		$params = array("rid"=>$rid,"userid"=>$id,"openid"=>$openid,"shyucout"=>intval($reply["dtcount"])>0?intval($reply["dtcount"])-1:0);
 		pdo_insert("dt_usercount", $params);
 	}else{
	 	if($shyucount==0){
	 		$nouser=0;
			if(!empty($usercount)){
				//剩余数量
				$shyucount=intval($usercount["shyucount"]);
			}else{
				
				$shyucount=empty($reply["dtcount"])?1:$reply["dtcount"];
				$nouser=1;
			}
			$sql="SELECT * FROM " . tablename('dt_question_reply') . " WHERE rid = :rid LIMIT 1";
			$quesreply = pdo_fetch($sql, array(':rid' => $rid));
			
			$huodongname=$quesreply["huodongname"];
			$followdesc=$quesreply["followdesc"];
			$huodongdesc=$quesreply["huodongdesc"];
			
			if ($quesreply['start_time'] > time()) {
				//倒计时
				$startsecond=$quesreply["start_time"];
				$now = time();
				$leftsecond=$startsecond-$now;
				include $this->template('nostart');
				exit();
			}
			
			if ($quesreply == false || $quereply['start_time'] > time() || $quesreply['end_time'] < time() || $quesreply['status']==0) {
				include $this->template('over');
				exit();
			}
			
			
			//企业信息
			$qyname=$quesreply["qyname"];
			$qylogo=$quesreply["qylogo"];
			$qylink=$quesreply["qylink"];
			$homebg=$quesreply["homebg"];
			
			$result=pdo_fetch("select count(*) as num from ".tablename("dt_userpoints")." where rid=:rid",array(":rid"=>$rid));
			$num = (int)$result['num'];
			
			
			$isshareadd=$reply["isshareadd"];//是否 分享增加一次
			
			//如果超过分享次数上限
			$sharelist=pdo_fetchall("select * from ".tablename("dt_usershare")." where fromuserid=:fromid and rid=:rid",array(":fromid"=>$openid,":rid"=>$rid));
			$is_max=0;
			if($reply["maxcount"]!=0 && !empty($reply["maxcount"]) && $reply["maxcount"]<=count($sharelist)){
				$is_max=1;
			}
			
			$count=$num+(int)$reply["xncount"];
			
			/**
			 * 分享
			 */
			
			$sharetitle=$reply["sharetitle"];//分享标题
			$sharecontent=$reply["sharecontent"];//分享内容
			$shareimg=$_W['attachurl'].$reply["shareimg"];//分享图片
			$isshareadd=$reply["isshareadd"];//是否 分享增加一次
			$sharelink="";
			$huodongname=$reply["huodongname"];
			$color=$reply["color"];
			if($isshareadd==0){
				$sharelink = $_W ['siteroot'] . 'app/' . $this->createMobileUrl ( 'index', array ('rid' => $rid));
			}else{
				$sharelink=$_W ['siteroot'] . 'app/' . $this->createMobileUrl ( 'index', array ('rid' => $rid,'fromid'=>$openid));
			}
			$sharelink = str_replace ( './', '', $sharelink );//分享链接
			$url='http://'.$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF'].'?'.$_SERVER['QUERY_STRING'];
			/**
			 * 检查用户是否关注
			 */
			if($quesreply["subscribe"]==1){
				$from_user = ! empty ( $_W ['openid'] ) ? $_W ['openid'] : $_W ['fans'] ['from_user'];
				$account = WeAccount::create ( $_W ['account'] );
				$userinfo = $account->fansQueryInfo ( $from_user );
				$followdesc=$quesreply["followdesc"];
				
				if (!empty($userinfo) && $userinfo["subscribe"]==1) {
					include $this->template('index');
				}else{
					setcookie("fromid",$fromid, time()+3600*12);
					include $this->template('subscribe');
				}
			}else{
				$userinfo=$this->getUserInfo($rid);
				$object = json_decode($userinfo);
				$nick=$object->nickname;
				$headimg=$object->headimgurl;
				setcookie("nick",$nick);
				setcookie("head",$headimg);
				include $this->template('index');
			}
			
			exit ();
	 	}
 	}
 	if($shyucount==0 && !empty($dtuser)){
 		$sql="SELECT * FROM " . tablename('dt_question_reply') . " WHERE rid = :rid LIMIT 1";
 		$quesreply = pdo_fetch($sql, array(':rid' => $rid));
 		$huodongname=$quesreply["huodongname"];
 		$followdesc=$quesreply["followdesc"];
 		$huodongdesc=$quesreply["huodongdesc"];
 		//企业信息
 		$qyname=$quesreply["qyname"];
 		$qylogo=$quesreply["qylogo"];
 		$qylink=$quesreply["qylink"];
 		$homebg=$quesreply["homebg"];
 		include $this->template('index');
 	}else{
		$sql="SELECT qrcode FROM " . tablename('dt_question_reply') . " WHERE rid = :rid LIMIT 1";
 		$qrcode = pdo_fetch($sql, array(':rid' => $rid));
		$questime=$reply["questiontime"];//答题总时间
		$questtimes=intval($questime)*60;
		$isrand=$reply["isrand"];//是否随机
		if($isrand==1){
			//从该活动的所有问题中随机抽出$total条数据
			$questionlist = pdo_fetchall("SELECT * FROM ". tablename('dt_question') . " WHERE rid = :rid  ORDER BY RAND() LIMIT ".intval($total), array(':rid' => intval($rid)));
		}else{
			//从该活动的所有问题中抽出前$total条数据
			$questionlist = pdo_fetchall("SELECT * FROM " . tablename('dt_question') . " WHERE rid=:rid ORDER BY id LIMIT ".intval($total), array(':rid' => $rid));
		}
		for($i=0;$i<count($questionlist);$i++){
			$quest=$questionlist[$i];
			$realanswers.=$quest["realanswer"].",";
		}
		$zongfen=intval($reply["zongfen"]);
		$onepoints=$zongfen/intval($total);//每题分值
		setcookie("stime", time(), time()+3600);
		include $this->template('dati');
 	}