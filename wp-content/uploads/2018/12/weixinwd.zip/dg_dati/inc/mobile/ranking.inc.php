<?php
global $_W,$_GPC;
load()->func('tpl');
	$rid=$_GPC["rid"];
	$acid=$_W['uniacid'];
	
	$openid = $_W["openid"];
	$nick=$_W['fans']['nickname'];
	$headimg=$_W['fans']['tag']['avatar'];
	$reply=pdo_fetch("SELECT * FROM " . tablename('dt_question_reply') . " WHERE rid = :rid ", array(':rid' => $rid));
	
	$userinfo = pdo_fetch("SELECT * FROM ". tablename("dt_userpoints")." WHERE openid=:openid and rid=:rid ORDER BY ID DESC LIMIT 1" , array(":openid"=>$openid,":rid"=>$rid));
	if(!empty($userinfo)){
		$id=intval($userinfo["id"]);
		$ljstatus=$userinfo["ljstatus"];
	}
	
	/**
	 * 分享
	 */
	
	$sharetitle=$reply["sharetitle"];//分享标题
	$sharecontent=$reply["sharecontent"];//分享内容
	$shareimg=$_W['attachurl'].$reply["shareimg"];//分享图片
	$isshareadd=$reply["isshareadd"];//是否 分享增加一次
	$sharelink="";
	$huodongname=$reply["huodongname"];
	$color=$reply["color"];
	if($isshareadd==0){
		$sharelink = $_W ['siteroot'] . 'app/' . $this->createMobileUrl ( 'index', array ('rid' => $rid));
	}else{
		$sharelink=$_W ['siteroot'] . 'app/' . $this->createMobileUrl ( 'index', array ('rid' => $rid,'fromid'=>$openid));
	}
	$sharelink = str_replace ( './', '', $sharelink );//分享链接
	$url='http://'.$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF'].'?'.$_SERVER['QUERY_STRING'];
	
	//排行榜显示数
	$phbnum=(!empty($reply["phbnum"]) && $reply["phbnum"]!=0)?$reply["phbnum"]:100;
	$phbimg=!empty($reply["phbimg"])?$_W['attachurl'].$reply["phbimg"]:MODULE_URL."resource/images/pic/ranking.png";
	//排行榜
	//$userlist=pdo_fetchall("SELECT openid,nick,headimg,MIN(sytime) AS sytime,MAX(points) AS points FROM (SELECT * FROM ". tablename('dt_userpoints')." WHERE rid=:rid ORDER BY points DESC,sytime ASC,TIME ) a GROUP BY a.openid ORDER BY points DESC,sytime ,time limit ".$phbnum, array(':rid' => $rid));
	$userlist=pdo_fetchall("SELECT 
	F2.* 
	FROM 
	(
		SELECT 
			openid, 
			points 
		from 
			(
				SELECT 
					openid, 
					max(points) points 
				FROM 
					(
						SELECT 
							openid, 
							max(points) points, 
							min(sytime) sytime, 
							nick, 
							headimg, 
							time 
						FROM 
							".tablename("dt_userpoints")." 
						WHERE 
							rid = :rid 
						GROUP by 
							openid, 
							points
					) a 
				GROUP by 
					a.openid
			) b
	) F1 
	INNER JOIN(
		SELECT 
			openid, 
			max(points) points, 
			min(sytime) sytime, 
			nick, 
			headimg, 
			time,
			(select addr from ".tablename("dt_userinfo")." i where i.openid=p.openid group by i.openid) as addr,	
			(select name from ".tablename("dt_userinfo")." i where i.openid=p.openid group by i.openid) as name
		FROM 
			".tablename("dt_userpoints")." p 
		WHERE 
			rid = :rid 
		GROUP by 
			openid, 
			points
	) F2 on F1.openid = F2.openid 
	and F1.points = F2.points 
	order by 
	points desc, 
	sytime, 
	time limit ".$phbnum, array(':rid' => $rid));
	$usersum=count($userlist);
	
	$paiming=0;
	for($i=0;$i<count($userlist);$i++){
		if($userlist[$i]["openid"]==$openid){
			$paiming=$i+1;
		}
	}
	//好友列表
	//$helplist=pdo_fetchall("select s.*,p.points as points,p.sytime as sytime from ".tablename("dt_usershare")." s left join ".tablename("dt_userpoints")." p on s.openid=p.openid group by s.openid ORDER BY p.points DESC,p.sytime where s.rid=:rid and s.fromuserid=:from",array(":rid"=>$rid,":from"=>$openid));
	$helplist=pdo_fetchall("SELECT s.*,p.points AS points,p.sytime AS sytime,(select addr from ".tablename("dt_userinfo")." i where i.openid=p.openid) as addr,	
			(select name from ".tablename("dt_userinfo")." i where i.openid=p.openid group by i.openid) as name FROM ".tablename("dt_usershare")." s LEFT JOIN ".tablename("dt_userpoints")." p ON s.openid=p.openid WHERE s.rid=:rid AND s.fromuserid=:from GROUP BY s.openid ORDER BY p.points DESC,p.sytime",array(":rid"=>$rid,":from"=>$openid));
	$helpcount=count($helplist);

	//倒计时
	$endsecond=$reply["end_time"];
	$now = time();
	$leftsecond=$endsecond-$now;
	//奖励设置
	$isjl=$reply["isjl"];
	$jltype=$reply["jltype"];
	$jlnum=$reply["jlnum"];
	$jlcontent=$reply["jlcontent"];
	//分享
	$sharetitle=$reply["sharetitle"];//分享标题
	$sharecontent=$reply["sharecontent"];//分享内容
	$shareimg=$_W["attachurl"].$reply["shareimg"];//分享图片
	$isshareadd=$reply["isshareadd"];//是否 分享增加一次
	$sharelink="";
	$color=$reply["color"];
	if($isshareadd==0){
		$sharelink = $_W ['siteroot'] . 'app/' . $this->createMobileUrl ( 'index', array ('rid' => $rid));
	}else{
		$sharelink=$_W ['siteroot'] . 'app/' . $this->createMobileUrl ( 'index', array ('rid' => $rid,'fromid'=>$openid));
	}
	$sharelink = str_replace ( './', '', $sharelink );//分享链接
	$url='http://'.$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF'].'?'.$_SERVER['QUERY_STRING'];
	
include $this->template('ranking');