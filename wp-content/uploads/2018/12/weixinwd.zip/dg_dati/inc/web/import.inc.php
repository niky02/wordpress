<?php
require_once MODULE_ROOT."/class/reader.php";
require_once MODULE_ROOT."/class/fileupload.php";

global $_GPC,$_W;
$acid=$_W["uniacid"];
$rid=$_GPC["rid"];
$filePath = $_GPC["excelpath"]; 

$up = new fileupload;
//设置属性(上传的位置， 大小， 类型， 名是是否要随机生成)
$up -> set("path", MODULE_ROOT."/resource/");
$up -> set("maxsize", 2000000);
$up -> set("allowtype", array("xls","xlsx"));
$up -> set("israndname", false);

//使用对象中的upload方法， 就可以上传文件， 方法需要传一个上传表单的名子 pic, 如果成功返回true, 失败返回false
if($up -> upload("excelfile")) {
	echo '<pre>';
	//获取上传后文件名子
	$filename=$up->getFileName();
	//创建对象
	$data = new Spreadsheet_Excel_Reader();
	//设置文本输出编码
	$data->setOutputEncoding('UTF-8');
	//读取Excel文件
	$data->read(MODULE_ROOT."/resource/".$filename);
	//$data->sheets[0]['numRows']为Excel行数
	for ($i = 2; $i <= $data->sheets[0]['numRows']; $i++) {
		$insert=array(
				"rid"=>$rid,
				"iacid"=>$acid,
				"uniacid"=>$acid,
				"type"=>$data->sheets[0]['cells'][$i][1],
				"question"=>str_replace('\r\n','',$data->sheets[0]['cells'][$i][2]),
				"realanswer"=>str_replace('\r\n','',$data->sheets[0]['cells'][$i][3]),
				"answerA"=>str_replace('\r\n','',$data->sheets[0]['cells'][$i][4]),
				"answerB"=>str_replace('\r\n','',$data->sheets[0]['cells'][$i][5]),
				"answerC"=>str_replace('\r\n','',$data->sheets[0]['cells'][$i][6]),
				"answerD"=>str_replace('\r\n','',$data->sheets[0]['cells'][$i][7]),
		);
		pdo_insert("dt_question",$insert);
	}
	message('上传完成！', referer(), 'success');
} else {
	//获取上传失败以后的错误提示
	//var_dump($up->getErrorMsg());
	message("上传失败！", referer(), 'error');
}

?>