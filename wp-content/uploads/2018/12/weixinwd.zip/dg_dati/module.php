<?php
/**
 * 答题模块定义
 *
 */
defined('IN_IA') or exit('Access Denied');

class Dg_datiModule extends WeModule {
	
	public $tablename = 'dt_question_reply';
	
	public function fieldsFormDisplay($rid = 0) {
		//要嵌入规则编辑页的自定义内容，这里 $rid 为对应的规则编号，新增时为 0
		global $_W;
		load ()->func ( 'tpl' );
		$reply=pdo_fetch("select * from ".tablename($this->tablename)."where rid=:rid",array(":rid"=>$rid));
		$now = time();
		if (!empty($rid)) {
			$reply = pdo_fetch("SELECT * FROM " . tablename($this->tablename) . " WHERE rid = :rid ORDER BY `id` DESC", array(':rid' => $rid));
		}
		if (!$reply) {
			$now = time();
			$reply = array(
					"status" => "1",
					"subscribe" => "1",
					"start_time"=>$now,
					"end_time"=>strtotime(date("Y-m-d H:i", $now + 7 * 24 * 3600)),
					"isrand"=>"1",
					"isshareadd"=>"1",
					"isjl"=>1,
					"jltype"=>0,
					"iswanshan"=>1,
					"xncount"=>0
			);
			$type=1;
		}
		include $this->template ('datisyscontrol');
	}

	public function fieldsFormValidate($rid = 0) {
		//规则编辑保存时，要进行的数据验证，返回空串表示验证无误，返回其他字符串将呈现为错误提示。这里 $rid 为对应的规则编号，新增时为 0
		return '';
	}

	public function fieldsFormSubmit($rid) {
		//规则验证无误保存入库时执行，这里应该进行自定义字段的保存。这里 $rid 为对应的规则编号
		//日志
		load()->func('logging');
		
		global $_GPC, $_W;
		load()->func('communication');
		$acid = $_W['uniacid'];
		$id = intval($_GPC['reply_id']);
		$link=str_replace("./", "", $_W['siteroot']."app/".$this->createMobileUrl("index",array("rid"=>$rid)));
		$insert = array(
				'rid' => $rid,
				'iacid'=>$acid,
				'uniacid' => $acid,
				'huodongname' => $_GPC['huodongname'],
				'huodongdesc' => htmlspecialchars_decode($_GPC['huodongdesc']),
				'huodongurl' => $link,
				'hdpicture' => $_GPC['hdpicture'],
				'status' => $_GPC['status'],
				'subscribe' => $_GPC['subscribe'],
				'sharetitle' => $_GPC['sharetitle'],
				'shareimg'=>$_GPC['shareimg'],
				'sharecontent' => $_GPC['sharecontent'],
				'start_time' =>strtotime($_GPC['datelimit']['start']),
				'end_time' => strtotime($_GPC['datelimit']['end']),
				'followdesc'=>$_GPC['followdesc'],
				"questioncount"=>$_GPC['questioncount'],
				"questiontime"=>$_GPC['questiontime'],
				"isrand"=>$_GPC['isrand'],
				"isshareadd"=>$_GPC['isshareadd'],
				"qyname"=>$_GPC["qyname"],
				'qrcode'=>$_GPC['qrcode'],
				"qylogo"=>$_GPC["qylogo"],
				"qylink"=>$_GPC["qylink"],
				"homebg"=>$_GPC["homebg"],
				"zongfen"=>$_GPC["zongfen"],
				"color"=>$_GPC["color"],
				"isjl"=>$_GPC["isjl"],
				'jltype'=>$_GPC['jltype'],
				'jlnum'=>$_GPC['jlnum'],
				'jlcontent'=>$_GPC['jlcontent'],
				'hxnum'=>$_GPC['hxnum'],
				'iswanshan'=>$_GPC['iswanshan'],
				'phbnum'=>$_GPC['phbnum'],
				'dtcount'=>$_GPC['dtcount'],
				'phbimg'=>$_GPC['phbimg'],
				'maxcount'=>$_GPC['maxcount'],
				'music'=>$_GPC['music'],
				'xncount'=>$_GPC['xncount']
		);
		$table='dt_question_reply';
		if (empty($id)) {
			$ret = pdo_insert($this->tablename, $insert);
			if (!empty($ret)) {
				message('添加答题活动成功！');
			}else{
				message('添加答题活动失败！');
			}
		}else{
			pdo_update($this->tablename, $insert, array('id' => $id));
		}
	}

	public function ruleDeleted($rid) {
		//删除规则时调用，这里 $rid 为对应的规则编号
	}

	
}