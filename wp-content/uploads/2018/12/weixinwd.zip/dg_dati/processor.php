<?php
/**
 * 答题模块处理程序
 
 */
defined('IN_IA') or exit('Access Denied');

class Dg_datiModuleProcessor extends WeModuleProcessor {
	public function respond() {
		global $_W;
		$rid = $this->rule;
		
		$quesreply = pdo_fetch("SELECT * FROM " . tablename('dt_question_reply') . " WHERE rid = :rid LIMIT 1", array(':rid' => $rid));
		
		$from = $this->message ['from'];
		
		if ($quesreply == false) {
			return $this->respText("抱歉,活动已取消...");
		}
// 		if ($quesreply['start_time'] > time()) {
// 			return $this->respText("抱歉,活动将于".date('Y-m-d H:i:s', $quesreply['start_time'])."开始，请耐心等待...");
// 		}
// 		if ($quesreply['end_time'] < time()) {
// 			return $this->respText("抱歉,活动已经结束...");
// 		}
		
		if ($quesreply['status']==0) {
			return $this->respText("抱歉,活动已经被管理员暂停...");
		}
		
		//这里定义此模块进行消息处理时的具体过程, 请查看微动力文档来编写你的代码
		return $this->respNews(array(
				'Title' => $quesreply["huodongname"],
				'Description' => "",//$quesreply["huodongdesc"]
				'PicUrl' => $quesreply["hdpicture"],
				//'PicUrl' => "../addons/face_recognition/resource/pic/1-1.png",
				'Url' => $this->createMobileUrl('index', array('rid' => $rid)),
		));
	}
}