<?php
defined('IN_IA') or exit('Access Denied');
define('ROOT_PATH', str_replace('site.php', '', str_replace('\\', '/', __FILE__)));
define('INC_PATH',ROOT_PATH.'inc/');

class Dg_datiModuleSite extends WeModuleSite {	
	public function doWebManage() {
		global $_GPC, $_W;
		
		load()->model('reply');
		$pindex = max(1, intval($_GPC['page']));
		$psize = 20;
		$params = array();
		$acid=$_W['uniacid'];
		$total = pdo_fetchcolumn("SELECT count(id) FROM " . tablename('dt_question_reply') . " WHERE iacid=" . $acid);
		
		$sql = "select * from ".tablename("dt_question_reply")." where uniacid = :iacid";
		$params = array();
		$params[':iacid'] = $acid;

		$list = pdo_fetchall($sql,$params);
		$pager = pagination($total, $pindex, $psize);
		
		include $this->template ( 'manage' );
	}
	
	/**
	 * 答题管理
	 */
	public function doWebDatiManage(){
		global $_GPC, $_W;
		$rid=intval($_GPC["rid"]);
		if($rid==0){
			$rid=$_COOKIE["rid"];
		}
		$params = array();
		$acid=$_W['uniacid'];
		
		$list = pdo_fetchall("SELECT * FROM " . tablename('dt_question') . " WHERE rid = :rid order by id desc", array(':rid' => $rid));
		setcookie("rid",$rid);
		include $this->template('datimanage');
	}
	
	/**
	 * 添加,编辑答题
	 */
	public function doWebAddDati(){
		global $_GPC, $_W;
		$rid=$_COOKIE["rid"];
		load()->func('tpl');
		$acid = empty($_W['acid']) ? $_W['uniacid'] : $_W['acid'];
		$id = intval($_GPC['id']);
		$question;
		if(!empty($id) && $id!=0){
			$question = pdo_fetch("SELECT * FROM " . tablename('dt_question') . " WHERE id = :id ", array(':id' => $id));
		}else{
			$question = array(
					"type" => "1",
			);
		}
		include $this->template('adddati');
	}
	
	public function doWebEditDati(){
		global $_GPC, $_W;
		$rid=intval($_GPC["rid"]);
		
		$acid=$_W['uniacid'];
		$id = intval($_GPC['id']);
		$insert;
		
		if($_GPC['type']==1){
			$insert = array(
					'rid' => $rid,
					'iacid'=>$acid,
					'uniacid' => $acid,
					'question' => $_GPC['question'],
					'quesimage'=>$_GPC['quesimage'],
					'realanswer' => $_GPC['realans'],
					'type' => $_GPC['type'],
					'points' => $_GPC['points'],
					'answerA'=> $_GPC['answerA'],
					'answerB'=> $_GPC['answerB'],
					'answerC'=> $_GPC['answerC'],
					'answerD'=> $_GPC['answerD'],
			);
		}else{
			$insert = array(
					'rid' => $rid,
					'iacid'=>$acid,
					'uniacid' => $acid,
					'question' => $_GPC['question'],
					'quesimage'=>$_GPC['quesimage'],
					'realanswer' => implode("",$_GPC['realanswer']),
					'type' => $_GPC['type'],
					'points' => $_GPC['points'],
					'answerA'=> $_GPC['answerA'],
					'answerB'=> $_GPC['answerB'],
					'answerC'=> $_GPC['answerC'],
					'answerD'=> $_GPC['answerD'],
			);
		}
		$ret;
		//先删除
		pdo_delete("dt_question", array('id' => $id));
		//再插入
		$ret = pdo_insert("dt_question", $insert);
		
		if (!empty($ret)) {
			message('操作成功！', $this->createWebUrl("datimanage",array("rid"=>$rid)), 'success');
		}else{
			message('操作失败！', referer(), 'error');
		}
	}
	
	public  function doWebDeleteDati(){
		global $_GPC, $_W;
		$rid=intval($_GPC["rid"]);
		$id=intval($_GPC["id"]);
		pdo_delete('dt_question', array('rid' => $rid,'id' => $id));
		message('删除成功！', referer(), 'success');
	}
	
	
	/**
	 * 操作活动开始或者结束
	 */
	public function doWebHdControl(){
		global $_GPC, $_W;
	
		$status = $_GPC['status'];
		$rid=$_GPC["rid"];
	
		$data = array('status' => $status);
		$params = array('rid'=>$rid);
		$re=pdo_update('dt_question_reply',$data,$params);
		if(!empty($re)){
			message('操作成功！', referer(), 'success');
		}else{
			message('操作失败！', referer(), 'error');
		}
	}
	
	public function doWebDelete() {
		global $_GPC, $_W;
		$rid = intval($_GPC['rid']);
		// $rule = pdo_fetch("SELECT id, module FROM " . tablename('rule') . " WHERE id = :id and uniacid=:iacid", array(':id' => $rid, ':iacid' => $_W['uniacid']));
		// if (empty($rule)) {
			// message('抱歉，要修改的规则不存在或是已经被删除！');
		// }
		// if (pdo_delete('rule', array('id' => $rid))) {
			// pdo_delete('rule_keyword', array('rid' => $rid));
			////删除统计相关数据
			// pdo_delete('stat_rule', array('rid' => $rid));
			// pdo_delete('stat_keyword', array('rid' => $rid));
			////调用模块中的删除
			// $module = WeUtility::createModule($rule['module']);
			// if (method_exists($module, 'ruleDeleted')) {
				// $module->ruleDeleted($rid);
			// }
		// }
		pdo_delete('rule_keyword', array('rid' => $rid));
		pdo_delete('stat_rule', array('rid' => $rid));
		pdo_delete("dt_question_reply", array('rid' => $rid));
		
		message('操作成功！', referer(), 'success');
	}
	
	public function doWebDeleteAll() {
		global $_GPC, $_W;
		$idArr = $_GPC['ridArr'];
		$count=0;
		for($i=0;$i<count($idArr);$i++){
			$id=$idArr[$i];
			pdo_delete("dt_question_reply", array('rid' => $id));
			pdo_delete('rule_keyword', array('rid' => $rid));
			pdo_delete('stat_rule', array('rid' => $rid));
		}
		$fmdata=array(
			"errno"	=>0
		);
		echo json_encode($fmdata);
	}
	/**
	 * 参与记录
	 */
	public function doWebRecord(){
		global $_GPC, $_W;
		load()->model('reply');
		load()->func('tpl');
		$rid=$_GPC["rid"];
		$acid=$_W['uniacid'];
		//分页
		$pindex = max(1, intval($_GPC['page']));
		$psize = 10;
		$reply=pdo_fetch("SELECT * FROM " . tablename('dt_question_reply') . " WHERE rid = :rid ", array(':rid' => $rid));
		$iswanshan=$reply["iswanshan"];
		$list = pdo_fetchall("SELECT * FROM " . tablename('dt_userpoints') . " WHERE rid=" . $rid.' and iacid='.$acid." GROUP BY openid ORDER BY points DESC,sytime");
		$total=count($list);
		$userlist=pdo_fetchall("SELECT 
		F2.*,u.*
		FROM 
		(
			SELECT 
				openid, 
				points 
			from 
				(
					SELECT 
						id as pid,
						openid, 
						max(points) points 
					FROM 
						(
							SELECT 
								id,
								openid, 
								max(points) points, 
								min(sytime) sytime, 
								nick, 
								headimg, 
								time 
							FROM 
								".tablename("dt_userpoints")." 
							WHERE 
								rid = :rid 
							GROUP by 
								id,
								openid, 
								points
						) a 
					GROUP by 
						a.openid
				) b
		) F1 
		INNER JOIN(
			SELECT 
				id as pid,
				openid,
				rid,
				max(points) points, 
				min(sytime) sytime, 
				nick, 
				headimg, 
				time 
			FROM 
				".tablename("dt_userpoints")." 
			WHERE 
				rid = :rid 
			GROUP by 
				id,
				openid, 
				points
		) F2 on F1.openid = F2.openid 
		and F1.points = F2.points 
		LEFT JOIN ".tablename("dt_userinfo")." u ON F2.openid=u.openid and F2.rid=u.rid
		order by 
		points desc, 
		sytime, 
		time LIMIT ".($pindex - 1) * $psize.",". $psize,array(':rid' => $rid));
		$pager = pagination($total, $pindex, $psize);
		
		include $this->template("record");
	}
	/**
	 * 修改参与记录
	 */
	public function doWebEditRecord(){
		global $_GPC, $_W;
		load ()->func ( 'tpl' );
		$id=$_GPC["id"];
		$record=pdo_fetch("SELECT * FROM ". tablename('dt_userpoints')." WHERE id=:id", array(':id' => $id));
		
		include $this->template("editrecord");
	}
	public function doWebEditRecord2(){
		global $_GPC, $_W;
		$id=$_GPC["id"];
		$points=$_GPC["points"];
		$data = array(
				"points"=>$points
		);
		pdo_update('dt_userpoints', $data, array('id' => $id));
		$fmdata = array(
				"success" =>1,
				"msg" => "更新成功"
		);
		echo json_encode($fmdata);
	}
	/**
	 * 删除参与记录
	 */
	public function doWebdeleterecord(){
		global $_GPC, $_W;
		$rid = intval($_GPC['rid']);
		$id=$_GPC['id'];
		$openid=$_GPC['openid'];
		pdo_delete("dt_userpoints", array('openid'=>$openid,'rid' => $rid));//删除参与者数据
		message('操作成功！', referer(), 'success');
	}
	//导出数据
	public function doWebdownload(){
		global $_GPC,$_W;
		$rid= intval($_GPC['rid']);
		$acid=$_W['uniacid'];
		if(empty($rid)){
			message('抱歉，传递的参数错误！','', 'error');
		}
		$reply = pdo_fetch("SELECT * FROM ".tablename('dt_question_reply')." WHERE rid = :rid", array(':rid' => $rid));
		$userlist=pdo_fetchall("SELECT 
		F2.*,u.* 
		FROM 
		(
			SELECT 
				openid, 
				points 
			from 
				(
					SELECT 
						openid, 
						max(points) points 
					FROM 
						(
							SELECT 
								openid, 
								max(points) points, 
								min(sytime) sytime, 
								nick, 
								headimg, 
								time 
							FROM 
								".tablename("dt_userpoints")." 
							WHERE 
								rid = :rid 
							GROUP by 
								openid, 
								points
						) a 
					GROUP by 
						a.openid
				) b
		) F1 
		INNER JOIN(
			SELECT 
				openid, 
				rid,
				max(points) points, 
				min(sytime) sytime, 
				nick, 
				headimg, 
				time 
			FROM 
				".tablename("dt_userpoints")." 
			WHERE 
				rid = :rid 
			GROUP by 
				openid, 
				points
		) F2 on F1.openid = F2.openid 
		and F1.points = F2.points 
		LEFT JOIN ".tablename("dt_userinfo")." u ON F2.openid=u.openid and F2.rid=u.rid
		order by 
		points desc, 
		sytime, 
		time", array(':rid' => $rid));
		$tableheader = array('序号','昵称', '头像', '分数','用时' ,'参与时间','姓名',"手机号","备注");
		$html = "\xEF\xBB\xBF";
		foreach ($tableheader as $value) {
			$html .= $value . "\t ,";
		}
		$html .= "\n";
		foreach ($userlist as $mid => $value) {
			$pid=$value["id"];
			$p = $mid + 1;
			$html .= $p . "\t ,";
			$html .= $value['nick'] . "\t ,";
			$html .= $value['headimg'] . "\t ,";
			$html .= $value['points'] . "\t ,";
			$html .= $value['sytime'] . "\t ,";
			$html .= $value['time'] . "\t ,";
			$html .= $value['name'] . "\t ,";
			$html .= $value['phone'] . "\t ,";
			$html .= $value['addr'] . "\t ,";
			$html .= "\n";
		}
		$filename = $reply['huodongname'].'_'.$rid;
	
		header("Content-type:text/csv");
		header("Content-Disposition:attachment; filename=".$filename.".csv");
	
		echo $html;
		exit();
	}
	/**
	 * 同步用户信息
	 */
	public function doWebupgred(){
		global $_GPC,$_W;
		load()->model('mc');
		$rid= intval($_GPC['rid']);
		$acid=$_W['uniacid'];
		$psql="select * from ".tablename('dt_userpoints')." where rid=:rid";
		$plist=pdo_fetchall($psql,array(':rid' => $rid));
	
		for($i=0;$i<count($plist);$i++){
			$fan=mc_fansinfo($plist[$i]["openid"],$acid,$acid);
			$para = array(
					'nick'=>$fan['nickname'],
					'headimg'=>$fan["tag"]['avatar']
			);
			pdo_update('dt_userpoints', $para, array('id' => $plist[$i]["id"]));
		}
		message('操作成功！', referer(), 'success');
	}
	/**
	 * 获取用户信息
	 */
	public function getUserInfo($rid){
		global $_GPC,$_W;
		$redirect_uri='http://'.$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF'].'?'.$_SERVER['QUERY_STRING'];
		$cuser_info=$_GPC[$rid.'dg_user_info'];
	
		if(empty($cuser_info)){
			$oauth2=new Oauth2($_W['oauth_account']);
	
			if(empty($_GPC['code'])){
				$oauth2->authorization_code($redirect_uri, Oauth2::$SCOPE_USERINFO,'we7sid-'.$_W['session_id']);
			}
			$code=$_GPC['code'];
	
			$access_token=$oauth2->getOauthAccessToken($code);
	
			$user_info=$oauth2->getOauthUserInfo($access_token['openid'], $access_token['access_token']);
	
			$cookieKey=$rid."dg_user_info";
			$cuser_info=$oauth2::setClientCookieUserInfo($user_info,$cookieKey);
		}
	
		$user_info=base64_decode($cuser_info);
		return $user_info;
	}
	
	/**
	 * 导入题库
	 */
	public function dowebimportdati(){
		global $_GPC, $_W;
		load()->func('tpl');
		$rid=$_GPC["rid"];
		include $this->template("import");
	}
	
	/**
	 * 核销
	 */
	public function domobilehexiao(){
		global $_GPC, $_W;

		$id=$_GPC["id"];
		$rid=$_GPC["rid"];
		$hxnum=$_GPC["hxnum"];
		$reply = pdo_fetch("SELECT * FROM " . tablename('dt_question_reply') . " WHERE rid = :rid ", array(':rid' => $rid));
		$fmdata;
		if($reply["hxnum"]==$hxnum){
			$data=array("ljstatus"=>1,"ljtime"=>time());
			$param=array("id"=>$id);
			$res=pdo_update("dt_userpoints",$data,$param);
			if($res){
				$fmdata=array("success"=>1,"msg"=>"核销成功");
			}else{
				$fmdata=array("success"=>-1,"msg"=>"核销失败");
			}
		}else{
			$fmdata=array("success"=>-1,"msg"=>"核销码输入有误！");
		}
		echo json_encode($fmdata);
		exit();
	}
	/**
	 * 添加成绩
	 */
	public function domobileaddchengji(){
		global $_W,$_GPC;
		load()->func('tpl');
		$rid=$_GPC["rid"];
		$acid=$_W['uniacid'];
		$reply=pdo_fetch("SELECT * FROM " . tablename('dt_question_reply') . " WHERE rid = :rid ", array(':rid' => $rid));
		$zongfen=intval($reply["zongfen"]);
		$openid = $_W["openid"];
		if($reply["subscribe"]==1){
			$nick=$_W['fans']['nickname'];
			$headimg=$_W['fans']['tag']['avatar'];
		}else{
			$userinfo=$this->getUserInfo($rid);
			$obj = json_decode($userinfo);
			$nick=$obj->nickname;
			$headimg=$obj->headimgurl;
		}
		
		$fromid=$_GPC["fromid"];//分享人openid
		$points=intval($_GPC["totalpoints"])<=$zongfen?intval($_GPC["totalpoints"]):$zongfen;
		//$sytime=$_GPC["totaltime"];
		$stime=$_COOKIE["stime"];
		$sytime=time()-intval($stime);
		$questime=$reply["questiontime"];//答题总时间
		if(intval($sytime)>intval($questime)*60){
			$sytime=intval($questime)*60;
		}
		$time=date('Y-m-d H:i:s',time());
		$name=$_GPC["name"];
		$phone=$_GPC["phone"];
		$addr=$_GPC["addr"];
		
		//如果是通过别人分享进来的
		if(!empty($fromid)){
			$relist=pdo_fetchall("select * from ".tablename("dt_usershare")." where fromuserid=:fromid and openid=:openid and rid=:rid",array(":fromid"=>$fromid,":openid"=>$openid,":rid"=>$rid));
			//如果超过分享次数上限
			$sharelist=pdo_fetchall("select * from ".tablename("dt_usershare")." where fromuserid=:fromid and rid=:rid",array(":fromid"=>$fromid,":rid"=>$rid));
			$is_max=0;
			if($reply["maxcount"]!=0 && !empty($reply["maxcount"]) && $reply["maxcount"]<=count($sharelist)){
				$is_max=1;
			}
			
			if(count($relist)>0 || $is_max==1){
				//如果已经分享过，则不处理
			}else{
				
				//更新分享人的答题次数+1
				$usercount = pdo_fetch("SELECT * FROM ". tablename("dt_usercount")." WHERE openid=:openid and rid=:rid LIMIT 1" , array(":openid"=>$fromid,":rid"=>$rid));
				$shyucount=intval($usercount["shyucount"])+1;
				$data=array("shyucount"=>$shyucount);
				$param=array("openid"=>$fromid);
				pdo_update("dt_usercount",$data,$param);
			}
			//添加成绩记录
			$params = array("rid"=>$rid,"iacid"=>$acid, "uniacid"=>$acid,"openid"=>$openid, "nick"=>$nick,
					"headimg"=>$headimg,"points"=>$points,"sytime"=>$sytime,"sycount"=>0,"time"=>$time,
					"ljstatus"=>0,"ljtime"=>0);
			pdo_insert("dt_userpoints", $params);
			$id=pdo_insertid();
			
			//判断是否有记录
// 			$usercount0 = pdo_fetch("SELECT * FROM ". tablename("dt_usercount")." WHERE openid=:openid and rid=:rid LIMIT 1" , array(":openid"=>$openid,":rid"=>$rid));
// 			if(empty($usercount0)){
// 				//添加答题次数记录
// 				$params = array("rid"=>$rid,"userid"=>$id,"openid"=>$openid,"shyucount"=>intval($reply["dtcount"])>0?intval($reply["dtcount"])-1:0);
// 				pdo_insert("dt_usercount", $params);
// 			}else{
// 				$shyucount0=intval($usercount0["shyucount"])>0?intval($usercount0["shyucount"])-1:0;
// 				$data=array("shyucount"=>$shyucount0);
// 				$param=array("openid"=>$openid);
// 				pdo_update("dt_usercount",$data,$param);
// 			}
			//添加分享记录
			$shareparams = array("rid"=>$rid,"iacid"=>$acid, "uniacid"=>$acid,"fromuserid"=>$fromid, "openid"=>$openid,"nick"=>$nick,"headimg"=>$headimg,"addtime"=>$time);
			$sharetable='dt_usershare';
			pdo_insert($sharetable, $shareparams);
			$result=pdo_fetchall("select * from ".tablename("dt_userinfo")." where openid=:openid and rid=:rid",array(":openid"=>$openid,":rid"=>$rid));
			if(count($result)>0){
			
			}else{
				//添加用户信息
				$pars = array("rid"=>$rid,"iacid"=>$acid, "uniacid"=>$acid,"openid"=>$openid,"name"=>$name,"phone"=>$phone,"addr"=>$addr,"addtime"=>time());
				pdo_insert("dt_userinfo", $pars);
			}
		}else{
			//添加成绩记录
			$params = array("rid"=>$rid,"iacid"=>$acid, "uniacid"=>$acid,"openid"=>$openid, "nick"=>$nick,
					"headimg"=>$headimg,"points"=>$points,"sytime"=>$sytime,"sycount"=>0,"time"=>$time,
					"ljstatus"=>0,"ljtime"=>0);
			pdo_insert("dt_userpoints", $params);
			$id=pdo_insertid();
			$shyucount=empty($reply["dtcount"])?0:$reply["dtcount"];
			
			//判断是否有记录
			$usercount2 = pdo_fetch("SELECT * FROM ". tablename("dt_usercount")." WHERE openid=:openid and rid=:rid LIMIT 1" , array(":openid"=>$openid,":rid"=>$rid));
			if(empty($usercount2)){
				//添加答题次数记录
				$params = array("rid"=>$rid,"userid"=>$id,"openid"=>$openid,"shyucount"=>intval($reply["dtcount"])>0?intval($reply["dtcount"])-1:0);
				pdo_insert("dt_usercount", $params);
			}else{
				$shyucount2=intval($usercount2["shyucount"])>0?intval($usercount2["shyucount"])-1:0;
				$data=array("shyucount"=>$shyucount2);
				$param=array("openid"=>$openid);
				pdo_update("dt_usercount",$data,$param);
			}
			$result=pdo_fetchall("select * from ".tablename("dt_userinfo")." where openid=:openid and rid=:rid",array(":openid"=>$openid,":rid"=>$rid));
			if(count($result)>0){

			}else{
				//添加用户信息
				$pars = array("rid"=>$rid,"iacid"=>$acid, "uniacid"=>$acid,"openid"=>$openid,"name"=>$name,"phone"=>$phone,"addr"=>$addr,"addtime"=>time());
				pdo_insert("dt_userinfo", $pars);
			}
			$ljstatus=0;
		}
		
		$fmdata["success"]=1;
		echo json_encode($fmdata);
	}
}