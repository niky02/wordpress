<?php
if (!isset($_COOKIE['username'])) {
    header("Location: ./login.php"); 
}
if (!isset($_COOKIE['password'])) {
    header("Location: ./login.php"); 
}
?>