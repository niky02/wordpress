<div id="footer">
	<div class="container">
		<div class="line">
 
			<p>久草CMS版本：<?php echo $version; ?>&nbsp;&nbsp;&nbsp;
			
		</div>
	</div>
</div>
