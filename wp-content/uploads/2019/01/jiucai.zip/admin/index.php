

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php include('inc_head.php') ?>
</head>
<body>
<?php

include('check.php');
include("../inc/version.php");

include("../inc/jiekou.php");



	if($versions == $version){
		
	}else{
		?>
		<script type="text/javascript">
alert("您好您的版本是最新版本"); 


</script>
<?php
	}								
	?>
<?php include('inc_header.php') ?>
<div id="content">
	<div class="container">
		<div class="line-big">
			<?php include('inc_left.php') ?>
<?php echo $gongao;?>
		</div>
	</div>
</div>
<?php include('inc_footer.php') ?>
</body>
</html>