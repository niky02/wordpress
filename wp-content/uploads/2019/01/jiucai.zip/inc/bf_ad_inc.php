<?php
define('bf_ad1', '');
define('bf_ad1s', '');
define('bf_ad2', '');
define('bf_ad2s', '');
define('bf_ad3', '');
define('bf_ad3s', '');
define('bf_ad4', '');
define('bf_ad4s', '');
define('bf_ad5', '');
define('bf_ad5s', '');
?>