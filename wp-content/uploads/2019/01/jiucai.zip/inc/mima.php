<?php
//后台密码
define('USERNAME', '9ccms');
define('PASSWORD', '9ccms');
define('IPPASS', '');
?>