<?php
$moban = "demo";
?>