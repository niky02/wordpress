<?php
//友情链接设置
define('XXXXXXXXXX13', '&&http://www.isexys.com###无广告导航&&
&&http://www.isexys.ml###isexys福利社&&');
?>