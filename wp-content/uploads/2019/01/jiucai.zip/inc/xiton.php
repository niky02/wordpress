<?php
//系统设置
define('XXXXXXXXXX1', 'X8AV在线');
define('XXXXXXXXXX2', 'X8AV-精品成人视频在线观看');
define('XXXXXXXXXX3', '色色在线,色色五月天,91秦先生,老司机,在线观看,波多野结衣');
define('XXXXXXXXXX4', '色色在线,色色五月天,91秦先生,老司机,在线观看,波多野结衣');
define('XXXXXXXXXX5', '69tang');
define('XXXXXXXXXX6', 'adcopartner#gmail.com');
define('XXXXXXXXXX8', '/image/logo.jpg');
?>