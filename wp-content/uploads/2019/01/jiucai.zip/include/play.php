<?php
error_reporting (E_ALL);
set_time_limit(0);
date_default_timezone_set ( "Asia/Shanghai" );
$indexxml=$ajax."/upload/xml/play_".$_GET['id'].".xml";
phpQuery::newDocumentFile($indexxml);
 function daohang($moban) {
	
$lobj = pq('studentcareer > daohang');
   foreach($lobj as $item)
   {
		$id=trim(pq($item)->find('id')->html());
		$name=trim(pq($item)->find('name')->html());		
		include('./template/'.$moban.'/html/home_daohang.html');
   }
}
//解析SEO数组开始			
$_Location = pq('studentcareer > seo');     
$title=$_Location->find('title')->html();        
$keywords=$_Location->find('keywords')->html();         
$description=$_Location->find('description')->html();
$title=XXXXXXXXXX2.$title;
$keywords=XXXXXXXXXX3.$keywords;
$description=XXXXXXXXXX4.$description; 
//解析SEO数组结束
//解析SEO数组开始
function liebiao($moban,$ajax) {
$lobj = pq('studentcareer > video');
   foreach($lobj as $item)
   {
		$id=trim(pq($item)->find('id')->html());
		$name=trim(pq($item)->find('name')->html());		
		$m3u8=trim(pq($item)->find('m3u8')->html());
		include('./template/'.$moban.'/html/play_list.html');	
   }
}   
//解析SEO数组结束
//友链开始
function youlian($youlian) {
echo $XXXXXXXXXX13 = preg_replace('/&&(.*?)###(.*?)&&/si',$youlian,XXXXXXXXXX13);

}
//友链结束
include('./template/'.$moban.'/html/play.html');
?>


