<?php

//XML标签配置
//SEO标题，关键词，概括开始
function SEO($SEO) {
	$dom = new DOMDocument();	

		$dom->load("http://127.0.0.1/upload/xml/type_".$_GET['type']."_".$_GET['page'].".xml");
	$seo = $dom->getElementsByTagName('seo');
	foreach($seo as $k => $p) {
		foreach(array('seo') as $x) {		
				$SEO=$SEO;$SEO = $p->getElementsByTagName($SEO);$SEO= $SEO->item(0)->nodeValue;

				echo $SEO;
		}
	}
}
//SEO标题，关键词，概括结束


//数据列表开始
function liebiao($moban) {

	$dom = new DOMDocument();
		$dom->load("http://127.0.0.1/upload/xml/type_".$_GET['type']."_".$_GET['page'].".xml");
	$video = $dom->getElementsByTagName('video');

	foreach($video as $k => $p) {
		    foreach(array('video') as $x) {	
			$id="id";$id = $p->getElementsByTagName($id);$id= $id->item(0)->nodeValue;
			
			$name="name";$name = $p->getElementsByTagName($name);$name= $name->item(0)->nodeValue;
			$pic="pic";$pic = $p->getElementsByTagName($pic);$pic= $pic->item(0)->nodeValue;$pic="http://127.0.0.1/".$pic;

			include('./template/'.$moban.'/html/index_list.html');			

			}
	}
}
//数据列表结束
//分类分页配置开始
function fenye($fenye) {
	$dom = new DOMDocument();
		$dom->load("http://127.0.0.1/upload/xml/type_".$_GET['type']."_".$_GET['page'].".xml");
$peizhi = $dom->getElementsByTagName('peizhi');
	foreach($peizhi as $k => $p) {
		foreach(array('peizhi') as $x) {
			$fenlei="fenlei";$fenlei = $p->getElementsByTagName($fenlei);$fenlei= $fenlei->item(0)->nodeValue;
			$zonyeshu="zonyeshu";$zonyeshu = $p->getElementsByTagName($zonyeshu);$zonyeshu= $zonyeshu->item(0)->nodeValue;
			$shouye="shouye";$shouye = $p->getElementsByTagName($shouye);$shouye= $shouye->item(0)->nodeValue;	
			$shangyiye="shangyiye";$shangyiye = $p->getElementsByTagName($shangyiye);$shangyiye= $shangyiye->item(0)->nodeValue;	
			$dangqianye="dangqianye";$dangqianye = $p->getElementsByTagName($dangqianye);$dangqianye= $dangqianye->item(0)->nodeValue;	
			$xiayiye="xiayiye";$xiayiye = $p->getElementsByTagName($xiayiye);$xiayiye= $xiayiye->item(0)->nodeValue;
			$weiye="weiye";$weiye = $p->getElementsByTagName($weiye);$weiye= $weiye->item(0)->nodeValue;
			$fenye=preg_replace('/##fenlei##/si',$fenlei,$fenye);
			$fenye=preg_replace('/##zonyeshu##/si',$zonyeshu,$fenye);
			$fenye=preg_replace('/##shouye##/si',$shouye,$fenye);
			$fenye=preg_replace('/##shangyiye##/si',$shangyiye,$fenye);
			$fenye=preg_replace('/##dangqianye##/si',$dangqianye,$fenye);
			$fenye=preg_replace('/##xiayiye##/si',$xiayiye,$fenye);
		echo	$fenye=preg_replace('/##weiye##/si',$weiye,$fenye);				
		}
	}
}
//分类分页配置结束
//友链开始
function youlian($youlian) {
echo $XXXXXXXXXX13 = preg_replace('/&&(.*?)###(.*?)&&/si',$youlian,XXXXXXXXXX13);

}
//友链结束
//echo $title;
//echo $keywords;
//echo $description;
//liebiao('<a><img src="##pic##">##id####name##</a>');  
include('./template/'.$moban.'/html/index.html');
?>


