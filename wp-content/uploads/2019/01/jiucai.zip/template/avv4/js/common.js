//ͼƬ����
var timers = new Array;
var images = new Array;

function changeThumb(id, url) {
    document.getElementById(id).src = url;
}


    $("body").on('mouseover', "img[id*='video_']", function() {
        cdn_url = $(this).attr("images");
        var id = $(this).attr("id");
        var split = id.split('_');
        var vid = split[1];

        for (var i = 1; i <= 20; i++) {
            var img_url = cdn_url + i + '.jpg';
            images[i] = new Image();
            images[i].src = img_url;
            timers[i] = setTimeout("changeThumb('" + id + "','" + img_url + "')", i * 400);
            //no $this
        }
    }).on('mouseout', "img[id*='video_']", function() { //��ԭ
        cdn_url = $(this).attr("images");
        for (var i = 1; i <= 20; i++) {
            clearTimeout(timers[i]);
            //die
        }
        $(this).attr('src', cdn_url + '1.jpg');
    });
    $(function() {
        $("img.lazy").lazyload({
            effect: "fadeIn"
        });
    });


function rand() {
    $("#rand").html('<div id="lodding" class="text-center"><img src="/static/images/load.gif"></div>');
    $.ajax({
        url: "/ajax/rand.html",
        success: function(data) {
            $("#rand").html(data);
        },
        error: function(data) {
            dialog.error('����ʧ��');
        }
    });
}