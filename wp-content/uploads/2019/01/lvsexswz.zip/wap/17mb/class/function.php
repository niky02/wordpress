<?php
	function object_array($array){
	  if(is_object($array)){
		$array = (array)$array;
	  }
	  if(is_array($array)){
		foreach($array as $key=>$value){
		  $array[$key] = object_array($value);
		}
	  }
	  return $array;
	} 
	function ugbk($v){
		$v = iconv("utf-8","gbk",$v);
		return $v;
	}
	function chsql($str){
		$re = '/^\'|!|%|_|-|\^|<|>|select|update|delete|union|into|load_file|outfile$/';
		if(preg_match($re,$str)){
			return false;
		}
		else{
			return true;
		}
	}
	function strsql($str){
		$re = array('/\'|!|%|_|-|^|<|>|select|update|delete|union|into|load_file|outfile/');
		$str = htmlspecialchars($str);
		$str = addslashes($str);
		$str = preg_replace($re,'',$str);
		
		return $str;
	}
?>