<?php
function opf($txtdir,$aid){
	$opffile = $txtdir.'/'.intval($aid/1000).'/'.$aid.'/index.opf';
	if(file_exists($opffile)){
		$opf = @file_get_contents($opffile);
		$find1 = '<?xml version="1.0" encoding="ISO-8859-1"?>';
		$find2 = array('dc:');
		$find3 = '/<spine>.*<\/spine>/s';
		$opf = str_replace($find1,'<?xml version="1.0" encoding="gbk"?>',$opf);
		$opf = str_replace($find2,'',$opf);
		//$opf = preg_replace($find3,'',$opf);	
		$opf = simplexml_load_string($opf);
		$opf = json_decode(json_encode($opf), true);
		return array('1',$opf);
	}
	else{
		return array('0','error');
	}
}
?>