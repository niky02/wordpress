<?php
	include_once "17mb/class/ez_sql_core.php";
	include_once "17mb/class/ez_sql_mysql.php";
	$db = new ezSQL_mysql($_17mb_user,$_17mb_pass,$_17mb_name,$_17mb_host);
	$db->get_results("SET NAMES 'utf8'");
	$sql_qt = 'select articleid,articlename,author,intro,sortid from '.$_17mb_prev.'article_article order by allvote desc limit 0,3';
	$sql_allvote = 'select articleid,articlename,author,intro,sortid from '.$_17mb_prev.'article_article order by allvote desc limit 0,10';
	$sql_goodnum = 'select articleid,articlename,author,intro,sortid from '.$_17mb_prev.'article_article order by goodnum desc limit 0,10';
	$sql_postdate = 'select articleid,articlename,author,intro,sortid from '.$_17mb_prev.'article_article order by postdate desc limit 0,10';
	$sql_lastupdate = 'select articleid,articlename,author,intro,sortid from '.$_17mb_prev.'article_article order by lastupdate desc limit 0,10';
	$sql_type_num = 'select count(articleid) from '.$_17mb_prev.'article_article ';
?>