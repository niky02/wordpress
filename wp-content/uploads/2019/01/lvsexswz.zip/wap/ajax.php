<?php
	//error_reporting(0);
	session_start();
	require 'main.php';
	require '17mb/class/sql.php';
	if($_REQUEST['ac']){
		$ac =  $_REQUEST['ac'];
		if($ac == 'newcase' && $_REQUEST['aid']){
			$aid = intval($_REQUEST['aid']);
			if(!is_int($aid)) die();
			$book = $db->get_row("select * from ".$_17mb_prev."article_article where articleid = ".$aid);
			if($book){
				$articlename = $book->articlename;
				$articleid = intval($book->articleid);
				$shortid = intval( $articleid / 1000 );
				$author = $book->author;
				$fullflag = $book->fullflag == 1 ? '已完本' : '连载中' ;
				$lastchapterid = $book->lastchapterid;
				$lastchapter = $book->lastchapter;
				echo $articleid.'|'.$shortid.'|'.$articlename.'|'.$author.'|'.$fullflag.'|'.$lastchapterid.'|'.$lastchapter;			
			}
		}
		if($ac=='allvisit' && $_REQUEST['aid']){
			$aid = intval($_REQUEST['aid']);
			if(!is_int($aid)) die();
			$book = $db->get_row("select allvisit from ".$_17mb_prev."article_article where articleid = ".$aid);
			if($book){
				$allvisit = $book->allvisit;
				echo 'document.write("'.$allvisit.'")';
			}
		}
		if($ac == "addbookmark" && $_REQUEST['aid']){
			if($_SESSION["jieqiUserId"] && $_SESSION['jieqiUserUname']){
				$uid = $_SESSION["jieqiUserId"];
				$username = $_SESSION['jieqiUserUname'];
				$aid = intval($_REQUEST['aid']);
				if(!is_int($aid)) die();
				//添加书签
				if($_REQUEST['cid']){
					$cid = intval($_REQUEST['cid']);
					if(!is_int($cid)) die();					
						if($_SESSION['jieqiUserId']){						
							$chapter = $db->get_row("select chaptername from ".$_17mb_prev."article_chapter where chapterid ='".$cid."' ");
							
							$case_extsis = $db->get_row("select caseid from ".$_17mb_prev."article_bookcase where articleid = '".$aid."' and userid='".$uid."' ");
							if(!$case_extsis){
								$article = $db->get_row("select articlename from ".$_17mb_prev."article_article where articleid ='".$aid."' ");
								if($article){
									$articlename = $article->articlename;	
								}
								if($chapter){
									$chaptername = $chapter->chaptername;	
									$q = $db->query("insert into ".$_17mb_prev."article_bookcase(articleid,articlename,userid,username,chapterid,chaptername,joindate) values('".$aid."','".$articlename."','".$uid."','".$username."','".$cid."','".$chaptername."','".date("U")."')");
									if($q) echo 'ok';
								}
							}
							else{
								if($chapter){
									$chaptername = $chapter->chaptername;
									$q = $db->query("update ".$_17mb_prev."article_bookcase set chapterid='".$cid."',chaptername='".$chaptername."' where articleid = '".$aid."' and userid = '".$uid."'");
									if($q) echo 'ok';
								}
							}
						}	
				}
				else{//添加书架
					
					$article = $db->get_row("select articlename from ".$_17mb_prev."article_article where articleid ='".$aid."' ");
					if($article){
						$articlename = $article->articlename;	
					}
					$case_extsis = $db->get_row("select caseid from ".$_17mb_prev."article_bookcase where articleid = '".$aid."' and userid='".$uid."' ");
					if(!$case_extsis){
						$db->query("insert into ".$_17mb_prev."article_bookcase(articleid,articlename,userid,username,joindate) values('".$aid."','".$articlename."','".$uid."','".$username."','".date("U")."')");
					}
					echo 'ok';
				}	
			}	
		}
	}
?>