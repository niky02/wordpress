<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-10-02 15:03:49
         compiled from "D:\wwwroot\wap\wwwroot\17mb\templates\s.html" */ ?>
<?php /*%%SmartyHeaderCode:1502357f121d56fbc44-99490886%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '0de7245dda01cb94cbbf8a1b7b02948ffcb1230c' => 
    array (
      0 => 'D:\\wwwroot\\wap\\wwwroot\\17mb\\templates\\s.html',
      1 => 1468296959,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1502357f121d56fbc44-99490886',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    '_17mb_sitename' => 0,
    '17mb_tips' => 0,
    'articlerows' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_57f121d5b1fa53_70984083',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57f121d5b1fa53_70984083')) {function content_57f121d5b1fa53_70984083($_smarty_tpl) {?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="application/xhtml+xml;charset=utf-8" />
    <title>搜索小说_<?php echo $_smarty_tpl->tpl_vars['_17mb_sitename']->value;?>
</title>
    <meta name="keywords" content="" />
    <meta name="description" content="" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no" />
    <meta name="format-detection" content="telephone=no" />
    <meta name="apple-mobile-web-app-capable" content="yes" />
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
    <link rel="stylesheet" href="/css/reset.css" />
    <link rel="stylesheet" href="/css/index.css" />
    <style>.tips{border:1px solid #C0DEEA;margin:10px;padding:10px;color:red}</style>
</head>
<body>
    <strong></strong>
    <header class="channelHeader">
<a class="iconback" href="/"><img src="images/header-back.gif" alt="返回"/></a>
搜索小说
<a class="iconhome" href="/"><img src="images/header-backhome.gif" alt="首页"/></a>
</header>

    <div class="recommend mybook">
    <div class="tips"><?php echo $_smarty_tpl->tpl_vars['17mb_tips']->value;?>
</div>
	<?php if (isset($_smarty_tpl->tpl_vars['smarty']->value['section']['i'])) unset($_smarty_tpl->tpl_vars['smarty']->value['section']['i']);
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['name'] = 'i';
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['loop'] = is_array($_loop=$_smarty_tpl->tpl_vars['articlerows']->value) ? count($_loop) : max(0, (int) $_loop); unset($_loop);
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['show'] = true;
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['max'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['loop'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['step'] = 1;
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['start'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['step'] > 0 ? 0 : $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['loop']-1;
if ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['show']) {
    $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['total'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['loop'];
    if ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['total'] == 0)
        $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['show'] = false;
} else
    $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['total'] = 0;
if ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['show']):

            for ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['start'], $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration'] = 1;
                 $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration'] <= $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['total'];
                 $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index'] += $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['step'], $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration']++):
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['rownum'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index_prev'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index'] - $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['step'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index_next'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index'] + $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['step'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['first']      = ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration'] == 1);
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['last']       = ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration'] == $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['total']);
?>
    <div class="hot_sale <?php if ($_smarty_tpl->tpl_vars['articlerows']->value[$_smarty_tpl->getVariable('smarty')->value['section']['i']['index']]['d2']!='') {?>hot_saleEm<?php }?>"><span class="num num<?php echo $_smarty_tpl->getVariable('smarty')->value['section']['i']['iteration'];?>
"><?php echo $_smarty_tpl->getVariable('smarty')->value['section']['i']['iteration'];?>
</span><a href="/<?php echo $_smarty_tpl->tpl_vars['articlerows']->value[$_smarty_tpl->getVariable('smarty')->value['section']['i']['index']]['shortid'];?>
_<?php echo $_smarty_tpl->tpl_vars['articlerows']->value[$_smarty_tpl->getVariable('smarty')->value['section']['i']['index']]['articleid'];?>
/"><p class="title"><?php echo $_smarty_tpl->tpl_vars['articlerows']->value[$_smarty_tpl->getVariable('smarty')->value['section']['i']['index']]['articlename'];?>
</p><p class="author"><?php echo $_smarty_tpl->tpl_vars['articlerows']->value[$_smarty_tpl->getVariable('smarty')->value['section']['i']['index']]['sortname'];?>
 | 作者：<?php echo $_smarty_tpl->tpl_vars['articlerows']->value[$_smarty_tpl->getVariable('smarty')->value['section']['i']['index']]['author'];?>
</p><p class="author"><?php echo $_smarty_tpl->tpl_vars['articlerows']->value[$_smarty_tpl->getVariable('smarty')->value['section']['i']['index']]['fullflag'];?>
 | 更新：<?php echo $_smarty_tpl->tpl_vars['articlerows']->value[$_smarty_tpl->getVariable('smarty')->value['section']['i']['index']]['lastchapter'];?>
</p></a></div>
	<?php endfor; endif; ?>
</div>
    <?php echo '<script'; ?>
 language="javascript" type="text/javascript" src="/js/zepto.min.js"><?php echo '</script'; ?>
>
    <?php echo '<script'; ?>
 language="javascript" type="text/javascript" src="/js/common.js"><?php echo '</script'; ?>
>
<?php echo $_smarty_tpl->getSubTemplate ("17mb/templates/foot.html", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

</body>
</html><?php }} ?>
