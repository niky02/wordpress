<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-10-02 16:40:59
         compiled from "D:\wwwroot\wap\wwwroot\17mb\templates\chapter.html" */ ?>
<?php /*%%SmartyHeaderCode:496957f1389ba80688-91230114%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '1c5fb7e1576801f2844fcab934c95df52bb09ee6' => 
    array (
      0 => 'D:\\wwwroot\\wap\\wwwroot\\17mb\\templates\\chapter.html',
      1 => 1471500564,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '496957f1389ba80688-91230114',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'chaptername' => 0,
    'articlename' => 0,
    '_17mb_sitename' => 0,
    'preview_chapterid' => 0,
    'shortid' => 0,
    'articleid' => 0,
    'next_chapterid' => 0,
    '_17mb_content' => 0,
    'chapterid' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_57f1389c13ac38_98775757',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57f1389c13ac38_98775757')) {function content_57f1389c13ac38_98775757($_smarty_tpl) {?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="application/xhtml+xml;charset=utf-8" />
    <title><?php echo $_smarty_tpl->tpl_vars['chaptername']->value;?>
_<?php echo $_smarty_tpl->tpl_vars['articlename']->value;?>
_<?php echo $_smarty_tpl->tpl_vars['_17mb_sitename']->value;?>
</title>
    <meta name="keywords" content="<?php echo $_smarty_tpl->tpl_vars['chaptername']->value;?>
,<?php echo $_smarty_tpl->tpl_vars['articlename']->value;?>
" />
    <meta name="description" content="<?php echo $_smarty_tpl->tpl_vars['_17mb_sitename']->value;?>
提供<?php echo $_smarty_tpl->tpl_vars['chaptername']->value;?>
,<?php echo $_smarty_tpl->tpl_vars['articlename']->value;?>
在线阅读。" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no" />
    <meta name="format-detection" content="telephone=no" />
    <meta name="apple-mobile-web-app-capable" content="yes" />
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
    <link rel="stylesheet" href="/css/reset.css" />
    <link rel="stylesheet" href="/css/read.css" />
    <?php echo '<script'; ?>
 language="javascript" type="text/javascript" src="/js/read.js"><?php echo '</script'; ?>
>
    <?php echo '<script'; ?>
 language="javascript" type="text/javascript" src="/js/yuedu.js"><?php echo '</script'; ?>
> 
    <style>
	.topMenuFree a{width:42%;}
	.topMenuFree  .fontsize{width:16%;}
    </style>
    </head>
<body id="read" class="read">
<header id="top" class="channelHeader channelHeader2"><a href="javascript:history.go(-1);" class="iconback"><img src="/images/header-back.gif" alt="返回"/></a><span class="title"><?php echo $_smarty_tpl->tpl_vars['chaptername']->value;?>
&nbsp;&nbsp;<?php echo $_smarty_tpl->tpl_vars['articlename']->value;?>
</span><a href="/" class="iconhome"><img src="/images/header-backhome.gif" alt="首页"/></a></header>
<div class="bg"></div>
<a name="pagetop"></a>
<p class="Readpage" style="background:#FFFFFF;padding:2px;">
    	<a id="lightdiv" class="button lightoff" onclick="nr_setbg('light')">关灯</a>
        <a id="huyandiv" class="button huyanon"  onclick="nr_setbg('huyan')">护眼</a>&nbsp;&nbsp;&nbsp;&nbsp;
        字体：<a id="fontbig" class="sizebg" onclick="nr_setbg('big')">大</a> <a id="fontmiddle" class="sizebg" onclick="nr_setbg('middle')" >中</a> <a id="fontsmall" class="sizebg" onclick="nr_setbg('small')">小</a>
</p>
<p class="Readpage">
<a href="<?php if ($_smarty_tpl->tpl_vars['preview_chapterid']->value!='') {?>/<?php echo $_smarty_tpl->tpl_vars['shortid']->value;?>
_<?php echo $_smarty_tpl->tpl_vars['articleid']->value;?>
/<?php echo $_smarty_tpl->tpl_vars['preview_chapterid']->value;?>
.html<?php } else { ?>/<?php echo $_smarty_tpl->tpl_vars['shortid']->value;?>
_<?php echo $_smarty_tpl->tpl_vars['articleid']->value;?>
/<?php }?>" id="pt_prev" class="Readpage_up">上一章</a>
<a href="/<?php echo $_smarty_tpl->tpl_vars['shortid']->value;?>
_<?php echo $_smarty_tpl->tpl_vars['articleid']->value;?>
/" id="pt_mulu" class="Readpage_up">目录</a>
<a href="<?php if ($_smarty_tpl->tpl_vars['next_chapterid']->value!='') {?>/<?php echo $_smarty_tpl->tpl_vars['shortid']->value;?>
_<?php echo $_smarty_tpl->tpl_vars['articleid']->value;?>
/<?php echo $_smarty_tpl->tpl_vars['next_chapterid']->value;?>
.html<?php } else { ?>/<?php echo $_smarty_tpl->tpl_vars['shortid']->value;?>
_<?php echo $_smarty_tpl->tpl_vars['articleid']->value;?>
/<?php }?>" id="pt_next" class="Readpage_down js_page_down">下一章</a>
</p>
<?php echo '<script'; ?>
>style_top()<?php echo '</script'; ?>
>
<div id="chaptercontent" class="Readarea ReadAjax_content">
<?php echo $_smarty_tpl->tpl_vars['_17mb_content']->value;?>

<p style="width:100%;text-alight:center;"><a href="javascript:addBookMarkByManual(<?php echo $_smarty_tpl->tpl_vars['chapterid']->value;?>
,<?php echo $_smarty_tpl->tpl_vars['articleid']->value;?>
);" style="text-align:center;color:red;">『加入书签，方便阅读』</a></p>
</div>
<?php echo '<script'; ?>
 language="javascript">getset()<?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 language="javascript">getset1()<?php echo '</script'; ?>
>
<p class="synopsisAd ReadAd ReadAd2"></p>
<p class="Readpage">
<a href="<?php if ($_smarty_tpl->tpl_vars['preview_chapterid']->value!='') {?>/<?php echo $_smarty_tpl->tpl_vars['shortid']->value;?>
_<?php echo $_smarty_tpl->tpl_vars['articleid']->value;?>
/<?php echo $_smarty_tpl->tpl_vars['preview_chapterid']->value;?>
.html<?php } else { ?>/<?php echo $_smarty_tpl->tpl_vars['shortid']->value;?>
_<?php echo $_smarty_tpl->tpl_vars['articleid']->value;?>
/<?php }?>" id="pt_prev" class="Readpage_up">上一章</a>
<a href="/<?php echo $_smarty_tpl->tpl_vars['shortid']->value;?>
_<?php echo $_smarty_tpl->tpl_vars['articleid']->value;?>
/" id="pt_mulu" class="Readpage_up">目录</a>
<a href="<?php if ($_smarty_tpl->tpl_vars['next_chapterid']->value!='') {?>/<?php echo $_smarty_tpl->tpl_vars['shortid']->value;?>
_<?php echo $_smarty_tpl->tpl_vars['articleid']->value;?>
/<?php echo $_smarty_tpl->tpl_vars['next_chapterid']->value;?>
.html<?php } else { ?>/<?php echo $_smarty_tpl->tpl_vars['shortid']->value;?>
_<?php echo $_smarty_tpl->tpl_vars['articleid']->value;?>
/<?php }?>" id="pt_next" class="Readpage_down js_page_down">下一章</a>
</p>
<?php echo '<script'; ?>
 language="javascript" type="text/javascript" src="/js/zepto.min.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 language="javascript" type="text/javascript" src="/js/common.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 language="javascript" type="text/javascript" src="/js/index.js"><?php echo '</script'; ?>
>

<?php echo '<script'; ?>
 type="text/javascript">
var lastread=new LastRead();lastread.set('<?php echo $_smarty_tpl->tpl_vars['articleid']->value;?>
', '<?php echo $_smarty_tpl->tpl_vars['chapterid']->value;?>
', '<?php echo $_smarty_tpl->tpl_vars['articlename']->value;?>
', '<?php echo $_smarty_tpl->tpl_vars['chaptername']->value;?>
');
<?php echo '</script'; ?>
>
<?php echo $_smarty_tpl->getSubTemplate ("foot.html", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

</body>
</html>
<?php }} ?>
