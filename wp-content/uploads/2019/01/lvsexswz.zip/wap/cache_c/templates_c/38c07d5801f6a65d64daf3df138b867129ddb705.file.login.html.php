<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-10-02 17:32:11
         compiled from "D:\wwwroot\wap\wwwroot\17mb\templates\login.html" */ ?>
<?php /*%%SmartyHeaderCode:434457f1449b5996a3-74801239%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '38c07d5801f6a65d64daf3df138b867129ddb705' => 
    array (
      0 => 'D:\\wwwroot\\wap\\wwwroot\\17mb\\templates\\login.html',
      1 => 1468327673,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '434457f1449b5996a3-74801239',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    '_17mb_sitename' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_57f1449b78d589_10088313',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57f1449b78d589_10088313')) {function content_57f1449b78d589_10088313($_smarty_tpl) {?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="application/xhtml+xml;charset=utf-8" />
    <title>会员登录-<?php echo $_smarty_tpl->tpl_vars['_17mb_sitename']->value;?>
</title>
    <meta name="keywords" content="" />
    <meta name="description" content="" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no" />
    <meta name="format-detection" content="telephone=no" />
    <meta name="apple-mobile-web-app-capable" content="yes" />
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
    <meta http-equiv="pragma" content="no-cache" />
    <meta http-equiv="cache-control" content="no-cache" />
    <meta http-equiv="expires" content="0" />
    <link rel="stylesheet" href="/css/login.css" />
    <link rel="stylesheet" href="/css/reset.css" />
</head>
<body style="background-color:white;overflow-y:hidden;">
<div class="bg"></div>
<header class="channelHeader channelHeader2">
	<a href="javascript:history.go(-1);" class="iconback"><img src="/images/header-back.gif" alt="返回"/></a>
    <span class="title"><?php echo $_smarty_tpl->tpl_vars['_17mb_sitename']->value;?>
会员登录</span>
    <a href="/" class="iconhome"><img src="/images/header-backhome.gif" alt="首页"/></a>
</header>

<div class="login_box">
	<form name="form_login" action="/login_go.php" method="post">
		<div class="login_name"><span class="person_bg"></span>
			<input type="text" class="name login_nm" name="username" value="用户名">
		</div>
		<p class="tips_text">请输入用户名</p>

		<div class="login_name"><span class="psw_bg"></span>
			<input type="text" class="name login_psw" name="password" value="你的账号密码">
		</div>
		<p class="tips_text">请输入密码</p>

		<div class="submit_btn">
			<label style="padding-bottom:5px; padding-top:5px; display:block;"><input type="checkbox" name="login_hold" value="1" checked="checked">30天内免登录</label>
			<input type="button" class="login_bto login_in" value="登录" />
		</div>
	</form>
	<p class="text_login"> 
		<input type="button" class="login_bto login_in" onclick="javascript:location.href='/register.php'" value="免费注册" />
	</p>
	
	<div class="tip_box">
		<h2>温馨提示：</h2>
		<p>
         1、登录成功后，可使用永久书架，保存的书永不丢失；<br />
         2、手机站与PC站共用一个帐号，可实现书架同步。
		</p>
	</div>

</div>
<?php echo '<script'; ?>
 language="javascript" type="text/javascript" src="/js/zepto.min.js"><?php echo '</script'; ?>
>
 <?php echo '<script'; ?>
 language="javascript" type="text/javascript" src="/js/login.js"><?php echo '</script'; ?>
>
 
<?php echo $_smarty_tpl->getSubTemplate ("17mb/templates/foot.html", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

</body>
</html>
<?php }} ?>
