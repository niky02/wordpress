<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-10-02 17:16:19
         compiled from "D:\wwwroot\wap\wwwroot\17mb\templates\newcase.html" */ ?>
<?php /*%%SmartyHeaderCode:2301457f140e331d875-00484786%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '68bec87259184665adade8f7bf658e2df62b7eab' => 
    array (
      0 => 'D:\\wwwroot\\wap\\wwwroot\\17mb\\templates\\newcase.html',
      1 => 1471500964,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2301457f140e331d875-00484786',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    '_17mb_sitename' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_57f140e3501993_54468856',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57f140e3501993_54468856')) {function content_57f140e3501993_54468856($_smarty_tpl) {?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="application/xhtml+xml;charset=utf-8" />
    <title>阅读记录_<?php echo $_smarty_tpl->tpl_vars['_17mb_sitename']->value;?>
</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no" />
    <meta name="format-detection" content="telephone=no" />
    <meta name="apple-mobile-web-app-capable" content="yes" />
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
    <link rel="stylesheet" href="/css/reset.css" />
    <link rel="stylesheet" href="/css/rank.css" />
    <?php echo '<script'; ?>
 language="javascript" type="text/javascript" src="/js/jquery.min.js"><?php echo '</script'; ?>
>
	<?php echo '<script'; ?>
 language="javascript" type="text/javascript" src="/js/yuedu.js"><?php echo '</script'; ?>
> 
    <style type="text/css">
   /*更新在reset*/
	header a{margin:0;}
	.channelHeader{overflow:hidden; padding:0;  width:100%;}
	.iconback{float:left;}
	.iconhome{float:right;}
	.iconback, .iconhome{background:none; margin-top:3px; font-size:12px; text-align:center; color:#fff; line-height:40px; width:40px; height:40px;}
	.channelHeader2 .iconhome{margin-top:-44px;}
	.iconback img, .iconhome img{width:40px; height:40px; font-size:12px; text-align:center; line-height:40px;}
	.pageBox .iconback, .pageBox .iconhome{background:none;}
	.bookcasetip{border:1px solid #C0DEEA;margin:10px;padding:10px;}
	 </style>
</head>
<body class="pageBox">
    <div class="main transition">
        <!-- 下拉框 -->
        <header class="channelHeader">
         <div class="tabArea tab-navarea">
          <div class="tab-nav tab-nav2 clearfix">
                    <h2 style="height:50px;width:16%">
                        <a class="iconback" href="/"><img src="images/header-backhome.gif" alt="首页"/></a>
                    </h2>
                    <h2 style="width:84%;height:50px;">
                        <a style="color:White;height:50px;line-height:50px;">阅读记录(保存最近阅读10本书)</a>
                    </h2>
                </div>
                 </div>
            </header>
        <div class="tabArea  list rankingList rankingList_3">
            <div class="slide-con slide-con2">
                <div id="newcase" class="slide-item list1">
                    <?php echo '<script'; ?>
>yuedu()<?php echo '</script'; ?>
>                       
                </div>
            </div>
        </div>
 
<?php echo $_smarty_tpl->getSubTemplate ("17mb/templates/foot.html", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

    </div>
</body>
</html>
<?php }} ?>
