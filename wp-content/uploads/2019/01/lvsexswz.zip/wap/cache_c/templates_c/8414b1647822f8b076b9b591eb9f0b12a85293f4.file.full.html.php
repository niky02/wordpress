<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-10-02 17:32:16
         compiled from "D:\wwwroot\wap\wwwroot\17mb\templates\full.html" */ ?>
<?php /*%%SmartyHeaderCode:1340557f144a0353e87-17970372%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '8414b1647822f8b076b9b591eb9f0b12a85293f4' => 
    array (
      0 => 'D:\\wwwroot\\wap\\wwwroot\\17mb\\templates\\full.html',
      1 => 1471500741,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1340557f144a0353e87-17970372',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    '_17mb_sitename' => 0,
    'sortid' => 0,
    'sort' => 0,
    'articlerows' => 0,
    '_17mb_pcurl' => 0,
    'jumppage' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_57f144a087f625_18678673',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57f144a087f625_18678673')) {function content_57f144a087f625_18678673($_smarty_tpl) {?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="application/xhtml+xml;charset=utf-8" />
    <title>全本小说在线阅读_<?php echo $_smarty_tpl->tpl_vars['_17mb_sitename']->value;?>
</title>
    <meta name="keywords" content="全本小说在线阅读,<?php echo $_smarty_tpl->tpl_vars['_17mb_sitename']->value;?>
" />
    <meta name="description" content="<?php echo $_smarty_tpl->tpl_vars['_17mb_sitename']->value;?>
提供全本小说在线阅读和txt下载。" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no" />
    <meta name="format-detection" content="telephone=no" />
    <meta name="apple-mobile-web-app-capable" content="yes" />
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
    <link rel="stylesheet" type="text/css" href="/css/reset.css" />
    <link rel="stylesheet" type="text/css" href="/css/sort.css" />
</head>
<body>
     <header class="channelHeader">
<a href="javascript:history.go(-1);" class="iconback"><img alt="返回" src="/images/header-back.gif"></a>
全本小说
<a href="/" class="iconhome"><img alt="首页" src="/images/header-backhome.gif"></a>
</header>
    
    <nav class="sortChannel_nav">
     <a href="/quanben.html"<?php if ($_smarty_tpl->tpl_vars['sortid']->value=='') {?> class="on"<?php }?>>全部</a>
        
        <?php if (isset($_smarty_tpl->tpl_vars['smarty']->value['section']['i'])) unset($_smarty_tpl->tpl_vars['smarty']->value['section']['i']);
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['name'] = 'i';
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['loop'] = is_array($_loop=$_smarty_tpl->tpl_vars['sort']->value) ? count($_loop) : max(0, (int) $_loop); unset($_loop);
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['show'] = true;
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['max'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['loop'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['step'] = 1;
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['start'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['step'] > 0 ? 0 : $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['loop']-1;
if ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['show']) {
    $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['total'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['loop'];
    if ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['total'] == 0)
        $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['show'] = false;
} else
    $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['total'] = 0;
if ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['show']):

            for ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['start'], $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration'] = 1;
                 $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration'] <= $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['total'];
                 $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index'] += $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['step'], $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration']++):
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['rownum'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index_prev'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index'] - $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['step'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index_next'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index'] + $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['step'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['first']      = ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration'] == 1);
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['last']       = ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration'] == $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['total']);
?>
        	<a href="/quanben<?php echo $_smarty_tpl->tpl_vars['sort']->value[$_smarty_tpl->getVariable('smarty')->value['section']['i']['index']]['sortid'];?>
.html"<?php if ($_smarty_tpl->tpl_vars['sort']->value[$_smarty_tpl->getVariable('smarty')->value['section']['i']['index']]['sortid']==$_smarty_tpl->tpl_vars['sortid']->value) {?> class="on"<?php }?>><?php echo $_smarty_tpl->tpl_vars['sort']->value[$_smarty_tpl->getVariable('smarty')->value['section']['i']['index']]['sortname'];?>
</a>
        <?php endfor; endif; ?> 
            
</nav>
    <div class="recommend">
        <div id="main">
                    <?php if (isset($_smarty_tpl->tpl_vars['smarty']->value['section']['i'])) unset($_smarty_tpl->tpl_vars['smarty']->value['section']['i']);
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['name'] = 'i';
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['loop'] = is_array($_loop=$_smarty_tpl->tpl_vars['articlerows']->value) ? count($_loop) : max(0, (int) $_loop); unset($_loop);
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['show'] = true;
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['max'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['loop'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['step'] = 1;
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['start'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['step'] > 0 ? 0 : $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['loop']-1;
if ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['show']) {
    $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['total'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['loop'];
    if ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['total'] == 0)
        $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['show'] = false;
} else
    $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['total'] = 0;
if ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['show']):

            for ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['start'], $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration'] = 1;
                 $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration'] <= $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['total'];
                 $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index'] += $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['step'], $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration']++):
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['rownum'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index_prev'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index'] - $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['step'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index_next'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index'] + $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['step'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['first']      = ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration'] == 1);
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['last']       = ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration'] == $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['total']);
?>
                    <div class="hot_sale">
                        <a href="/<?php echo $_smarty_tpl->tpl_vars['articlerows']->value[$_smarty_tpl->getVariable('smarty')->value['section']['i']['index']]['shortid'];?>
_<?php echo $_smarty_tpl->tpl_vars['articlerows']->value[$_smarty_tpl->getVariable('smarty')->value['section']['i']['index']]['articleid'];?>
/">
                            <img class="lazy" data-original="<?php echo $_smarty_tpl->tpl_vars['_17mb_pcurl']->value;?>
/files/article/image/<?php echo $_smarty_tpl->tpl_vars['articlerows']->value[$_smarty_tpl->getVariable('smarty')->value['section']['i']['index']]['shortid'];?>
/<?php echo $_smarty_tpl->tpl_vars['articlerows']->value[$_smarty_tpl->getVariable('smarty')->value['section']['i']['index']]['articleid'];?>
/<?php echo $_smarty_tpl->tpl_vars['articlerows']->value[$_smarty_tpl->getVariable('smarty')->value['section']['i']['index']]['articleid'];?>
s.jpg" src="/images/defaultimg.png" onerror="this.src='/images/nopic.gif'">
                            <p class="title">
                                <?php echo $_smarty_tpl->tpl_vars['articlerows']->value[$_smarty_tpl->getVariable('smarty')->value['section']['i']['index']]['articlename'];?>

                            </p>
                            <p class="author">
                                作者：<?php echo $_smarty_tpl->tpl_vars['articlerows']->value[$_smarty_tpl->getVariable('smarty')->value['section']['i']['index']]['author'];?>
</p>
                        </a>
                        <p class="review">
                            <span class="longview"></span>简介：<?php echo $_smarty_tpl->tpl_vars['articlerows']->value[$_smarty_tpl->getVariable('smarty')->value['section']['i']['index']]['intro'];?>
</p>
                    </div>
<?php endfor; endif; ?>   
        </div>
                        <p class="page">
							<?php echo $_smarty_tpl->tpl_vars['jumppage']->value;?>

                        </p>
<br />
                </div>
    <?php echo '<script'; ?>
 language="javascript" type="text/javascript" src="/js/zepto.min.js"><?php echo '</script'; ?>
>
    <?php echo '<script'; ?>
 language="javascript" type="text/javascript" src="/js/sort.js"><?php echo '</script'; ?>
>
    <?php echo '<script'; ?>
 language="javascript" type="text/javascript" src="/js/lazyload.js"><?php echo '</script'; ?>
>
    <?php echo '<script'; ?>
 type="text/javascript" language="javascript">
    $(function(){
	    $("img.lazy").lazyload();
    });
    <?php echo '</script'; ?>
>

<?php echo $_smarty_tpl->getSubTemplate ("17mb/templates/foot.html", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>


</body>
</html><?php }} ?>
