<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-10-02 14:54:55
         compiled from "D:\wwwroot\wap\wwwroot\17mb\templates\index.html" */ ?>
<?php /*%%SmartyHeaderCode:1293757f11f47ada3a3-52928540%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'a8c21b1ba345817932d50263a52999f4885aa88f' => 
    array (
      0 => 'D:\\wwwroot\\wap\\wwwroot\\17mb\\templates\\index.html',
      1 => 1475420092,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1293757f11f47ada3a3-52928540',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_57f11f48183988_34317820',
  'variables' => 
  array (
    '_17mb_sitename' => 0,
    'qt' => 0,
    '_17mb_pcurl' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57f11f48183988_34317820')) {function content_57f11f48183988_34317820($_smarty_tpl) {?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="application/xhtml+xml;charset=utf-8" />
    <title>在线看小说_<?php echo $_smarty_tpl->tpl_vars['_17mb_sitename']->value;?>
</title>
    <meta name="generator" content="<?php echo $_smarty_tpl->tpl_vars['_17mb_sitename']->value;?>
" />
    <meta id="ctl00_metaKeywords" name="keywords" content="在线看小说,<?php echo $_smarty_tpl->tpl_vars['_17mb_sitename']->value;?>
"/>
    <meta id="ctl00_metaDescription" name="description" content="<?php echo $_smarty_tpl->tpl_vars['_17mb_sitename']->value;?>
是一个免费在线看小说的网站，提供最新热门小说免费在线阅读和txt下载。"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no" />
    <meta name="format-detection" content="telephone=no" />
    <meta name="apple-mobile-web-app-capable" content="yes" />
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
    <link rel="stylesheet" href="/css/index.css" />
    <style type="text/css">
    .bannerLink .ajax_html, .list .ajax_html{height:auto; overflow:hidden; line-height:normal;}
	.ajax_html{text-align:center; width:320px; margin:0 auto;}
	.tabArea4 .ajax_html{width:25%; margin:0;}
	.ajax_html img{padding:20px 0;}
	.ajax_html b{display:none;}
 </style>
</head>
    <link type="text/css" href="/css/wap.css" rel="stylesheet" />
    <?php echo '<script'; ?>
 type="text/javascript" src="/js/jquery.1.8.3.min.js"><?php echo '</script'; ?>
>
    <?php echo '<script'; ?>
 type="text/javascript" src="/js/head.js"><?php echo '</script'; ?>
>
</head>
<body>
<!--屏幕自适应开始-->
<header class="mian_box">
  <!--nav-->
    <ul class="nav_s" >
                <li class="nav_one"><a href="/">首页</a></li>
                <li class="nav_one"><a href="/xclass/0/1.html">书库</a></li>
                <li class="nav_one"><a href="/ph/week.html">排行</a></li>
                <li class="nav_one"><a href="/login.php">会员</a></li>
  </ul>
</header>
<section class="com-sec">
			<nav class="nav">
				<ul class="clearfix">
					<li><a href="/xclass/1/1.html" class="n-boys"><i></i><span>男生</span></a></li>
					<li><a href="/xclass/8/1.html" class="n-girls"><i></i><span>女生</span></a></li>
					<li><a href="/newcase.html" class="n-flower"><i></i><span>书架</span></a></li>
					<li><a href="/xclass/0/1.html" class="n-seri"><i></i><span>连载</span></a></li>
					<li><a href="/quanben.html" class="n-comp"><i></i><span>全本</span></a></li>
				</ul>
			</nav>
		</section>
    <form name="articlesearch" class="searchForm" method="post" action="/s.php">  
      <input type="text" name="keyword" class="searchForm_input searchForm_input2" value="输入书名•作者" />
        <input type="hidden" name="t" value="1" />
        <input type="submit" class="searchForm_btn" value="搜索" />
    </form>
    
<div class="tabArea tabArea4 hot">
        <div class="tab-nav clearfix">
            <h2><a class="tab-nav-cur">强推</a></h2>
            <h2><a style="display: none;">热门</a></h2>
            <h2><a style="display: none;">全本</a></h2>
            <h2><a style="display: none;">&nbsp;</a></h2>
        </div>
        <div class="slide">
            <div class="slide-con4 div">
                <div class="slide-item index_hot1">
                    
                <?php if (isset($_smarty_tpl->tpl_vars['smarty']->value['section']['i'])) unset($_smarty_tpl->tpl_vars['smarty']->value['section']['i']);
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['name'] = 'i';
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['loop'] = is_array($_loop=$_smarty_tpl->tpl_vars['qt']->value) ? count($_loop) : max(0, (int) $_loop); unset($_loop);
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['show'] = true;
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['max'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['loop'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['step'] = 1;
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['start'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['step'] > 0 ? 0 : $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['loop']-1;
if ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['show']) {
    $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['total'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['loop'];
    if ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['total'] == 0)
        $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['show'] = false;
} else
    $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['total'] = 0;
if ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['show']):

            for ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['start'], $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration'] = 1;
                 $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration'] <= $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['total'];
                 $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index'] += $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['step'], $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration']++):
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['rownum'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index_prev'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index'] - $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['step'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index_next'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index'] + $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['step'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['first']      = ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration'] == 1);
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['last']       = ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration'] == $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['total']);
?>    
                    <div class="hot_sale">
                    <a href="/<?php echo $_smarty_tpl->tpl_vars['qt']->value[$_smarty_tpl->getVariable('smarty')->value['section']['i']['index']]['shortid'];?>
_<?php echo $_smarty_tpl->tpl_vars['qt']->value[$_smarty_tpl->getVariable('smarty')->value['section']['i']['index']]['articleid'];?>
/">
                        <img class="lazy" style="width:89px;height:119px;" data-original="<?php echo $_smarty_tpl->tpl_vars['_17mb_pcurl']->value;?>
/files/article/image/<?php echo $_smarty_tpl->tpl_vars['qt']->value[$_smarty_tpl->getVariable('smarty')->value['section']['i']['index']]['shortid'];?>
/<?php echo $_smarty_tpl->tpl_vars['qt']->value[$_smarty_tpl->getVariable('smarty')->value['section']['i']['index']]['articleid'];?>
/<?php echo $_smarty_tpl->tpl_vars['qt']->value[$_smarty_tpl->getVariable('smarty')->value['section']['i']['index']]['articleid'];?>
s.jpg" src="images/defaultimg.png" onerror="this.src='images/nopic.gif'" />
                        <p class="title"><?php echo $_smarty_tpl->tpl_vars['qt']->value[$_smarty_tpl->getVariable('smarty')->value['section']['i']['index']]['articlename'];?>
</p>
                        <p class="author">作者：<?php echo $_smarty_tpl->tpl_vars['qt']->value[$_smarty_tpl->getVariable('smarty')->value['section']['i']['index']]['author'];?>
</p>
                        <p class="review">简介：<?php echo mb_substr($_smarty_tpl->tpl_vars['qt']->value[$_smarty_tpl->getVariable('smarty')->value['section']['i']['index']]['intro'],0,70,'utf8');?>
...</p>
                        </a>
                    </div>
               <?php endfor; endif; ?>
               
                </div>
            </div>
        </div>
    </div>
    <div class="tabArea tabArea4 bannerLink div">
        <div class="tab-nav tab-nav4 clearfix">
            <h2><a class="tab-nav-cur">玄幻奇幻</a></h2>
            <h2><a style="display: none;">&nbsp;</a></h2>
            <h2><a style="display: none;">&nbsp;</a></h2>
            <h2><a style="display: none;">&nbsp;</a></h2>
        </div>
        <div class="slide">
            <div class="slide-con4">
                <div class="slide-item index_sort1">
					<ul><?php echo b(array('num'=>"6",'order'=>"allvisit",'class'=>"1",'url'=>"/{shortid}_{articleid}/"),$_smarty_tpl);?>

                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="tabArea tabArea4 bannerLink div">
        <div class="tab-nav tab-nav4 clearfix">
            <h2 id="H2_1"><a class="tab-nav-cur">武侠仙侠</a></h2>
            <h2><a style="display: none;">&nbsp;</a></h2>
            <h2><a style="display: none;">&nbsp;</a></h2>
            <h2><a style="display: none;">&nbsp;</a></h2>
        </div>
        <div class="slide">
            <div class="slide-con4">
                <div class="slide-item index_sort1">
					<ul><?php echo b(array('num'=>"6",'order'=>"allvisit",'class'=>"2",'url'=>"/{shortid}_{articleid}/"),$_smarty_tpl);?>

                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="tabArea tabArea4 bannerLink div">
        <div class="tab-nav tab-nav4 clearfix">
            <h2 id="H2_2"><a class="tab-nav-cur">都市言情</a></h2>
            <h2><a style="display: none;">&nbsp;</a></h2>
            <h2><a style="display: none;">&nbsp;</a></h2>
            <h2><a style="display: none;">&nbsp;</a></h2>
        </div>
        <div class="slide">
            <div class="slide-con4">
                <div class="slide-item index_sort1">
					<ul><?php echo b(array('num'=>"6",'order'=>"allvisit",'class'=>"3",'url'=>"/{shortid}_{articleid}/"),$_smarty_tpl);?>

                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="tabArea tabArea4 bannerLink div">
        <div class="tab-nav tab-nav4 clearfix">
            <h2 id="H2_3"><a class="tab-nav-cur">历史军事</a></h2>
            <h2><a style="display: none;">&nbsp;</a></h2>
            <h2><a style="display: none;">&nbsp;</a></h2>
            <h2><a style="display: none;">&nbsp;</a></h2>
        </div>
        <div class="slide">
            <div class="slide-con4">
                <div class="slide-item index_sort1">
					<ul><?php echo b(array('num'=>"6",'order'=>"allvisit",'class'=>"4",'url'=>"/{shortid}_{articleid}/"),$_smarty_tpl);?>

                    </ul>
                </div>
            </div>
        </div>
    </div>
<?php echo '<script'; ?>
 language="javascript" type="text/javascript" src="/js/zepto.min.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 language="javascript" type="text/javascript" src="/js/common.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 language="javascript" type="text/javascript" src="/js/lazyload.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 type="text/javascript" language="javascript">
    $(function(){
	    $("img.lazy").lazyload();
    });
<?php echo '</script'; ?>
>
<?php echo $_smarty_tpl->getSubTemplate ("foot.html", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

</body>
</html><?php }} ?>
