<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-10-02 15:08:13
         compiled from "D:\wwwroot\wap\wwwroot\17mb\templates\info.html" */ ?>
<?php /*%%SmartyHeaderCode:3244457f122dd9debc7-81051879%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'f6a2a49c8dd3b676da3cc1200f583392ee51f004' => 
    array (
      0 => 'D:\\wwwroot\\wap\\wwwroot\\17mb\\templates\\info.html',
      1 => 1471503718,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '3244457f122dd9debc7-81051879',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'articlename' => 0,
    '_17mb_sitename' => 0,
    'author' => 0,
    '_17mb_pcurl' => 0,
    'shortid' => 0,
    'articleid' => 0,
    'sortname' => 0,
    'fullflag' => 0,
    'allvisit' => 0,
    'lastupdate' => 0,
    'intro' => 0,
    'chapter' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_57f122de1f29f4_68098526',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57f122de1f29f4_68098526')) {function content_57f122de1f29f4_68098526($_smarty_tpl) {?><?php if (!is_callable('smarty_modifier_date_format')) include 'D:\\wwwroot\\wap\\wwwroot\\libs\\plugins\\modifier.date_format.php';
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="application/xhtml+xml;charset=utf-8" />
    <title><?php echo $_smarty_tpl->tpl_vars['articlename']->value;?>
txt下载,<?php echo $_smarty_tpl->tpl_vars['articlename']->value;?>
最新章节_<?php echo $_smarty_tpl->tpl_vars['_17mb_sitename']->value;?>
</title>
    <meta name="generator" content="<?php echo $_smarty_tpl->tpl_vars['_17mb_sitename']->value;?>
" />
    <meta id="ctl00_metaKeywords" name="keywords" content="<?php echo $_smarty_tpl->tpl_vars['articlename']->value;?>
txt下载,<?php echo $_smarty_tpl->tpl_vars['articlename']->value;?>
最新章节"/>
    <meta id="ctl00_metaDescription" name="description" content="<?php echo $_smarty_tpl->tpl_vars['_17mb_sitename']->value;?>
提供<?php echo $_smarty_tpl->tpl_vars['author']->value;?>
写的小说《<?php echo $_smarty_tpl->tpl_vars['articlename']->value;?>
》最新章节免费在线阅读，《<?php echo $_smarty_tpl->tpl_vars['articlename']->value;?>
》txt下载、请关注《<?php echo $_smarty_tpl->tpl_vars['articlename']->value;?>
》吧，本站会第一时间更新《<?php echo $_smarty_tpl->tpl_vars['articlename']->value;?>
》的最新章节。" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no" />
    <meta name="format-detection" content="telephone=no" />
    <meta name="apple-mobile-web-app-capable" content="yes" />
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
    <link rel="stylesheet" href="/css/reset.css" />
    <link rel="stylesheet" href="/css/bookinfo.css" />
</head>
<body>
    <div class="bg">
    </div>
    <header class="channelHeader channelHeader2">
<a href="javascript:history.go(-1);" class="iconback"><img src="/images/header-back.gif" alt="返回"/></a>
<span class="title"><?php echo $_smarty_tpl->tpl_vars['articlename']->value;?>
</span>
<a href="/" class="iconhome"><img src="/images/header-backhome.gif" alt="首页"/></a>
</header>
    <p class="synopsisAd" style="color: red;"></p>
    <div class="synopsisArea">
        <div class="synopsisArea_detail">
            <img src="<?php echo $_smarty_tpl->tpl_vars['_17mb_pcurl']->value;?>
/files/article/image/<?php echo $_smarty_tpl->tpl_vars['shortid']->value;?>
/<?php echo $_smarty_tpl->tpl_vars['articleid']->value;?>
/<?php echo $_smarty_tpl->tpl_vars['articleid']->value;?>
s.jpg" onerror="this.src='/images/defaultimg.png'" />
            <a href="/<?php echo $_smarty_tpl->tpl_vars['shortid']->value;?>
_<?php echo $_smarty_tpl->tpl_vars['articleid']->value;?>
/">
                <p class="author">作者：<?php echo $_smarty_tpl->tpl_vars['author']->value;?>
</p>
            </a>
          <p class="sort">
                类别：<?php echo $_smarty_tpl->tpl_vars['sortname']->value;?>
</p>
            <p class="">
                状态：<?php echo $_smarty_tpl->tpl_vars['fullflag']->value;?>
</p>
            <p class="">
                点击：<?php echo $_smarty_tpl->tpl_vars['allvisit']->value;?>
<font color="red"><?php echo '<script'; ?>
 src="/ajax.php?ac=allvisit&aid=<?php echo $_smarty_tpl->tpl_vars['articleid']->value;?>
"><?php echo '</script'; ?>
></font></p>
            <p class="">
                更新：<?php echo smarty_modifier_date_format($_smarty_tpl->tpl_vars['lastupdate']->value,"Y-m-d");?>
</p>
        </div>
        <p class="btn">
			<a href="/<?php echo $_smarty_tpl->tpl_vars['shortid']->value;?>
_<?php echo $_smarty_tpl->tpl_vars['articleid']->value;?>
/all.html">开始阅读</a><a href="javascript:addBookMarkByManual(0,<?php echo $_smarty_tpl->tpl_vars['articleid']->value;?>
);" class="btn_toBookShelf">加入书架</a><a href="/mybook.php" class="btn_toMyBook">我的书架</a><a href="<?php echo $_smarty_tpl->tpl_vars['_17mb_pcurl']->value;?>
/modules/article/packdown.php?id=<?php echo $_smarty_tpl->tpl_vars['articleid']->value;?>
&amp;type=txt&amp;fname=<?php echo urlencode($_smarty_tpl->tpl_vars['articlename']->value);?>
">TXT下载</a>
	</p>
        <p class="review">
        	<?php echo $_smarty_tpl->tpl_vars['intro']->value;?>

        </p>
    </div>
    <div  class="recommend">
        <h2><a>最新章节 &nbsp;&nbsp;&nbsp;&nbsp;更新：<?php echo smarty_modifier_date_format($_smarty_tpl->tpl_vars['lastupdate']->value,"Y-m-d");?>
</a></h2>
	<div class="directoryArea">
		<?php if (isset($_smarty_tpl->tpl_vars['smarty']->value['section']['i'])) unset($_smarty_tpl->tpl_vars['smarty']->value['section']['i']);
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['name'] = 'i';
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['loop'] = is_array($_loop=$_smarty_tpl->tpl_vars['chapter']->value) ? count($_loop) : max(0, (int) $_loop); unset($_loop);
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['show'] = true;
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['max'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['loop'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['step'] = 1;
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['start'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['step'] > 0 ? 0 : $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['loop']-1;
if ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['show']) {
    $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['total'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['loop'];
    if ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['total'] == 0)
        $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['show'] = false;
} else
    $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['total'] = 0;
if ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['show']):

            for ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['start'], $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration'] = 1;
                 $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration'] <= $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['total'];
                 $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index'] += $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['step'], $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration']++):
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['rownum'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index_prev'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index'] - $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['step'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index_next'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index'] + $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['step'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['first']      = ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration'] == 1);
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['last']       = ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration'] == $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['total']);
?>
            <p><a href="/<?php echo $_smarty_tpl->tpl_vars['shortid']->value;?>
_<?php echo $_smarty_tpl->tpl_vars['articleid']->value;?>
/<?php echo $_smarty_tpl->tpl_vars['chapter']->value[$_smarty_tpl->getVariable('smarty')->value['section']['i']['index']]['chapterid'];?>
.html"><?php echo $_smarty_tpl->tpl_vars['chapter']->value[$_smarty_tpl->getVariable('smarty')->value['section']['i']['index']]['chaptername'];?>
</a></p>
        <?php endfor; endif; ?>
	</div>
 	 <h2><a href="/<?php echo $_smarty_tpl->tpl_vars['shortid']->value;?>
_<?php echo $_smarty_tpl->tpl_vars['articleid']->value;?>
/all.html">查看完整目录</a></h2>
    </div>
    <?php echo '<script'; ?>
 language="javascript" type="text/javascript" src="/js/zepto.min.js"><?php echo '</script'; ?>
>
    <?php echo '<script'; ?>
 language="javascript" type="text/javascript" src="/js/common.js"><?php echo '</script'; ?>
>
    <?php echo '<script'; ?>
 language="javascript" type="text/javascript" src="/js/index.js"><?php echo '</script'; ?>
>
    <?php echo '<script'; ?>
 language="javascript" type="text/javascript" src="/js/lazyload.js"><?php echo '</script'; ?>
>
  <?php echo '<script'; ?>
 language="javascript" type="text/javascript">
$(function(){
    ReverseChapterList()
	$("img.lazy").lazyload();
});

$('.nav a').click(function(){
	$(this).addClass('sel');
	$(this).siblings().removeClass('sel');
	
	$obj = $('.'+ $(this).attr('id'));
	
	$obj.siblings().hide();
	$obj.show();
	$('.bomtype').text($obj.data('type'));
	$('.bomtypeclass').text($(this).attr('id'));
});	

$(function(){
	$('.btn_to2014').click(function(){
		$('.bom_synopsis').show();
		$('.bg').show();
	});
	
	$('.bomhide').click(function(){
		$('.bombox').hide();
		$('.bg').hide();	
	});
})
    <?php echo '</script'; ?>
>
    
<?php echo $_smarty_tpl->getSubTemplate ("foot.html", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

<?php echo '<script'; ?>
 src="/click.php?aid=<?php echo $_smarty_tpl->tpl_vars['articleid']->value;?>
"><?php echo '</script'; ?>
>
  </body>
</html><?php }} ?>
