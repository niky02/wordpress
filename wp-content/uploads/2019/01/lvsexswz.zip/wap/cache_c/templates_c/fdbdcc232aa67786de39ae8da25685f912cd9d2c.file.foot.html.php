<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-10-02 14:52:56
         compiled from "D:\wwwroot\wap\wwwroot\17mb\templates\foot.html" */ ?>
<?php /*%%SmartyHeaderCode:2932657f11f484f6441-11773546%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'fdbdcc232aa67786de39ae8da25685f912cd9d2c' => 
    array (
      0 => 'D:\\wwwroot\\wap\\wwwroot\\17mb\\templates\\foot.html',
      1 => 1471520670,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2932657f11f484f6441-11773546',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_57f11f4851db16_99973163',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57f11f4851db16_99973163')) {function content_57f11f4851db16_99973163($_smarty_tpl) {?><?php echo '<script'; ?>
>_17mb_tj();_17mb_bottom();<?php echo '</script'; ?>
>
<form name="articlesearch" class="searchForm" method="post" action="/s.php">  
    <input type="text" name="keyword" class="searchForm_input searchForm_input2" value="输入书名•作者" />
    <input type="hidden" name="t" value="1" />
    <input type="submit" class="searchForm_btn" value="搜索" />
</form>

<p class="note">
</p>
<footer>
    <a href="#top"><img src="/images/icon-backtop.gif" title="↑" alt="↑"/></a>
    <p class="version channel">
    <a href="/">首页</a>
    <a href="/mybook.php" >我的书架</a>
    <a href="/newcase.html" >阅读记录</a>
<?php echo '<script'; ?>
 src="https://s95.cnzz.com/z_stat.php?id=1260170988&web_id=1260170988" language="JavaScript"><?php echo '</script'; ?>
>
    </p>
</footer><?php }} ?>
