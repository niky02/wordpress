<?php 
	session_start();
	require 'main.php';
	require '17mb/class/opf.php';
	require($_17mb_pcdir."/configs/article/sort.php");
	$url=$_SERVER['REQUEST_URI'];
	$urlchapter = $_17mb_url.$url;
	$_17mb_uid = $_SESSION["jieqiUserId"] ? $_SESSION["jieqiUserId"] : "";
	if($_GET['aid'] && $_GET['cid']){
		$aid = intval($_GET['aid']);
		$cid = intval($_GET['cid']);
		$shortid = intval($aid/1000);
		$opf = opf($_17mb_txtdir,$aid);
		if($opf[0] == 1){
			//小说信息
			$article = $opf[1]['metadata']['dc-metadata'];
			$chapter = $opf[1]['manifest']['item'];
			$sortid = $article['Sortid'];
			$articlename = $article['Title'];
			$author = $article['Creator'];
			$intro = $article['Description'];
			$fullflag = $article['Fullflag'] == 1 ? "已完结" : "连载中";
			$lastupdate = $article['Date'];
			$tpl->assign("articleid",$aid);
			$tpl->assign("shortid",$shortid);
			$tpl->assign('chapterid',$cid);
			$tpl->assign("articlename",$articlename);
			$tpl->assign("author",$author);
			$tpl->assign("intro",$intro);
			$tpl->assign("sortid",$sortid);
			$tpl->assign("sortname",$jieqiSort['article'][$sortid]['caption']);
			$tpl->assign("fullflag",$fullflag);
			$tpl->assign("lastupdate",$lastupdate);
			$tpl->assign("_17mb_uid",$_17mb_uid);
			$tpl->assign("urlchapter",$urlchapter);
			
			$txtdir = $_17mb_txtdir.'/'.$shortid.'/'.$aid.'/'.$cid.'.txt';
			if(file_exists($txtdir)){
				$_17mb_content = @file_get_contents($txtdir);
				$_17mb_content = @str_replace("\r\n","<br/>",$_17mb_content);
				$_17mb_content = iconv("gbk","utf-8",@str_replace(" ","&nbsp;",$_17mb_content));
			}
			else{
				echo "章节TXT文件不存在，请检查！";
				die();
			}
			//章节内容
			/*if($chapter->attachment){
				$image_code = $chapter->attachment;
				$attachdir = $_17mb_pcdir.'/files/article/attachment/'.$shortid.'/'.$aid.'/'.$cid.'';
				$files=array();
				$dirhandle = @opendir($attachdir);
				while ($file = @readdir($dirhandle)) {
					if($file != '.' && $file != '..'){
						$files[] = $file;
					}
				}
				@closedir($dirhandle);
				foreach($files as $file){
					if (is_file($attachdir.'/'.$file)){
						$_17mb_content_img .= '<img src="'.$_17mb_pcurl.'/files/article/attachment/'.$shortid.'/'.$aid.'/'.$cid.'/'.$file.'" border="0" width="100%" class="imagecontent" />';
					}
				}					
			}*/
			$tpl->assign("_17mb_content",$_17mb_content.'<br/>'.$_17mb_content_img);			
			
			//章节列表
			$k = 0;
			$kk = 0;
			foreach($chapter as $v){
				$tmpcid = str_replace('.txt','',$v['@attributes']['href']);
				if($v['@attributes']['content-type'] == "chapter"){
					if($tmpcid == $cid){
						$kk = $k;
					}
					$arr[$k]['chapterid'] = $tmpcid;
					$arr[$k]['chaptername'] = $v['@attributes']['id'];
				}
				$k++;
			}
			$chaptername = $arr[$kk]['chaptername'];
			$preview_chapterid = $arr[($kk-1)]['chapterid'];
			$preview_chaptername = $arr[($kk-1)]['chaptername'];
			$next_chapterid = $arr[($kk+1)]['chapterid'];
			$next_chaptername = $arr[($kk+1)]['chaptername'];
			$tpl->assign('chaptername',$chaptername);
			$tpl->assign('preview_chapterid',$preview_chapterid);
			$tpl->assign('next_chapterid',$next_chapterid);
		}
		else{
			@header("http/1.1 404 not found"); 
			@header("status: 404 not found");
			echo "17模板网提示您：小说opf文件不存在，请检查URL是否正确！此页面返回404状态！";
			die();
		}
	}
	$cachedir = str_replace('\\','/',$tpl->cache_dir).intval($aid/1000)."/".$aid;
	$tpl->cache_dir = $cachedir;
	$tpl->display('chapter.html',$url);
?>