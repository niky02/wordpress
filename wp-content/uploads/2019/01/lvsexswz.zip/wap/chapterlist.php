<?php 
	require 'main.php';
	require '17mb/class/opf.php';
	require($_17mb_pcdir."/configs/article/sort.php");
	$url=$_SERVER['REQUEST_URI'];	

	if($_GET['aid']){
		$aid = intval($_GET['aid']);
		$shortid = intval($aid/1000);
		$opf = opf($_17mb_txtdir,$aid);
		if($opf[0] == 1){
			//小说信息
			$article = $opf[1]['metadata']['dc-metadata'];
			$sortid = $article['Sortid'];
			$articlename = $article['Title'];
			$author = ugbk($article['Creator']);
			$intro = ugbk($article['Description']);
			$fullflag = $article['Fullflag'] == 1 ? "已完结" : "连载中";
			$lastupdate = $article['Date'];
			$tpl->assign("articleid",$aid);
			$tpl->assign("shortid",$shortid);
			$tpl->assign("articlename",$articlename);
			$tpl->assign("author",$author);
			$tpl->assign("intro",$intro);
			$tpl->assign("sortid",$sortid);
			$tpl->assign("sortname",$jieqiSort['article'][$sortid]['caption']);
			$tpl->assign("fullflag",$fullflag);
			$tpl->assign("lastupdate",$lastupdate);	
			$tpl->assign("desc",$desc);
			
			$chapter = $opf[1]['manifest']['item'];
			
			//章节列表
			$kkk = 0;
			foreach($chapter as $v){
				if($v['@attributes']['content-type'] == "chapter"){
					$arr[$kkk][chapterid] = str_replace('.txt','',$v['@attributes']['href']);
					$arr[$kkk][chaptername] = $v['@attributes']['id'];
					$kkk++;
				}
			}
			$tpl->assign('chapter',$arr);

		}
		else{
			@header("http/1.1 404 not found"); 
			@header("status: 404 not found");
			echo "17模板网提示您：小说opf文件不存在，请检查URL是否正确！此页面返回404状态！";
			die();
		}
	}
	$cachedir = str_replace('\\','/',$tpl->cache_dir).intval($aid/1000)."/".$aid;
	$tpl->cache_dir = $cachedir;
	$tpl->display('chapterlist.html',$url);
?>