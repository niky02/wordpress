<?php
if($_GET['aid']){
	$aid = intval($_GET['aid']);
	$nowtime = date('U');
	require("main.php");
	@mysql_connect($_17mb_host, $_17mb_user,$_17mb_pass)or die("1");  
	@mysql_select_db($_17mb_name)or die("2"); 
	$query = @mysql_query("update `jieqi_article_article` set `lastvisit` = '$nowtime',dayvisit = dayvisit+1,weekvisit = weekvisit+1,monthvisit = monthvisit+1,allvisit = allvisit+1 where `articleid` = '".$aid."' ") or die("3");
}
?>