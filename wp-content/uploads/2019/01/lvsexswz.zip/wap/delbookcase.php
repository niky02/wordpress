<?php 
	require 'main.php';
	require '17mb/class/sql.php';
	session_start();
	$aid = intval($_REQUEST['aid']);
	if(!is_int($aid)){
		die('error aid');
	}
	$uid = $_SESSION['jieqiUserId'];
	echo $uid;
	if($uid!=null){
		$db->query("delete from `jieqi_article_bookcase` where articleid = '".$aid."' and userid = '".$uid."'");
		header("Location:/mybook.php"); 
	}
?>
