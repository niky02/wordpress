<?php 
	require 'main.php';
	require '17mb/class/sql.php';
	require($_17mb_pcdir."/configs/article/sort.php");
	$url=$_SERVER['REQUEST_URI'];	

	$pageid = !$_REQUEST['page'] ? 1 : intval($_REQUEST['page']) ;
	$sortid = !$_REQUEST['sortid'] ? '' : intval($_REQUEST['sortid']) ;

	if(!is_int($pageid)){
		die('error pageid');
	}

	if($sortid == '' ){
		$where_sort = "";
		$tpl->assign('sortid','');
	}
	else{
		if(!is_int($sortid)){
			die('error sortid');
		}
		$where_sort = " and sortid = '$sortid' ";
		$tpl->assign('sortid',$sortid);
	}
	
	$pagecount = 1 ;//共几页
	$pagenum = 10 ;//每页有多少条数据
	$numall = 1;//全部数据条数
	$numbegin = 1;//开始数据
	$numend = 1;//结束数据
	$previd = 1;//上一页页码
	$nextid = 1;//下一页页码
	$numall = $db->get_var("select count(articleid) from ".$_17mb_prev."article_article where fullflag=1 ".$where_sort);
	$pagecount = ceil( $numall / $pagenum ) ;
	$numbegin = ( $pageid - 1 ) * $pagenum ;
	$numend = $pagenum ;

	//处理上一页和下一页页码
	if($pageid != 1){
		$previd = $pageid - 1;
	}
	if($pageid != $pagecount){
		$nextid = $pageid + 1;
	}
	else{
		$nextid = $pagecount;
	}
	
	$sqlfull = $db->get_results("select articleid,articlename,sortid,author,intro from ".$_17mb_prev."article_article where fullflag = '1' ".$where_sort." order by lastupdate desc limit ".$numbegin.",".$numend." ");	
	if($sqlfull){
		$k1 = 0;
		foreach($sqlfull as $v){
			$arr[$k1][articleid] = $v->articleid;
			$arr[$k1][shortid] = intval($v->articleid / 1000);
			$arr[$k1][articlename] = $v->articlename;
			$arr[$k1][author] = $v->author;
			$arr[$k1][intro] = $v->intro;
			$arr[$k1][sortid] = $v->sortid;
			$arr[$k1][sortname] = substr($jieqiSort['article'][$v->sortid]['caption'],0,4);
			$k1++;
		}
		$tpl->assign('articlerows',$arr);	
	}
	//页码设置
	$prepage = '<a href="/quanben'.$sortid.'_'.$previd.'.html">上一页</a>';
	$nextpage = '<a href="/quanben'.$sortid.'_'.$nextid.'.html">下一页</a>';
	//首页尾页处理
	//第一页
	if($pageid == 1 ){$prepage = ''; }
	//最后一页
	if($pageid == $pagecount){$nextpage = ''; }
	if($pageid == 1 && $pageid == $pagecount){
		$nextpage = '<a href="/quanben'.$sortid.'_'.$nextid.'.html">下一页</a>';
	}
	$pagecontent .=$prepage.'<input type="text" class="page_txt" value="'.$pageid.'/'.$pagecount.'" size="5" name="txtPage" id="txtPage" />'.$nextpage;
	$tpl->assign('jumppage',$pagecontent);
	$kk = 0;
	foreach($jieqiSort['article'] as $key=>$v){
		$arrSort[$kk]['sortid'] = $key;
		$arrSort[$kk]['sortname'] = iconv("gbk","utf-8",$v['caption']);
		$kk++;
	}
	$tpl->assign('sort',$arrSort);
	
	$tpl->display('full.html',$url);
?>
