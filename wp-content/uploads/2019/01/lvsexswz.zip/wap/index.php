<?php
	require 'main.php';
	require '17mb/class/sql.php';
	session_start();
	require($_17mb_pcdir."/configs/article/sort.php");
	$sorts = $jieqiSort['article'];
	$qt = $db->get_results($sql_qt);
	$k1 = 0;
	foreach($qt as $v){
		$arr[$k1][articleid] = $v->articleid;
		$arr[$k1][shortid] = intval($v->articleid / 1000);
		$arr[$k1][articlename] = $v->articlename;
		$arr[$k1][intro] = $v->intro;
		$arr[$k1][author] = $v->author;
		$arr[$k1][sortid] = $v->sortid;
		$arr[$k1][sortname] = substr($sorts[$v->sortid]['caption'],0,4);
		$k1++;
	}
	$tpl->assign('qt',$arr);
	
	function b($arr){
		global $_17mb_host;
		global $_17mb_user;
		global $_17mb_name;
		global $_17mb_pass;
		global $_17mb_prev;
		global $sorts;
		require '17mb/class/sql.php';
		$content = "";
		$num = $arr['num'];//次数
		$class = $arr['class'];//分类
		$order = $arr['order'];//排序
		$url = $arr['url'];//URL
		$block = $db->get_results("select `articleid`,`articlename`,`sortid`,`lastupdate`,`lastchapter` from `".$_17mb_prev."article_article` where `sortid` = '$class' order by `$order` desc limit $num");
		for($i=0;$i<$num;$i++){
			$articleid = $block[$i]->articleid;
			$shortid = intval($articleid/1000);
			$url1 = str_replace('{shortid}',$shortid,$url);
			$url2 = str_replace('{articleid}',$articleid,$url1);
			$content .= "
					<li><a href=\"$url2\"><p><span class=\"sort\">[".iconv("gbk","utf-8",$sorts[$block[$i]->sortid]['caption'])."]</span><span class=\"title\">".$block[$i]->articlename."</span></p><li>";
		}
		return $content;
	}
	$tpl->registerPlugin("function","17mb_block","b");
	
	
	if($_SESSION["jieqiUserId"]){
		$uid = $_SESSION["jieqiUserId"];
		$uname = $_SESSION["jieqiUserUname"];
		$tpl->assign("uid",$uid);
		$tpl->assign("uname",$uname);
	}
	
	$tpl->display('index.html');
	
?>