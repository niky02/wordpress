<?php
	session_start();
	require 'main.php';
	require '17mb/class/sql.php';
	$tpl->caching = 0;
	
	$showbooks = "";
	if($_SESSION["jieqiUserId"]){
		$uid = $_SESSION["jieqiUserId"];
		$tpl->assign("uid",$uid);
		
		$article = $db->get_results("select * from ".$_17mb_prev."article_bookcase where userid = '".$uid."'");
		if($article){
			$k = 0;
			foreach($article as $v){
				$aid = $v->articleid;
				$lastchapter = $db->get_row("select lastchapterid,lastchapter,author from ".$_17mb_prev."article_article where articleid = '".$aid."'");
				$arr[$k][articleid] = $aid;
				$arr[$k][shortid] = intval($v->articleid / 1000);
				$arr[$k][articlename] = $v->articlename;
				$arr[$k][bookmarkid] = $v->chapterid == 0 ? "" : $v->chapterid;
				$arr[$k][bookmark] = $v->chaptername;
				$arr[$k][author] = $lastchapter->author;
				$arr[$k][fullflag] = $v->fullflag == 1 ? '完本' : '连载' ;
				$arr[$k][lastchapter] = $lastchapter->lastchapter;
				$arr[$k][lastchapterid] = $lastchapter->lastchapterid;
				$arr[$k][kk] = $k+1;
				$k++;
			}
			$tpl->assign('num',$k);
			$tpl->assign('articlerows',$arr);
		}
		else{
			$_17mb_tips = '书架空空如也！<a href="/">点这里去看书吧</a>';
		}
	}
	else{
		header("Location:/login.php?url=$_17mb_url/mybook.php"); 
	}
	$tpl->assign('17mb_tips',$_17mb_tips);
	$tpl->caching = 0;
	$tpl->display('mybook.html',$url);
?> 
