<?php
	session_start();
	require 'main.php';
	require '17mb/class/sql.php';

	//$article = $db->get_results("select * from ".$_17mb_prev."article_bookcase where userid = '".$uid."'");

	/*$k = 0;
	foreach($article as $v){
		$aid = $v->articleid;
		$lastchapter = $db->get_row("select lastchapterid,lastchapter from ".$_17mb_prev."article_article where articleid = '".$aid."'");
		$arr[$k][articleid] = $aid;
		$arr[$k][shortid] = intval($v->articleid / 1000);
		$arr[$k][articlename] = $v->articlename;
		$arr[$k][bookmarkid] = $v->chapterid == 0 ? "" : $v->chapterid;
		$arr[$k][bookmark] = $v->chaptername;
		$arr[$k][lastchapter] = $lastchapter->lastchapter;
		$arr[$k][lastchapterid] = $lastchapter->lastchapterid;
		$k++;
	}
	$tpl->assign('num',$k);
	$tpl->assign('articlerows',$arr);
	*/
	
	$tpl->caching = 0;
	$tpl->display('newcase.html',$url);
?> 
