<?php
	session_start();
	require 'main.php';
	require '17mb/class/sql.php';
	$url=$_SERVER['REQUEST_URI'];	
	
	if($_SESSION["jieqiUserId"] && $_SESSION["jieqiUserUname"] && $_SESSION["jieqiUserGroup"]){
		$uid = $_SESSION["jieqiUserId"];
		$uname = $_SESSION["jieqiUserUname"];
		$ugroup = $_SESSION["jieqiUserGroup"];
				
		$tpl->assign('_17mb_uid',$uid);
		$tpl->assign('_17mb_uname',$uname);
		if($_POST['upass1'] && $_POST['upass2']){
			$upass1 = $_POST['upass1'];
			$upass2 = $_POST['upass2'];
			if($upass1 == $upass2){
				$upass = $upass1 = $upass2;
				if($upass == ''){
					$tips = '请输入密码！';
				}
				elseif(strlen($upass) > 16){
					$tips = '密码长度太长！';
				}
				elseif(strlen($upass) < 6){
					$tips = '密码长度太短！';
				}
				else{
					$upass = substr($upass,0,16);
					if(preg_match('/^([a-zA-Z0-9]*)$/',$upass)){
						$s = array(',',';','\'','~','$','%','^','^','*','(',')','<','>','{','}');
						$upass = str_replace($s,'',$upass);
						$e = $db->query("update ".$_17mb_prev."system_users set pass ='".md5($upass)."' where uid = '".$uid."' and uname = '".$uname."' and groupid = '".$ugroup."'");
						if($e){
							$tips = '密码修改成功，请记住新密码！';
						}
						else{
							$tips = '密码修改失败，请联系管理员！';
						}
					}
					else{
						$tips = '密码格式不正确！';
					}
				}
			}
			else{
				$tips = '两次输入的密码不一致！';
			}
			$tpl->assign('tips',$tips.'<a href="/user.php" style="color:red"><b>回用户中心</b></a>');
		}
	}
	else{
		header("Location:/login.php?url=$_17mb_url/user.php"); 
	}
	$tpl->caching = 0;
	$tpl->display('passeditw.html',$url);
?>
