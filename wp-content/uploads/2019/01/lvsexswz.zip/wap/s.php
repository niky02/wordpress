<?php
	session_start();
	require 'main.php';
	require '17mb/class/sql.php';
	require($_17mb_pcdir."/configs/article/sort.php");

	if($_REQUEST['keyword']){
		$s = $_REQUEST['keyword'];
		$s = str_replace('输入书名•作者','',$s);
		$s = str_replace('•','',$s);
		$s = strsql($s);
		$tpl->assign("search_key",$s);
		//$s = iconv("utf-8", "gbk", $s);
		if(strlen($s) < 2){
			$_17mb_tips = "请输入搜索关键词！";
		}
		else{
			$s = mysql_real_escape_string($s);
	
			$where = "articlename like '%".$s."%' or author like '%".$s."%'";
	
			$article = $db->get_results("select articleid,sortid,articlename,author,fullflag,lastchapter from ".$_17mb_prev."article_article where ".$where." order by articleid desc");
	
			$search_num = "";
			if($article){
				$search_num = "1";
				$k = 0;
				foreach($article as $v){
					$arr[$k][d2] = ($k % 2 == 0) ? '' : '1' ;
					$arr[$k][articleid] = $v->articleid;
					$arr[$k][shortid] = intval($v->articleid / 1000);
					$arr[$k][articlename] = $v->articlename;
					$arr[$k][intro] = $v->intro;
					$arr[$k][author] = $v->author;
					$arr[$k][sortid] = $v->sortid;
					$arr[$k][fullflag] = ($v->fullflag == 0) ? '连载' : '完结';
					$arr[$k][lastchapter] = $v->lastchapter;
					$arr[$k][sortname] = iconv("gbk","utf-8",$jieqiSort['article'][$v->sortid]['caption']);
					$k++;
				}
				$tpl->assign('articlerows',$arr);
			}
			else{
				$_17mb_tips = "无搜索结果！";
			}
			$tpl->assign("search_num",$search_num);
		}
	}
	$tpl->assign('17mb_tips',$_17mb_tips);
	$tpl->caching = 0;
	$tpl->display('s.html',$url);
?>