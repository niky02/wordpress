<?php

	require 'main.php';
	require '17mb/class/sql.php';
	require($_17mb_pcdir."/configs/article/sort.php");
	$url=$_SERVER['REQUEST_URI'];	
	
	$kk = 0;
	foreach($jieqiSort['article'] as $key=>$v){
		$arrSort[$kk]['sortid'] = $key;
		$arrSort[$kk]['sortname'] = iconv("gbk","utf-8",$v['caption']);
		$kk++;
	}
	$tpl->assign('sort',$arrSort);

	if($_GET[page]){ 
		$sortid = intval($_GET['sortid']);
		$pageid = intval($_GET['page']);		
		$sortname = iconv("gbk","utf-8",$jieqiSort['article'][$sortid][caption]);
		$sortname = $sortname ? $sortname : '分类';
		if(!is_int($sortid)){
			die('error sortid');
		}
		if(!is_int($pageid)){
			die('error pageid');
		}
		$pagecount = 1 ;
		$pagenum = 10 ;
		$numall = 1;
		$numbegin = 1;
		$numend = 1;
		$previd = 1;
		$nextid = 1;
		if($sortid == 0){
			$numall =  $db->get_var("select count(articleid) from ".$_17mb_prev."article_article"); 
		}
		else{
			$numall =  $db->get_var("select count(articleid) from ".$_17mb_prev."article_article where sortid = '".$sortid."' "); 
		}
		$pagecount = ceil( $numall / $pagenum ) ;
		$numbegin = ( $pageid - 1 ) * $pagenum ;
		$numend = $pagenum ;
		//处理上一页和下一页页码
		if($pageid != 1){
			$previd = $pageid - 1;
		}
		if($pageid != $pagecount){
			$nextid = $pageid + 1;
		}
		else{
			$nextid = $pagecount;
		}
		if($sortid == 0){
			$sqlsort = $db->get_results("select articleid,articlename,author,intro from jieqi_article_article order by lastupdate desc limit ".$numbegin.",".$numend." ");
		}
		else{
			$sqlsort = $db->get_results("select articleid,articlename,author,intro from jieqi_article_article where sortid = '".$sortid."' order by lastupdate desc limit ".$numbegin.",".$numend." ");
		}
		if($sqlsort){
			$tpl->assign("type",$type);
			$tpl->assign("sortid",$sortid);
			$tpl->assign("sortname",$sortname);
			$k1 = 0;
			foreach($sqlsort as $v){
				$arr[$k1][articleid] = $v->articleid;
				$arr[$k1][shortid] = intval($v->articleid / 1000);
				$arr[$k1][articlename] = $v->articlename;
				$arr[$k1][author] = $v->author;
				$arr[$k1][intro] = $v->intro;
				$k1++;
			}
			$tpl->assign('articlerows',$arr);	
			
			//页码处理
			$shouye = '<a href="/xclass/'.$sortid.'/1.html">[首页]</a>';
			$preview = '<a href="/xclass/'.$sortid.'/'.$previd.'.html">[上页]</a>';
			$next = '<a href="/xclass/'.$sortid.'/'.$nextid.'.html">[下页]</a>';
			$weiye = '<a href="/xclass/'.$sortid.'/'.$pagecount.'.html">[尾页]</a>';
			//第一页
			if($pageid == 1 ){$preview = ''; }
			//最后一页
			if($pageid == $pagecount){$next = ''; }
			
			$pagecontent .=$preview.'<input type="text" class="page_txt" value="'.$pageid.'/'.$pagecount.'" size="5" name="txtPage" id="txtPage" />'.$next;
	
			$tpl->assign('jumppage',$pagecontent);	
		}
		
	}
	else{
	
	}
	$cachedir = str_replace('\\','/',$tpl->cache_dir)."sort";
	$tpl->cache_dir = $cachedir;
	$tpl->display('sort.html',$url);	
?>
