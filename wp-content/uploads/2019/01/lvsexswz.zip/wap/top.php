<?php
	require 'main.php';
	require '17mb/class/sql.php';
	require($_17mb_pcdir."/configs/article/sort.php");
	$url=$_SERVER['REQUEST_URI'];	

	if($_REQUEST['type']){
		
		$type = $_REQUEST['type'];		
		
		$pageid = !$_REQUEST['page'] ? 1 : intval($_REQUEST['page']) ;
		$sortid = !$_REQUEST['sortid'] ? '' : intval($_REQUEST['sortid']) ;
			
		if(!is_int($pageid)){
			die('error pageid');
		}
			
		if($type == "week" ||$type == "month" ||$type == "all" ){
		
			$pagecount = 1 ;
			$pagenum = 10 ;
			$numall = 1;
			$numbegin = 1;
			$numend = 1;
			$previd = 1;
			$nextid = 1;
			
			$nowtime = date("U");//现在时间
			
			if($type == "week" ) { 
				$typename = "周排行榜";$orderby = "weekvisit";$where = "where lastvisit > ".($nowtime-604800);
			}
			if($type == "month" ){ 
				$typename = "月排行榜";$orderby = "monthvisit";$where = "where lastvisit > ".($nowtime-2592000);
			}
			if($type == "all" )  { 
				$typename = "总排行榜";$orderby = "allvisit";$where = "where 1=1";
			}
			if($sortid == '' ){
				$where_sort = "";
				$tpl->assign('sortid','');
			}
			else{
				if(!is_int($sortid)){
					die('error sortid');
				}
				$where_sort = " and sortid = '$sortid' ";
				$tpl->assign('sortid',$sortid);
			}
			$tpl->assign("type",$type);
			$tpl->assign("typename",$typename);
			
			$numall =  $db->get_var($sql_type_num.$where.$where_sort); 
			$pagecount = ceil( $numall / $pagenum ) ;
			$numbegin = ( $pageid - 1 ) * $pagenum ;
			$numend = $pagenum ;
			//处理上一页和下一页页码
			if($pageid != 1){
				$previd = $pageid - 1;
			}
			if($pageid != $pagecount){
				$nextid = $pageid + 1;
			}
			else{
				$nextid = $pagecount;
			}
			$sqltype = $db->get_results("select articleid,articlename,author,sortid,intro from ".$_17mb_prev."article_article ".$where.$where_sort." order by ".$orderby." desc limit ".$numbegin.",".$numend);
			if($sqltype){
				$k1 = 0;
				foreach($sqltype as $v){
					$arr[$k1][articleid] = $v->articleid;
					$arr[$k1][shortid] = intval($v->articleid / 1000);
					$arr[$k1][articlename] = $v->articlename;
					$arr[$k1][author] = $v->author;
					$arr[$k1][sortid] = $v->sortid;
					$arr[$k1][sortname] = substr($jieqiSort['article'][$v->sortid]['caption'],0,4);
					$arr[$k1][intro] = $v->intro;
					$k1++;
				}
				$tpl->assign('articlerows',$arr);
				
				//页码处理
				$preview = '<a href="/ph/'.$type.$sortid.'_'.$previd.'.html">[上页]</a>';
				$next = '<a href="/ph/'.$type.$sortid.'_'.$nextid.'.html">[下页]</a>';
				//第一页
				if($pageid == 1 ){$preview = ''; }
				//最后一页
				if($pageid == $pagecount){$next = ''; }
				if($pageid == 1 && $pageid == $pagecount){
					$next = '<a href="/ph/'.$type.$sortid.'_'.$nextid.'.html">[下页]</a>';	
				}
				$pagecontent .=$preview.'<input type="text" class="page_txt" value="'.$pageid.'/'.$pagecount.'" size="5" name="txtPage" id="txtPage" />'.$next;
				$tpl->assign('jumppage',$pagecontent);
			
			}
			$kk = 0;
			foreach($jieqiSort['article'] as $key=>$v){
				$arrSort[$kk]['sortid'] = $key;
				$arrSort[$kk]['sortname'] = iconv("gbk","utf-8",$v['caption']);
				$kk++;
			}
			$tpl->assign('sort',$arrSort);
			
		}
		else{
			die("1-".$type);
		}
	}

	else{
		die();
	}
	$cachedir = str_replace('\\','/',$tpl->cache_dir)."top";
	$tpl->cache_dir = $cachedir;
	$tpl->display('top.html',$url);	
?>