<?php
	session_start();
	require 'main.php';
	require '17mb/class/sql.php';
	require($_17mb_pcdir."/configs/article/sort.php");
	if($_SESSION["jieqiUserId"] && $_SESSION["jieqiUserUname"] && $_SESSION["jieqiUserGroup"]){
		$uid = $_SESSION["jieqiUserId"];
		$uname = $_SESSION["jieqiUserUname"];
		$ugroup = $_SESSION["jieqiUserGroup"];
		$user = $db->get_row("select * from ".$_17mb_prev."system_users where uid = '".$uid."'");
		if($user){
			$regdate = $user->regdate;
			$email = $user->email;
			$avatar = $user->avatar;
		}
		$tpl->assign('_17mb_uid',$uid);
		$tpl->assign('_17mb_uname',$uname);
		$tpl->assign('_17mb_regdate',$regdate);
		$tpl->assign('_17mb_email',$email);
		$tpl->assign('_17mb_avatar',$avatar);
	}
	else{
		header("Location:/login.php?url=$_17mb_url/user.php"); 
	}
/*	
								
		
		if($sqlfull){
				$tpl->assign('jumppage',$pagecontent);	
		}*/
	$tpl->caching = 0;
	$tpl->display('user.html',$url);
?>
