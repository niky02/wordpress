<?php
/**
 * 早起打卡挑战模块定义
 *
 * @author hai105
 * @url 
 */
defined('IN_IA') or exit('Access Denied');

class Hai105_dakaModule extends WeModule {



}